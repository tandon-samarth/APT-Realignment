import pandas as pd
import sqlalchemy
from datetime import datetime
import typing
import pkgutil
import csv
import logging
import traceback
from time import sleep
from maps_analytics_utils.utils.auxilary import get_map_version


def get_columns_condition(row):
    """Generates a column with a list that contains the columns that are used to filter OSM ddbb

    :param row: DataFrame row
    :type row: DataFrame row
    :return: list that contains the names of the columns of the ddbb to filter to implement that condition
    :rtype: list
    """
    cols_list = [i.split('=', 1)[0] for i in row['osm_tags'].split(',')] 
    return cols_list


def are_columns_of_schema(row, reference_list):
    """Generates boolean indicating if the columns used in the filter for selecting OSM POIs of a Ttom category
    are contained in the table's columns

    :param row: DataFrame row
    :type row: DataFrame row
    :param condition_list: list with the columns used for the where clause in the condition
    :type condition_list: list
    :param reference_list: list with the columns of the table of that country's schema
    :type reference_list: list
    :return: bool
    :rtype: bool
    """
    return set(row['condition_fields']).issubset(reference_list)


def retry_read_query(sql, engine, num_retries=5, sleep_time=2):
    """Tries to read the input sql query num_retries times, 
    waiting sleep_time seconds before trying to fetch the data again

    :param sql: sql query
    :type sql: str
    :param num_retries: number of times to try to fetch the data, defaults to 5
    :type num_retries: int, optional
    :param sleep_time: number of seconds to wait if fails, 
    which will be multiplied by 2 in each failure, defaults to 2
    :type sleep_time: int, optional
    :return: dataframe with the query result
    :rtype: pandas.DataFrame
    """
    # logging.info(sql)

    df = None
    
    for num in range(0, num_retries):  # try num_retries times
        # logging.info('Retry num: ' + str(num))
        try:
            # df= pd.read_sql_query(sql, engine, chunksize=10000)
            df= pd.read_sql_query(sql, engine).reset_index(drop=True)
            break
            
        except Exception as ex:
            logging.info(ex)
            # logging.info('Sleeping: ' + str(sleep_time) + ' seconds')
            sleep(sleep_time)          # wait for sleep_time seconds before trying to fetch the data again
            sleep_time *= 2            # Implement backoff
            
    return df


def get_engine_from_the_db(db):
    """[summary]

    :param db: name of the database on which you want the engine
    :type db: string
    :return: engine
    :rtype: sqlalchemy engine
    """

    # dictionary with all the connections available so far
    # TODO: convert to file
    driver = 'postgresql'
    db_dict = {'poi': {'host': 'poi_db_dev.maps-data-analytics-dev.amiefarm.com',
                       'port': '5432',
                       'database': 'poi',
                       'user': 'dba_admin',
                       'psw': 'dba_admin'},
               'mdbf': {'host': 'prod-mdbf-db.c2mcxsumdn8z.eu-west-1.rds.amazonaws.com',
                        'port': '5432',
                        'database': 'mdbf_db',
                        'user': 'dl_quality_leadstore_prod',
                        'psw': 'dl_quality_leadstore_prod'},
               'mnr_country_eur': {'host': 'caprod-cpp-pgmnr-001.flatns.net',
                                   'port': '5432',
                                   'database': 'mnr',
                                   'user': 'mnr_ro',
                                   'psw': 'mnr_ro'},
               'mnr_country_usaaa1_row': {'host': 'caprod-cpp-pgmnr-002.flatns.net',
                                       'port': '5432',
                                       'database': 'mnr',
                                       'user': 'mnr_ro',
                                       'psw': 'mnr_ro'},
                'mnr_continent_eur_usa': {'host': 'caprod-cpp-pgmnr-005.flatns.net',
                                       'port': '5432',
                                       'database': 'mnr',
                                       'user': 'mnr_ro',
                                       'psw': 'mnr_ro'},
                'mnr_continent_row': {'host': 'caprod-cpp-pgmnr-006.flatns.net',
                                       'port': '5432',
                                       'database': 'mnr',
                                       'user': 'mnr_ro',
                                       'psw': 'mnr_ro'},
                'openmap': {'host': 'vad3g-prod.openmap.maps.az.tt3.com',
                            'port': '5432',
                            'database': 'ggg',
                            'user': 'ggg_ro',
                            'psw': 'ggg_ro'}
               }

    try:
        engine = sqlalchemy.create_engine(driver + '://' +
                               db_dict[db]['user'] + ':' +
                               db_dict[db]['psw'] + '@' +
                               db_dict[db]['host'] + ':' +
                               db_dict[db]['port'] + '/' +
                               db_dict[db]['database'],
                               executemany_mode='values',
                               executemany_values_page_size=10000,
                               connect_args={'connect_timeout': 600}
                               )
        
        return engine

    except Exception as e:
        print('ERROR occured when creating the engine')
        print('\tCode:  ' + e.code)
        print('\tError origin: ' + str(e.orig))


def get_mnr_schema(country, db):
    """Retrieves the last schema of mnr, for a given country, from country mnr servers

    :param country: country iso code
    :type country: string
    :param db: name of the DB-> 
            - poi
            - mdbf
            - mnr_country_eur
            - mnr_country_usaaa1_row
            - mnr_continent_eur_usa
            - mnr_continent_row
    :type db: string
    :return: the name of the last mnr schema for tha country
    :rtype: string
    """

    try:
        engine = get_engine_from_the_db(db)
        conn = engine.raw_connection()
        cursor= conn.cursor()

        if country.upper() in ("USA","CAN"): #USA and CAN are queried directly in the continent server so, there is not need to get the country schema, but just return 'nam'
            db_schema="nam" #returning the string of "USA" or "CAN"
        else:
            cursor.execute("select schema_name from information_schema.schemata where schema_name ilike '%{}%' order by schema_name asc;".format(country))
            if country.upper() in ('CHE','IND', 'ISR'): # This is needed because of special behaviour of these countries
                cursor.scroll(cursor.rowcount-2)
                db_schema=cursor.fetchone()[0] #returning the string of the tuple
            else:
                cursor.scroll(cursor.rowcount-1)
                db_schema=cursor.fetchone()[0] #returning the string of the tuple

    except Exception as e:
        print('ERROR -> are you connected to the VPN?')
        print(str(datetime.now())+"   ERROR when selecting the schema: "+ str(e))
        raise
    else:
        return db_schema
    finally:
        cursor.close()


def get_mnr_server_for_country(country: str) -> str:
    """Function that searches for MNR server name based on the input ISO3 country code.
    The list with the corresponding MNR server names can be found at pssr/data/raw/country_server_link.csv

    :param country: ISO3 country code.
    :type country: str
    :return: MNR server name, where country info is located.
    :rtype: str
    """
    #TODO
    #Change path, once pushed to develop branch
    MatFile = pkgutil.get_data(__name__, '../data/raw/country_server_link.csv')
    dfreader = csv.reader(MatFile.decode('utf-8').splitlines(), delimiter=';')
    df = pd.DataFrame(data=dfreader)
    new_header = df.iloc[0] #grab the first row for the header
    df = df[1:] #take the data less the header row
    df.columns = new_header
    try:
        server = df.loc[df.country == str.lower(country),'db'].values[0]
        return server
    except IndexError as e:
        print("IndexError:", e, "--- Make sure the input is a country ISO3 code.")


def get_pois_to_check_from_mnr_db(sql, db):
    """Get sample from mnr
        :param sql: sql string to be executed
        :type sql: string
        :param db: name of the mnr server to query
        :type db: string
        :return: dataframe with the sample"""

    # create engine for the call
    engine = db.get_engine_from_the_db(db)

    df = pd.DataFrame()

    try:
        df = pd.read_sql(sql, engine)
    except Exception as e:
        logging.error(traceback.print_exc())
        print(traceback.print_exc())
        df = pd.DataFrame()

    return df


def create_sql_sample_mnr_pois_without_areas_with_external_id_one_stn_country(schema, country, limit, poi_types):
    """ Creates a sql string that queries MNR database to get samples for POIs. It also includes the eexternal POI_ID to use with the API calls
    This includes several STN per POI. Additional function must be run to align STNs from rows to columns: STN1, STN2
    :param schema: schema we want to query to
    :type schema: str
    :param limit: amount of elements we want
    :type limit: int
    :param poi_types: list of poi_types
    :type poi_types: list
    :return: SQL string qith the query we want to run
    :rtype: str
    """ 

    if isinstance(poi_types, str):
        poi_types = "('" + poi_types + "')"

    sql= """
        with unique_bn as( -- get only one bn, not the complete set
                    SELECT p2n.poi_id, mn.name
                        FROM (select poi_id, cast(min(cast(nameset_id as text)) as uuid) nameset_id
                                from {schema}.mnr_poi2nameset 
                                where nt_brand_name group by 1) p2n
                            join {schema}.mnr_nameset2name mnn
                                on p2n.nameset_id = mnn.nameset_id
                            join {schema}.mnr_name mn
                                on mnn.name_id = mn.name_id
                )
                , sample_pois as( -- select the right amount of POIS by category/country
                    SELECT mp.feat_id poi_id
                                , mp.feat_type poi_type
                                , mp.poi_address_id 
                                , '{country}' as country
                                , mp.name as poi_name
                                , bn.name as poi_bn
                                , mp.email
                                , mp.internet 
                                , mp.telephone_num
                                , st_astext(mp.geom) as wkt
                                FROM {schema}.mnr_poi mp
                                left join unique_bn bn on mp.feat_id = bn.poi_id
                    where mp.feat_type in {poi_types}
                    order by random()
                    limit {limit}
                )
                , mpaa as ( --select pois with aa8 information
                    SELECT 
                    mpaa.poi_id 
                    ,mpaa.name as aa8_name
                    , mpaa.code aa8_code
                    , maa.feat_area/1000000 area_km2
                    , ma.value_integer population
                    , ma.value_integer/(maa.feat_area/1000000) density
                    , case
                        when ma.value_integer > 100000 then 'urban'
                        when ma.value_integer > 50000 and ma.value_integer/(maa.feat_area/1000000)> 1500 then 'urban'
                        when ma.value_integer > 5000 and ma.value_integer/(maa.feat_area/1000000)> 300 then 'intermediate'
                        else 'rural'
                    end aa8_type                    
                    FROM (-- selects pois that are located in a single aa8; this multiplicitity happens due the pois on borders
                            select mpaa.*
                            FROM {schema}.mnr_poi2admin_area mpaa
                                join (
                                        select poi_id
                                            FROM {schema}.mnr_poi2admin_area mpaa
                                            where mpaa.feat_type=1119
                                            group by 1
                                            having count(*) = 1
                                        ) unique_aa
                                    on mpaa.poi_id= unique_aa.poi_id
                                join sample_pois pic 
                                            	on mpaa.poi_id = pic.poi_id
                            where mpaa.feat_type=1119
                            ) mpaa  
                        join {schema}.mnr_admin_area maa
                            on mpaa.admin_area_id = maa.feat_id
                        JOIN {schema}.mnr_admin_area2attribute maaa
                            on maaa.admin_area_id = mpaa.admin_area_id
                        join {schema}.mnr_attribute ma
                            on ma.attribute_id = maaa.attribute_id
                    where mpaa.feat_type=1119
                        and ma.attribute_type = 'PO'
                )
                , single_name as (-- get only one stn name, not the complete set
                    select nameset_id
                        , min(name_id::text) name_id
                    from {schema}.mnr_nameset2name
                    group by nameset_id
                )
                , external_ids as( -- get external_ids from the db
                    SELECT pa.poi_id , value_varchar as external_id
                    FROM {schema}.mnr_attribute a
                    join {schema}.mnr_poi2attribute as pa on a.attribute_id = pa.attribute_id
                    where attribute_type = 'EI'
                )
                SELECT mp.poi_id
                            , ei.external_id
                            , mp.poi_type
                            , mp.poi_address_id 
                            , mp.country
                            , mpaa.aa8_name
                            , mpaa.aa8_code
                            , mpaa.population
                            , mpaa.density
                            , mpaa.aa8_type
                            , mp.poi_name
                            , mp.poi_bn as poi_brand
                            , mn.name as streetname
                            , mpa.hsn as housenumber
                            , mp.email
                            , mp.internet 
                            , mp.telephone_num
                            , mp.wkt
                            FROM sample_pois mp
                            left join {schema}.mnr_poi_address mpa 
                                on mp.poi_address_id= mpa.poi_address_id
                            left join single_name mnn
                                on mpa.street_nameset_id = mnn.nameset_id
                            left join {schema}.mnr_name mn
                                on mnn.name_id::uuid = mn.name_id
                            left join mpaa
                                on mp.poi_id = mpaa.poi_id
                            left join external_ids ei
                                on ei.poi_id=mp.poi_id;""".format(schema=schema, country=country, poi_types=poi_types, limit=limit)
    return sql


def create_sql_sample_mnr_pois_without_areas_with_external_id_one_stn_continent (schema, country, limit, poi_types):
    """ Creates a sql string that queries MNR database to get samples for POIs. It also includes the eexternal POI_ID 
    to use with the API calls
    It calls the continent servers, basically for USA or CAN.
    This includes one STN per POI.
    TODO : the query is too heavy and it is timing out in the server. NEED to refactor it
    
    :param schema: schema we want to query to
    :type schema: str
    :param limit: amount of elements we want
    :type limit: int
    :param poi_types: list of poi_types
    :type poi_types: list
    :return: SQL string qith the query we want to run
    :rtype: str
    """ 

    if isinstance(poi_types, str):
        poi_types = "('" + poi_types + "')"

    sql = """with unique_bn as( -- get only one bn per poi , not the complete set
                            SELECT p2n.poi_id, mn.name
                                FROM (select poi_id, cast(min(cast(nameset_id as text)) as uuid) nameset_id from {schema}.mnr_poi2nameset where nt_brand_name group by 1) p2n
                                    join {schema}.mnr_nameset2name mnn
                                        on p2n.nameset_id = mnn.nameset_id
                                    join {schema}.mnr_name mn
                                        on mnn.name_id = mn.name_id
                        )
                        , pois_in_country as( -- select the amount of needed POIs per category/country
                                select mp.feat_id poi_id
                                , '{country}' as country
                                , mp.feat_type
                                , mp.name
                                , bn.name as poi_bn
                                , mp.email
                                , mp.internet 
                                , mp.telephone_num
                                , st_astext(mp.geom) as geom
                                , mp.poi_address_id
                                FROM {schema}.mnr_poi mp
                                    join {schema}.mnr_poi2admin_area paa on mp.feat_id= paa.poi_id
                                    left join unique_bn bn on bn.poi_id=mp.feat_id
                                where paa.feat_type=1111 and paa.code='USA'
                                    and mp.feat_type in {poi_types}
                                    and bn.name is null -- This part makes to exclude pois with bn
                                order by random()
                                limit {limit}     
                                )
                        ,pois_aa_formatted as ( -- pois with aa information
                                select mpaa.poi_id 
                                , mpaa.name as aa8_name
                                , mpaa.code aa8_code
                                , maa.feat_area/1000000 area_km2
                                , ma.value_integer population
                                , ma.value_integer/(maa.feat_area/1000000) density
                                , case
                                    when ma.value_integer > 100000 then 'urban'
                                    when ma.value_integer > 50000 and ma.value_integer/(maa.feat_area/1000000)>1200 then 'urban'
                                    when ma.value_integer > 5000 and ma.value_integer/(maa.feat_area/1000000)> 300 then 'intermediate'
                                    else 'rural'
                                end aa8_type
                                FROM (-- selects pois that are located in a single aa8; this multiplicitity happens due the pois on borders
                                        select mpaa.*
                                        FROM {schema}.mnr_poi2admin_area mpaa
                                            join (
                                                    select poi_id
                                                        FROM {schema}.mnr_poi2admin_area mpaa
                                                        where mpaa.feat_type=1119
                                                        group by 1
                                                        having count(*) = 1
                                                    ) unique_aa
                                            on mpaa.poi_id= unique_aa.poi_id
                                        where mpaa.feat_type=1119
                                        ) mpaa
                                    join pois_in_country pic on mpaa.poi_id = pic.poi_id
                                    join {schema}.mnr_admin_area maa on mpaa.admin_area_id = maa.feat_id
                                    JOIN {schema}.mnr_admin_area2attribute maaa on maaa.admin_area_id = mpaa.admin_area_id
                                    join {schema}.mnr_attribute ma on ma.attribute_id = maaa.attribute_id
                                where mpaa.feat_type=1119
                                    and ma.attribute_type = 'PO'
                        )
                        , single_name as (-- get only one stn name, not the complete set
                            select nameset_id
                                , min(name_id::text) name_id
                            from {schema}.mnr_nameset2name
                            group by nameset_id
                        )        
                        , external_ids as(--external_id from API
                                SELECT pa.poi_id , value_varchar as external_id
                                FROM {schema}.mnr_attribute a
                                join {schema}.mnr_poi2attribute as pa on a.attribute_id = pa.attribute_id
                                where attribute_type = 'EI'
                        )
                        SELECT mp.poi_id
                                    , ei.external_id
                                    , mp.country
                                    , paaf.aa8_name
                                    , paaf.aa8_code
                                    , paaf.population
                                    , paaf.density
                                    , paaf.aa8_type
                                    , mp.feat_type poi_type
                                    , mp.poi_address_id
                                    , mp.name as poi_name
                                    , mp.poi_bn as poi_brand
                                    , mn.name as streetname
                                    , mpa.hsn as housenumber
                                    , mp.email
                                    , mp.internet 
                                    , mp.telephone_num
                                    , st_astext(mp.geom) as wkt
                                    FROM pois_in_country mp
                                    left join pois_aa_formatted as paaf
                                            on mp.poi_id=paaf.poi_id
                                    left join {schema}.mnr_poi_address mpa 
                                        on mp.poi_address_id= mpa.poi_address_id
                                    left join single_name mnn
                                        on mpa.street_nameset_id = mnn.nameset_id
                                    left join {schema}.mnr_name mn
                                        on cast(mnn.name_id as uuid) = mn.name_id
                                    left join external_ids ei
                                        on ei.poi_id = mp.poi_id;""".format(schema=schema, country=country, poi_types=poi_types, limit=limit)
    return sql


def get_sample_from_mnr(provider, db, country, schema, sample_size, poi_type):
    """Makes a call to MNR and gets the amount fo cases needed for a sample.
    The information about the country, the sample size, etc comes in the item
    The information about the connection para meters comes in conn_data

    :param provider: Name of the competitor you want to sample
        go/tt/he/wb...
    :type provider: str
    :param conn_data: serie containing the data for the conection to the db
    :type conn_data: [Pandas Serie
    :param item: Serie containing the data to build the sql query. 
                Information like country, sample size, table, schema, are neeeded
    :type item: Pandas Series
    :return: Sampel from MNR with the requiered amount of cases 
    from teh requiered categories
    :rtype: Pandas Dataframe
    """

    #if CAN or USA the query must be different beucase they are calling to continent MNR

    if country in ('USA', 'CAN'):
        sql = create_sql_sample_mnr_pois_without_areas_with_external_id_one_stn_continent(schema, country, sample_size, str(poi_type))
    else:
        sql = create_sql_sample_mnr_pois_without_areas_with_external_id_one_stn_country(schema, country, sample_size, str(poi_type))
    
    df_pois = get_pois_to_check_from_mnr_db(sql, db)

    if not df_pois.empty: # means error in the query
        df_pois['feature_type'] = df_pois.poi_type.astype("int")
        df_pois['provider_id'] = provider
        df_pois = df_pois.drop(['poi_type'], axis=1)

        # check whether we have the complete sample
        sample_achieved = False
        if df_pois.shape[0] >= sample_size:
            sample_achieved = True

        if not sample_achieved:
            logging.warning("Missing POIS City: " + str(country) + " POI_type: " + str(poi_type))
            print("WARNING : missing POIS. Area: " + str(country) + " POI_type: " + str(poi_type) + ' // ' + str(df_pois.shape[0]) + ' out of ' + str(sample_size))
    else:
        logging.error("No POIS found in country: " + str(country) + " POI_type: " + str(poi_type) + ' // ' + str(df_pois.shape[0]) + ' out of ' + str(sample_size))
    return df_pois


def get_openmap_or_osm_country_schema(country: str, provider: str):
    """For an input country (acronym), returns its OSM VAD (openmap) schema

    :param country: country (3 letters acronym)
    :type country: str
    :param provider: provider to choose ("openmap" or "osm")
    :type provider: str
    :return: MNR schema, connection details, sqlalchemy engine for postgresql ddbb connection
    :rtype: str, str, str
    """

    sql_schema = """
    SELECT schema_name
    FROM information_schema.schemata"""
    if provider == "openmap":
        osm_3g_db = { 
            'host': 'vad3g-prod.openmap.maps.az.tt3.com',
            'port': 5432,
            'database': 'ggg',
            'user': 'ggg_ro',
            'password': 'ggg_ro'
        }

    elif provider == "osm":
        osm_3g_db = { 
        'host': 'tt3g-prod.openmap.maps.az.tt3.com',
        'port': 5432,
        'database': 'ggg',
        'user': 'ggg_ro',
        'password': 'ggg_ro'
    }

    engine = sqlalchemy.create_engine(f'postgresql+psycopg2://{osm_3g_db["user"]}:{osm_3g_db["password"]}@{osm_3g_db["host"]}:{osm_3g_db["port"]}/{osm_3g_db["database"]}')
    schemas = retry_read_query(sql=sql_schema, engine=engine, num_retries=4, sleep_time=2)
    schema = [s for s in schemas.schema_name if '_'+str.lower(country)+'_' in s]
    schema.sort(reverse=True)
    if schema:
        schema_str = schema[0]
        connection_str = osm_3g_db
    if not schema:
        schema_str = None
        connection_str = None
        engine = None
        print('Country ' + country + ' schema not found in OSM/Openmap (3G)')
        #logging.warning('Country ' + country + ' schema not found in OSM Public (3G)')

    return schema_str, connection_str, engine


def get_openmap_pois(category, country, num_pois, schema, connection, engine):
    """Generate sample of OSM 3G POIs

    :param category: category of the POIs
    :type category: str
    :param country: country of the POIs (ISO3)
    :type country: str
    :param num_pois: number of POIs to generate the sample
    :type num_pois: int
    :param mapping_csv: csv file with the mapping info (osm tags for each ttom category, doesn't need to be a row per category)
                    Must contain the fields: 'feature_type' (tt_category), 'feature_type_description' (category name) and 'osm_tags' (to generate the condition)
    :type mapping_csv: str
    :return: Sample of POIs
    :rtype: Pandas DataFrame
    """
    sql_cols = f"""
    SELECT column_name
    FROM information_schema.columns
    WHERE table_schema = '{schema}'
    AND table_name = 'planet_osm_point'"""

    country_columns = retry_read_query(sql=sql_cols, engine=engine, num_retries=3, sleep_time=2)

    MatFile = pkgutil.get_data(__name__, '../data/raw/poi_category_mapping.csv')
    dfreader = csv.reader(MatFile.decode('utf-8').splitlines(), delimiter=',')
    mapping_file = pd.DataFrame(data=dfreader)
    new_header = mapping_file.iloc[0] #grab the first row for the header
    mapping_file = mapping_file[1:] #take the data less the header row
    mapping_file.columns = new_header
    # filter input category
    mapping_file_filtered = mapping_file.loc[mapping_file.feature_type==category].copy()

    # make an sql condition from osm tags
    # mapping_file_filtered['condition'] = (mapping_file_filtered['osm_tags']+ ',').str.replace("=", "='").str.replace(",", "',").str[:-1].str.replace(",", " AND ")
    mapping_file_filtered['condition'] = ('"' + mapping_file_filtered['osm_tags'] + ',').str.replace("=", '"'+"='").str.replace(",", "',"+'"').str[:-2].str.replace(",", " AND ")

    # Generate a column with a list that contains the columns of the ddbb to filter
    mapping_file_filtered['condition_fields'] = mapping_file_filtered.apply(lambda row: get_columns_condition(row), axis=1)

    # Generate boolean column indicating if the columns used are contained in the table's (of that country's schema) columns
    mapping_file_filtered['use_condition'] = mapping_file_filtered.apply(lambda row: are_columns_of_schema(row, reference_list=country_columns.column_name.to_list()), axis=1)

    # Filter only rows contained
    mapping_file_filtered_true = mapping_file_filtered.loc[mapping_file_filtered.use_condition].copy()

    if mapping_file_filtered_true.empty:
        columns = ['poi_id', 'poi_brand', 'poi_brand_boolean', 'feature_type', 'country', 'use_case_name', 'use_case_brand', 'use_case_category', 
                   'poi_name', 'streetname', 'housenumber', 'wkt', 'category', 'group_category', 'lat', 'lon', 'provider_id']
        sample = pd.DataFrame(columns=columns)
    else:
        # make sql condition per category
        df_cat_condition = mapping_file_filtered_true.groupby(['feature_type','feature_type_description'])['condition'].apply(') OR ('.join).reset_index()
        df_cat_condition['condition'] = '(' + df_cat_condition['condition'] + ')'

        # condition (str) for that category
        condition = df_cat_condition['condition'][0]

        sql_sample = f"""              
        SELECT
        osm_id as poi_id,
        cntry_code as country,
        name as poi_name,
        brand as poi_brand,
        "addr:housename" as streetname,
        "addr:housenumber" as housenumber,
        st_astext(way) as wkt
        FROM {schema}.planet_osm_polygon 
        WHERE ({condition})
        AND cntry_code = '{country.upper()}'
        AND name IS NOT NULL AND name <> ''
        ORDER BY random()
        LIMIT {num_pois}"""

        sample = retry_read_query(sql=sql_sample, engine=engine, num_retries=3, sleep_time=2)

        sample['provider_id'] = 'openmap'
        #sample['category_name'] = df_cat_condition['feature_type_description'].unique()[0]
        

    if len(sample) < num_pois:
        print('Category: ' + category + ', Country: ' + country + ', Number of POIs selected is below the desired amount: ' + str(len(sample)) + ' vs ' + str(num_pois))
        #logging.warning('Category: ' + category + ', Country: ' + country + ', Number of POIs selected is below the desired amount: ' + str(len(sample)) + ' vs ' + str(num_pois))

    return sample


def get_mapping_master_table():
    """Simple function which requires an input pandas dataframe and the column name for which holds the
    coordinated in WKT format (i.e. POINt(X X)), which default value is wkt. Then it starts iterating
    and calling the from_wktpoint_to_latlon() to extract the latitude and longitude values from the WKT format
    in two separate lists.

    :param in_df: Input pandas dataframe.
    :type in_df: pd.DataFrame
    :param wkt_column: String input corresponding to the WKT format coordinates column name, defaults to "wkt"
    :type wkt_column: str, optional
    :return: Returns two lists, one for latitude and another for longitude.
    :rtype: typing.Tuple[str, str]
    """
    MatFile = pkgutil.get_data(__name__, '../data/raw/poi_category_mapping.csv')
    dfreader = csv.reader(MatFile.decode('utf-8').splitlines(), delimiter=',')
    mapping_file = pd.DataFrame(data=dfreader)
    new_header = mapping_file.iloc[0] #grab the first row for the header
    mapping_file = mapping_file[1:] #take the data less the header row
    mapping_file.columns = new_header
    return mapping_file


def from_wktpoint_to_latlon(wkt):
    """Extract from a WKT of a point, the latitude and longitude

    :param wkt: Well Known Text value of a geometry
    :type wkt: str
    :return: latitude, longitude
    :rtype: long
    """

    longitude_latitude_trans = wkt.replace('POINT(', '')
    longitude_latitude_trans = longitude_latitude_trans.replace(')', '')
    longitude_latitude_trans = longitude_latitude_trans.split()
    latitude = longitude_latitude_trans[1]
    longitude = longitude_latitude_trans[0]

    return latitude, longitude


def extract_lat_lon(in_df: pd.DataFrame, wkt_column: str = "wkt") -> typing.Tuple[str, str]:
    """Simple function which requires an input pandas dataframe and the column name for which holds the
    coordinated in WKT format (i.e. POINt(X X)), which default value is wkt. Then it starts iterating
    and calling the from_wktpoint_to_latlon() to extract the latitude and longitude values from the WKT format
    in two separate lists.

    :param in_df: Input pandas dataframe.
    :type in_df: pd.DataFrame
    :param wkt_column: String input corresponding to the WKT format coordinates column name, defaults to "wkt"
    :type wkt_column: str, optional
    :return: Returns two lists, one for latitude and another for longitude.
    :rtype: typing.Tuple[str, str]
    """
    lat_list = []
    lon_list = []
    for idx, row in in_df.iterrows():
        lat, lon = from_wktpoint_to_latlon(row[wkt_column])
        lat_list.append(lat)
        lon_list.append(lon)
    return lat_list, lon_list


def from_poi_brand_to_boolean(poi_brand: str) -> int:
    no_brand_list = ["none", "null", ""]
    if poi_brand == None:
        boolean_out = 0
    elif poi_brand.lower() in no_brand_list:
        boolean_out = 0
    else:
        boolean_out = 1
    return boolean_out



def extract_poi_brand_boolean(in_df: pd.DataFrame, brand_column: str = "poi_brand") -> list:
    """The function requires an input pandas dataframe and the column name for which holds the
    POI brand (i.e. "Volvo", "El Corte Ingles"), which default value is "poi_brand". Then it starts iterating
    and calling the from_poi_brand_to_boolean() to extract the boolean response (int: 1/0) in a list.

    :param in_df: Input pandas dataframe.
    :type in_df: pd.DataFrame
    :param brand_column: String input corresponding to the POI brand column name, defaults to "poi_brand"
    :type brand_column: str, optional
    :return: Returns a list containing the boolean responses.
    :rtype: list
    """
    boolean_list = []
    for idx, row in in_df.iterrows():
        boolean = from_poi_brand_to_boolean(row[brand_column])
        boolean_list.append(boolean)
    return boolean_list


def extract_all_tt_poi_categories_in_country(provider: str, db_connection: str, country: str, schema: str, in_df: pd.DataFrame) -> pd.DataFrame:
    """Function that encapsulates all other sub functions to extract the POIs per country per category. It requires a provider input string, either
    "tt" or "openmap", the database connection in string format which corresponds to the server name, the country which is in ISO3 format, the 
    schema which needs to be call in SQL, and finally a pandas dataframe which corresponds to the superfluous_categories_countries master table.
    The output is a pandas dataframe with the required POIs per country and extra extracted columns like "category", "group_category", "lat", "lon",
    and "poi_brand_boolean".

    :param provider: [description]
    :type provider: str
    :param db_connection: [description]
    :type db_connection: str
    :param country: [description]
    :type country: str
    :param schema: [description]
    :type schema: str
    :param in_df: Input pandas dataframe 
    :type in_df: pd.DataFrame
    :return: Returns a pandas dataframe with the required POIs per country.
    :rtype: pd.DataFrame
    """
    columns = ['poi_id', 'poi_brand', 'poi_brand_boolean','feature_type', 'country', 'use_case_name', 'use_case_brand', 'use_case_category', 
               'poi_name', 'streetname', 'housenumber', 'wkt', 'category', 'group_category', 'lat', 'lon', "provider_id"]
    out_df = pd.DataFrame(columns=columns)
    if provider == "tt":
        for idx, row in in_df.iterrows():
            if int(row[country.upper()]) > 0:
                country_category_df = get_sample_from_mnr(provider, db_connection, country, schema, int(row[country.upper()]), row["feature_type"])
                country_category_df["category"] = row["category"]
                country_category_df["group_category"] = row["group_category"]
                country_category_df["use_case_name"] = row["use_case_name"]
                country_category_df["use_case_brand"] = row["use_case_brand"]
                country_category_df["use_case_category"] = row["use_case_category"]
                lat_list, lon_list = extract_lat_lon(country_category_df)
                country_category_df["lat"] = lat_list
                country_category_df["lon"] = lon_list
                poi_brand_boolean_list = extract_poi_brand_boolean(country_category_df)
                country_category_df["poi_brand_boolean"] = poi_brand_boolean_list
                #TODO
                # To do in pyspark, and read/check if run_id exists in ADLS table
                country_category_df["provider_id"] = provider
                country_category_df = country_category_df[columns]
                out_df = pd.concat([out_df, country_category_df])
    return out_df


def extract_all_openmap_poi_categories_in_country(provider: str, db_connection: str, country: str, schema: str, in_df: pd.DataFrame, engine: sqlalchemy.engine.base.Engine) -> pd.DataFrame:
    """[summary]

    :param provider: [description]
    :type provider: str
    :param db_connection: [description]
    :type db_connection: str
    :param country: [description]
    :type country: str
    :param schema: [description]
    :type schema: str
    :param in_df: [description]
    :type in_df: pd.DataFrame
    :param engine: [description]
    :type engine: sqlalchemy.engine.base.Engine
    :return: [description]
    :rtype: pd.DataFrame
    """
    columns = ['poi_id', 'poi_brand', 'poi_brand_boolean', 'feature_type', 'country', 'use_case_name', 'use_case_brand', 'use_case_category', 
               'poi_name', 'streetname', 'housenumber', 'wkt', 'category', 'group_category', 'lat', 'lon', 'provider_id']
    out_df = pd.DataFrame(columns=columns)
    if provider == "openmap":
        for idx, row in in_df.iterrows():
            if int(row[country.upper()]) > 0:
                country_category_df = get_openmap_pois(str(row["feature_type"]), country, int(row[country.upper()]), schema, db_connection, engine)
                country_category_df["feature_type"] = row["feature_type"]
                country_category_df["category"] = row["category"]
                country_category_df["group_category"] = row["group_category"]
                country_category_df["use_case_name"] = row["use_case_name"]
                country_category_df["use_case_brand"] = row["use_case_brand"]
                country_category_df["use_case_category"] = row["use_case_category"]
                lat_list, lon_list = extract_lat_lon(country_category_df)
                country_category_df["lat"] = lat_list
                country_category_df["lon"] = lon_list
                poi_brand_boolean_list = extract_poi_brand_boolean(country_category_df)
                country_category_df["poi_brand_boolean"] = poi_brand_boolean_list
                #TODO
                # To do in pyspark, and read/check if run_id exists in ADLS table
                country_category_df["provider_id"] = provider
                country_category_df = country_category_df[columns]
                out_df = pd.concat([out_df, country_category_df])
    return out_df


def extract_all_osm_poi_categories_in_country(provider: str, db_connection: str, country: str, schema: str, in_df: pd.DataFrame, engine: sqlalchemy.engine.base.Engine) -> pd.DataFrame:
    """[summary]

    :param provider: [description]
    :type provider: str
    :param db_connection: [description]
    :type db_connection: str
    :param country: [description]
    :type country: str
    :param schema: [description]
    :type schema: str
    :param in_df: [description]
    :type in_df: pd.DataFrame
    :param engine: [description]
    :type engine: sqlalchemy.engine.base.Engine
    :return: [description]
    :rtype: pd.DataFrame
    """
    columns = ['poi_id', 'poi_brand', 'poi_brand_boolean', 'feature_type', 'country', 'use_case_name', 'use_case_brand', 'use_case_category', 
               'poi_name', 'streetname', 'housenumber', 'wkt', 'category', 'group_category', 'lat', 'lon', 'provider_id']
    out_df = pd.DataFrame(columns=columns)
    if provider == "osm":
        for idx, row in in_df.iterrows():
            if int(row[country.upper()]) > 0:
                country_category_df = get_openmap_pois(str(row["feature_type"]), country, int(row[country.upper()]), schema, db_connection, engine)
                country_category_df["feature_type"] = row["feature_type"]
                country_category_df["category"] = row["category"]
                country_category_df["group_category"] = row["group_category"]
                country_category_df["use_case_name"] = row["use_case_name"]
                country_category_df["use_case_brand"] = row["use_case_brand"]
                country_category_df["use_case_category"] = row["use_case_category"]
                lat_list, lon_list = extract_lat_lon(country_category_df)
                country_category_df["lat"] = lat_list
                country_category_df["lon"] = lon_list
                poi_brand_boolean_list = extract_poi_brand_boolean(country_category_df)
                country_category_df["poi_brand_boolean"] = poi_brand_boolean_list
                #TODO
                # To do in pyspark, and read/check if run_id exists in ADLS table
                country_category_df["provider_id"] = provider
                country_category_df = country_category_df[columns]
                out_df = pd.concat([out_df, country_category_df])
    return out_df


def superfluous_sampling(provider: str, country: str = None) -> pd.DataFrame:
    """[summary]

    :param provider: [description]
    :type provider: str
    :param country: [description], defaults to None
    :type country: str, optional
    :return: [description]
    :rtype: pd.DataFrame
    """
    columns = ['poi_id', 'poi_brand', 'poi_brand_boolean', 'feature_type', 'country', 'use_case_name', 'use_case_brand', 'use_case_category', 
               'poi_name', 'streetname', 'housenumber', 'wkt', 'category', 'group_category', 'lat', 'lon', 'provider_id']
    out_df = pd.DataFrame(columns=columns)
    #superfluous_categories_master_path = '../data/raw/superfluous_categories_countries_master.csv'
    superfluous_categories_master_path = '../data/raw/poc_superfluous_categories_countries_master.csv'
    MatFile = pkgutil.get_data(__name__, superfluous_categories_master_path)
    dfreader = csv.reader(MatFile.decode('utf-8').splitlines(), delimiter=';')
    df = pd.DataFrame(data=dfreader)
    new_header = df.iloc[0] #grab the first row for the header
    df = df[1:] #take the data less the header row
    df.columns = new_header
    # Do all countries in df if country == None
    if country != None:
        if provider == "tt":
            db_connection = get_mnr_server_for_country(country)
            schema = get_mnr_schema(country, db_connection)
            country_df = df[['category', 'group_category','feature_type', 'use_case_name', 'use_case_brand', 'use_case_category', country.upper()]]
            out_df = extract_all_tt_poi_categories_in_country(provider, db_connection, country, schema, country_df)
            out_df["map_version"] = get_map_version("tt")
        elif provider == "openmap":
            schema, db_connection, engine = get_openmap_or_osm_country_schema(country, provider)
            country_df = df[['category', 'group_category','feature_type', 'use_case_name', 'use_case_brand', 'use_case_category', country.upper()]]
            out_df = extract_all_openmap_poi_categories_in_country(provider, db_connection, country, schema, country_df, engine)
            out_df["map_version"] = get_map_version("openmap")
        elif provider == "osm":
            schema, db_connection, engine = get_openmap_or_osm_country_schema(country, provider)
            country_df = df[['category', 'group_category','feature_type', 'use_case_name', 'use_case_brand', 'use_case_category', country.upper()]]
            out_df = extract_all_osm_poi_categories_in_country(provider, db_connection, country, schema, country_df, engine)
            out_df["map_version"] = None
    return out_df

