import pandas as pd
import numpy as np
import geopandas as gpd
import shapely
import typing
from functools import reduce 
from pyspark.sql import DataFrame
import pkg_resources


osm_tags = ['osm_id','access','addr:housename','addr:housenumber','addr:interpolation','admin_level','aerialway','aeroway','amenity','area',
            'barrier','bicycle','brand','bridge','boundary','building','capital','construction','covered','culvert','cutting','denomination','disused',
            'ele','embankment','foot','generator:source','harbour','highway','historic','horse','intermittent','junction','landuse','layer','leisure','lock',
            'man_made','military','motorcar','name','natural','office','oneway','operator','place','population','power','power_source','public_transport',
            'railway','ref','religion','route','service','shop','sport','surface','toll','tourism','tower:type','tunnel','water','waterway','wetland','width',
            'wood','z_order','tags','text(node.way) geom','reg_code','region','cntry_code','state_code','state','county','city','mqs']

def unionAll(*dfs:DataFrame) -> DataFrame:
    return reduce(DataFrame.unionAll, dfs)


def convert_poi_to_query(x:pd.DataFrame) -> str:
    """Takes a coordinates geoseries and converts it into a string to build a query in Postgres
    
    :param x: coordinates
    :type x: geopandas.GeoSeries
    :return: string to build a spatial query (table) 
    :rtype: str
    """
    
    # Create index for each address and convert coordinates to WKT
    values = list(zip(x.index.tolist(), x.coordinates.to_wkt(), x.category_id_tt))
    values_str = ','.join([str(value) for value in values])
    
    return  "(VALUES " + values_str + ")"


def convert_coordinates_to_query(x:gpd.GeoSeries) -> str:
    """Takes a coordinates geoseries and converts it into a string to build a query in Postgres
    
    :param x: coordinates
    :type x: geopandas.GeoSeries
    :return: string to build a spatial query (table) 
    :rtype: str
    """
    
    # Create index for each address and convert coordinates to WKT
    values = list(zip(x.index.tolist(), x.to_wkt()))
    values_str = ','.join([str(value) for value in values])
    
    return  "(VALUES " + values_str + ")"


def convert_to_coordinates(lat:float, lon:float) -> shapely.geometry.point.Point:
    """UDF that converts a pair of latitude and longitude to a shapely geometry Point object 
    :param lat: latitude
    :type lat: float
    :param lon: longitude
    :type lon: float
    :return: the Well Known Text (WKT) of the shapely geometry object
    :rtype: shapely.geometry.point.Point
    """

    try:
      return shapely.geometry.Point(float(lon), float(lat)).wkt  
    except Exception:
      return shapely.geometry.Point(999, 999).wkt


def radius_buffer_call(input_df:pd.DataFrame, pbf_df:gpd.GeoDataFrame or pd.DataFrame, radius:int or float) -> typing.Tuple[pd.DataFrame, pd.DataFrame]:
    """Finds APTs in Openmap PBF at a given radius
    :param df: DataFrame containing sample addresses with reference coordinates in a column named 'coordinates'
    :type df: pd.DataFrame
    :param pbf_df: DataFrame containing nodes and ways of APT type for the country. Contains column 'provider_coordinates'
    :type pbf_df: gpd.GeoDataFrame or pd.DataFrame
    :param libpostal_df: libpostal containing the address components of the sample addresses in 'df'. Used for matching
    :type libpostal_df: pd.DataFrame
    :param radius: radius in which APTs from the PBF will be returned
    :type radius: int or float
    :param stopwords_pattern: regex pattern to remove stopwords, if needed. Optional, defaults to None
    :type stopwords_pattern: str
    :return: tuple of DataFrames, first one for the matched APTs and second one for all APTS returned by the PBF
    :rtype: typing.Tuple[pd.DataFrame, pd.DataFrame]
    """
    
    input_df = input_df.copy()
    input_df['coordinates'] = pbf_df.apply(lambda x: shapely.geometry.Point(x.longitude, x.latitude), axis=1)
    # Convert to GPD and set projection
    input_df = gpd.GeoDataFrame(input_df, geometry='coordinates')
    #input_df['provider_coordinates'] = input_df['coordinates'].set_crs('EPSG:4326')


    # Merge to original DF
    #pbf_df = pbf_df.merge(openmapDF_apts_tags, on='id').reset_index(drop=True)
    pbf_df['provider_coordinates'] = pbf_df.apply(lambda x: shapely.geometry.Point(x.longitude, x.latitude), axis=1)


    # Convert to GPD and set projection
    pbf_gdf = gpd.GeoDataFrame(pbf_df, geometry='provider_coordinates')
    pbf_gdf['provider_coordinates'] = pbf_gdf['provider_coordinates'].set_crs('EPSG:4326')

    #input_df = input_df.copy()
    #Create buffer
    input_df['buffers'] = input_df.coordinates.set_crs('EPSG:4326').to_crs("EPSG:3857").buffer(radius).to_crs('EPSG:4326')
    input_df = input_df.drop(columns='coordinates')


    # Ensure geometry column is buffers
    input_df = gpd.GeoDataFrame(input_df, geometry='buffers')
    
    
    # Ensure PBF is GeoDataFrame and on the same projection
    #pbf_gdf = gpd.GeoDataFrame(pbf_df, geometry='provider_coordinates')
    #pbf_gdf['provider_coordinates'] = pbf_gdf.provider_coordinates.set_crs('EPSG:4326')
    
    
    # Perform spatial join
    out_df = gpd.sjoin(input_df, pbf_gdf, how='left', predicate='intersects')

    out_df = out_df.loc[~out_df.latitude.isna()].reset_index(drop=True)
    return out_df
  
  
def get_numeric_house_number_column(x:pd.Series) -> typing.List[str]:
    """Extracts the numeric component of a house number

    :param x: column containing house numbers
    :type x: pd.Series
    :return: list containing the parsed housenumbers
    :rtype: typing.List[str]
    """
    numeric_component = x.str.extract('(\d+)[^\d]*(\d+)?', expand=False).fillna('')
    return [' '.join(j).strip() for j in numeric_component.values.tolist()]


def create_mapping_conditions(x:pd.Series) -> typing.List[str]:
    """Returns a SQL valid way to query the tags column of a PBF

    :param x: Series containing the mapping (key, value) 
    :type x: pd.Series
    :return: string containing the way to query an hstore
    :rtype: typing.List[str]
    """
    query_mapping = []
    
    for cond in x:
        if len(cond) == 2:
            if cond[1] != '*':
                query_mapping.append("(tags->'{key}' = '{value}')".format(key=cond[0], value=cond[1]))
            else:
                query_mapping.append("(tags->'{key}' <> '')".format(key=cond[0]))
    
    return query_mapping


def create_mapping_sql(x:pd.Series) -> typing.List[str]:
    """Creates mapping in 'case when' form for querying the available fields in OSM databases

    :param x: Series containing the mapping (key, value) 
    :type x: pd.Series
    :return:string containing the way to query the fields from the 3G DBs
    :rtype: typing.List[str]
    """
    query_conditions = []
    
    for cond in x:
        if cond[0] in osm_tags and cond[1] != '*':
            query_conditions.append('("{}"=\'{}\')'.format(cond[0], cond[1]))
        elif cond[0] in osm_tags and cond[1] == '*':
            query_conditions.append('("{}"<>\'\')'.format(cond[0]))
    
    return query_conditions


def generate_pois_mapping_osm(path:str, tag_column:str='om_filter_tags', category_column:str='category_code') -> pd.DataFrame:
    """Creates the mapping from OSM categories to equivalent TT one

    :param path: internal path in package where the mapping csv is stored
    :type path: str
    :param tag_column: column indicating the conversion from the tags in OSM to the corresponding category in TT
    :type tag_column: str
    :param category_column: column indicating the category of a POI in TT
    :type category_column: str
    :return: DataFrame containinng the parsing for queries in SQL
    :rtype: pd.DataFrame
    """
    
    # Read and normalize data
    DB_FILE = pkg_resources.resource_filename(__name__, path)
    poi_mapping_table = pd.read_csv(DB_FILE)
    poi_mapping_table['om_filter_tags'] = poi_mapping_table[tag_column]
    poi_mapping_table['category_code'] = poi_mapping_table[category_column]
    
    
    # Filter categories not existing
    poi_mapping_table = poi_mapping_table.loc[~(poi_mapping_table.om_filter_tags.isna())].reset_index(drop=True)
    poi_mapping_table = poi_mapping_table.loc[~poi_mapping_table.om_filter_tags.str.contains('not.*mappable', case=False, regex=True)].reset_index(drop=True)
    poi_mapping_table['om_filter_tags'] = poi_mapping_table.om_filter_tags.str.replace(' AND ', ',', case=False, regex=False)
    poi_mapping_table['om_filter_tags_list'] = poi_mapping_table.om_filter_tags.apply(lambda x: x.split(','))


    # Add logic to each row
    poi_mapping_table['om_filter_tags_list'] =  poi_mapping_table.om_filter_tags_list.apply(lambda x: list(set(x)))
    poi_mapping_table['conditions'] = poi_mapping_table.om_filter_tags_list.apply(lambda x: [cond.split('=') for cond in x])
    poi_mapping_table['condition_case_when'] = poi_mapping_table.conditions.apply(create_mapping_conditions)
    poi_mapping_table['sql_mapping'] = poi_mapping_table.conditions.apply(create_mapping_sql)
    poi_mapping_table['sql_mapping_condition'] = poi_mapping_table.sql_mapping.apply(lambda x: ' and '.join(x))
    poi_mapping_table['sql_tags_condition'] = poi_mapping_table.condition_case_when.apply(lambda x: ' and '.join(x))
    poi_mapping_table['row_condition'] = '(' + poi_mapping_table.sql_tags_condition + np.where(poi_mapping_table.sql_mapping_condition != '',
                                                                                        ' or ' + poi_mapping_table.sql_mapping_condition, '') + ')'

    # Group by category
    poi_categories_df = poi_mapping_table.groupby('category_code')['row_condition'].agg(lambda x: list(x)).reset_index()
    poi_categories_df['row_condition'] = poi_categories_df.row_condition.apply(lambda x: ' or '.join(x))
    poi_categories_df['category_code'] = poi_categories_df.category_code.astype(str)
    
    
    return poi_categories_df