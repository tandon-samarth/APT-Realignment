from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType, MapType
from pyspark.sql import SparkSession
from pyspark.sql import DataFrame as SparkDataFrame
import typing

    
def create_df_from_list(in_list: typing.List, schema_type: str) -> SparkDataFrame:
    """Creates a Pyspark DataFrame with the results of each API call

    :param in_list: List with the results of each API call
    :type in_list: typing.List[str]
    :param schema_type: Type of the schema: arp_reference, arp_results
    :type schema_type: str
    :return: Pyspark DataFrame with the API call results
    :rtype: SparkDataFrame
    """
    if schema_type == "map_content_poi_source":
        fields = [StructField("poi_id", StringType(),True),
                StructField("poi_type", StringType(),True),
                StructField("poi_name", StringType(),True),
                StructField("poi_brand", StringType(),True),
                StructField("poi_lat", FloatType(),True),
                StructField("poi_lon", FloatType(),True),
                StructField("poi_provider_id", StringType(),True),
                StructField("poi_map_version", StringType(),True),
                StructField("ref_api1_run_id", StringType(),True),
                StructField("ref_provider_id", StringType(),True),
                StructField("ref_lat", FloatType(),True),
                StructField("ref_lon", FloatType(),True),
                StructField("ref_brand", StringType(),True),
                StructField("ref_poi_brand_boolean", StringType(),True),
                StructField("reference_id", StringType(),True),
                StructField("ref_country", StringType(),True),
                StructField("ref_name", StringType(),True),
                StructField("ref_category_name", StringType(),True),
                StructField("ref_category_name_tt", StringType(),True),
                StructField("ref_business_status", StringType(),True),
                StructField("ref_feature_type", IntegerType(),True),
                StructField("source_run_id", StringType(),True)
                ]
    
    elif schema_type == "map_content_poi_matching":
        fields = [StructField("poi_id", StringType(),True),
                StructField("poi_type", StringType(),True),
                StructField("poi_name", StringType(),True),
                StructField("poi_brand", StringType(),True),
                StructField("poi_provider_id", StringType(),True),
                StructField("poi_map_version", StringType(),True),
                StructField("ref_api1_run_id", StringType(),True),
                StructField("ref_provider_id", StringType(),True),
                StructField("ref_brand", StringType(),True),
                StructField("reference_id", StringType(),True),
                StructField("ref_country", StringType(),True),
                StructField("ref_name", StringType(),True),
                StructField("ref_category_name", StringType(),True),
                StructField("ref_category_name_tt", StringType(),True),
                StructField("ref_feature_type", IntegerType(),True),
                StructField("source_run_id", StringType(),True),
                StructField("name_matching", IntegerType(),True),
                StructField("brand_matching", IntegerType(),True),
                StructField("category_matching", IntegerType(),True),
                StructField("location_distance_m", FloatType(),True),
                StructField("distance_matching", IntegerType(),True),
                StructField("matching_run_id", StringType(),True),
                StructField("ref_use_case", StringType(),True),
                StructField("match_code", IntegerType(),True),
                StructField("metric", StringType(),True)
                ]
    
    elif schema_type == "map_content_results":
        fields = [StructField("matching_run_id", StringType(),True),
                StructField("poi_provider_id", StringType(),True),
                StructField("category_name", StringType(),True),
                StructField("category_id_tt", StringType(),True),
                StructField("country", StringType(),True),
                StructField("size", IntegerType(),True),
                StructField("variable", StringType(),True),
                StructField("interval_mean", StringType(),True),
                StructField("moe_90", StringType(),True),
                StructField("metric", StringType(),True),
                StructField("category_representative", StringType(),True)
                ]

    else:
        return None

    schema = StructType(fields)
    spark = SparkSession.builder.getOrCreate()
    try:
        output_df = spark.createDataFrame(in_list, schema)
        return output_df
    except TypeError as err:
        print(f"Error converting list to spark dataframe: {err}")
        return None