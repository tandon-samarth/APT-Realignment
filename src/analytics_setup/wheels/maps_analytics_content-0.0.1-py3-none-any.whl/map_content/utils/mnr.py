import pandas as pd
import numpy as np 
import country_converter
import geopandas as gpd
import shapely
from addressing.utils import dbconnection
import typing
from addressing.automatic_matching import automatic_matching
from addressing.automatic_matching.rooftop.rooftop import haversine_distance
from fuzzywuzzy import fuzz
import unidecode
import re
from rapidfuzz import process
from rapidfuzz.fuzz import token_set_ratio
from map_content.utils import utils


def convert_coordinates_to_query(x:gpd.GeoSeries) -> str:
    """Takes a coordinates geoseries and converts it into a string to build a query in Postgres
    
    :param x: coordinates
    :type x: geopandas.GeoSeries
    :return: string to build a spatial query (table) 
    :rtype: str
    """
    
    # Create index for each address and convert coordinates to WKT
    values = list(zip(x.index.tolist(), x.to_wkt()))
    values_str = ','.join([str(value) for value in values])
    
    return  "(VALUES " + values_str + ")"


def find_country_schemas(country:str, latest:bool or None=True) -> pd.DataFrame:
    """Find the database and schemas to query in MNR
    
    :param country: country code in ISO2 or ISO3
    :type country: str
    :param latest: boolean or None indicating whether to return the latest version of MNR, defaults to True
    :type latest: bool or None, optional
    :return: DataFrame with the relevant country schemas
    :rtype: pd.DataFrame
    """
    
    
    # Standarize country input to ISO3
    country_iso3 = country_converter.convert(country, to='ISO3')

    # Query MNR databases to get where the database and schema we need to query are 
    sections = ['eur-cas-mnr', 'lam-mea-nam-oce-sea-mnr']
    schemas_df = pd.DataFrame()
    
    # Loop over MNR databases and retrieve schemas
    for section in sections:
        _, conn = dbconnection.connect('../sql/database.ini', section)
        schema = pd.read_sql('SELECT nspname FROM pg_catalog.pg_namespace', 
                                conn)
        
        schema['db'] = section
        conn.close()
        
        # Add to schema dataframe
        schemas_df = pd.concat([schemas_df, schema], ignore_index=True)
        
    # Filter relevant country
    country_schemas = (schemas_df
                    .loc[schemas_df.nspname.str.contains('_'+country_iso3+'_', 
                                                            case=False)]
                    .reset_index(drop=True)
                    )

    country_schemas['date'] = country_schemas.nspname.str[0:13]
    country_schemas['schema'] = country_schemas.nspname.str[13:]
    country_schemas['is_latest'] = country_schemas.date==country_schemas.groupby('schema').date.max()[0]
    
    
    # Fix dates to real format
    country_schemas['date'] = country_schemas.date.str[1:-1].str.replace('_', '.') + '_00'


    # Return schemas
    if latest:
        return country_schemas.loc[country_schemas.is_latest==latest].reset_index(drop=True)
    else:
        return country_schemas


def lookup_by_coordinates(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, 
                          radius:int or float=50, inner_radius:int or float=0) -> pd.DataFrame:
    """Performs spatial queries of a list of coordinates in MNR to get the APTs near the addresses
    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the addresses to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param radius: radius in meters to look around the coordinates to retrieve the nearby APTs,  defaults to 50
    :type radius: int or float, optional
    :param inner_radius: radius in meters of a smaller buffer. When bigger than zero, we are essentially getting the point in a disk, defaults to 0
    :type inner_radius: int or float, optional
    :return: APTs in MNR near the coordinates
    :rtype: gpd.DataFrame
    """


    # Create query for addresses to reverse lookup
    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                         from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    
    
    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', row.db)
        
        
        # Create query for spatial query in MNR database
        query_buffers = """
        with sample as ({query_coordinates})
        
        , buffers as (
        select  
            sample.index_searched_query
            , sample.coordinates
            , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
        from sample
        )     
        
            
        , apt as (                   
        select 
            '{mnr_version}' as version_checked
        ,	case when n."name" is null then concat(p2.hsn, ', ', p2.street_name, ', ', p2.place_name, ', ', p2.postal_code, ', ', p2.country)
                else concat(p2.hsn, ', ', p2.street_name, ', ', n."name", ', ', p2.place_name, ', ', p2.postal_code, ', ', p2.country)
                end as address
        ,	p2.hsn
        ,	p2.street_name
        ,	p2.place_name
        ,	n.name
        ,	p2.postal_code
        ,	p2.country
        ,	p2.geom
        from
            
        (
        select p1.*, n."name" as place_name
            from
            (
        select apt.feat_id, hsn.hsn, n."name" as street_name, ad.place_name_id, pp.postal_code, pp.country, apt.geom, dependent_locality_id
            from "{schema}".mnr_apt as apt
            join buffers on ST_Intersects(buffers.buffer, apt.geom)
            join "{schema}".mnr_apt2addressset as a2a on apt.feat_id = a2a.apt_id
            join "{schema}".mnr_addressset as ads on a2a.addressset_id = ads.addressset_id
            join "{schema}".mnr_address as ad on ads.addressset_id = ad.addressset_id
            join "{schema}".mnr_hsn as hsn on ad.house_number_id = hsn.hsn_id
            left join "{schema}".mnr_postal_point as pp on ad.postal_code_id = pp.feat_id
            left join "{schema}".mnr_name as n on ad.street_name_id = n.name_id
            --where apt.feat_id in ('8de23f2d-cbcb-4628-baa1-a6b8dc4489df')
            ) as p1
        left join "{schema}".mnr_name as n 
            on p1.place_name_id = n.name_id
            ) as p2
        
        left join "{schema}".mnr_name as n on p2.dependent_locality_id = n.name_id
        )

        select 
            buffers.index_searched_query
        ,   buffers.coordinates
        ,   st_astext(buffers.buffer) buffer
        ,   apt.version_checked
        ,   apt.address
        ,   apt.hsn
        ,   apt.street_name
        ,   apt.place_name
        ,   apt.name
        ,   apt.postal_code
        ,   apt.country
        ,   st_astext(apt.geom) geom
        from buffers 
        join apt on 
            ST_Intersects(buffers.buffer, apt.geom)
        
        where 
        	floor(ST_Distance(apt.geom, buffers.coordinates, true)) >= {inner_radius} 
        """.format(mnr_version = row.date,
                   query_coordinates = query_coordinates,
                   schema = row.nspname,
                   radius = radius,
                   inner_radius=inner_radius)


        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_buffers, conn, geom_col='coordinates')
        spatial_query_result['buffer'] = gpd.GeoSeries.from_wkt(spatial_query_result['buffer'])
        spatial_query_result['geom'] = gpd.GeoSeries.from_wkt(spatial_query_result['geom'])


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
    

    return gpd.GeoDataFrame(lookup_df)


def lookup_address_ranges(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, radius:int or float=50) -> pd.DataFrame:
    """Searches for house number ranges in MNR given coordinates

    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the addresses to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param radius: radius in meters to look around the coordinates to retrieve the nearby APTs, defaults to 50
    :type radius: int or float, optional
    :return: APTs in MNR near the coordinates
    :rtype: gpd.DataFrame
    """
    
    # Create query for addresses to reverse lookup
    query_coordinates =  """select index_searched_query
    ,  st_geomfromtext (coordinates, 4326)  coordinates 
    from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    

    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', row.db)
        
    
        # Create query for spatial query in MNR database
        query_hsn_ranges = """
        with sample as ({query_coordinates})

        , buffers as (
        select  
            sample.index_searched_query
            , sample.coordinates
            , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
        from sample
        ) 

        , hnr as (select
            mnr_netw_route_link.feat_id as netw_id,
            mnr_netw_route_link.name::text as pri_name,
            pp.postal_code,
            mnr_locality.locality,
            mnr_locality.country,
            mnr_netw_geo_link.geom,
            case min(hsn_variance) filter (where mnr_netw2hsn_range.line_side in (1, 2))
                when 2 then 'Even'
                when 3 then 'Odd'
                when 4 then 'Numeric Mixed'
                when 5 then 'Irregular'
                when 6 then 'Alphabetic'
            end as left_variance,
            min(hsn) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 1) as left_first,
            bool_and(interpolated) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 1) as left_first_interpolated,
            array_agg(hsn::text order by seq_num) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 3) as left_intermediates,
            --string_agg(hsn::text, ';' order by seq_num) filter (where line_side in (1, 2) and hsn_type = 3) as left_intermediates,
            min(hsn) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 2) as left_last,
            bool_and(interpolated) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 2) as left_last_interpolated,

            case min(hsn_variance) filter (where mnr_netw2hsn_range.line_side in (1, 3))
                when 2 then 'Even'
                when 3 then 'Odd'
                when 4 then 'Numeric Mixed'
                when 5 then 'Irregular'
                when 6 then 'Alphabetic'
            end as right_variance,
            min(hsn) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 1) as right_first,
            bool_and(interpolated) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 1) as right_first_interpolated,
            array_agg(hsn::text order by seq_num) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 3) as right_intermediates,
            --string_agg(hsn::text, ';' order by seq_num) filter (where line_side in (1, 3) and hsn_type = 3) as right_intermediates,
            min(hsn) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 2) as right_last,
            bool_and(interpolated) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 2) as right_last_interpolated

            from
            "{schema}".mnr_netw_route_link as mnr_netw_route_link

            inner join "{schema}".mnr_netw2hsn_range as mnr_netw2hsn_range on mnr_netw2hsn_range.netw_id = mnr_netw_route_link.feat_id

            join "{schema}".mnr_netw_geo_link mnr_netw_geo_link on mnr_netw_geo_link.feat_id = mnr_netw_route_link.netw_geo_id

            join buffers on ST_Intersects(buffers.buffer, mnr_netw_geo_link.geom)

            inner join "{schema}".mnr_hsn_range as mnr_hsn_range using (hsn_range_id)

            inner join "{schema}".mnr_hsn_range2hsn as mnr_hsn_range2hsn using (hsn_range_id)

            inner join "{schema}".mnr_hsn as mnr_hsn using (hsn_id)

            left join "{schema}".mnr_netw2postal_point as mnr_netw2postal_point 
                on mnr_netw2postal_point.netw_id = mnr_netw2hsn_range.netw_id
                and mnr_netw2postal_point.line_side = mnr_netw2hsn_range.line_side

            left join "{schema}".mnr_postal_point pp 
                on pp.feat_id = mnr_netw2postal_point.postal_point_id

            left join "{schema}".mnr_netw2locality mnr_netw2locality 
                on mnr_netw2locality.netw_id = mnr_netw2hsn_range.netw_id
                and mnr_netw2locality.ranking = 1
                
            left join "{schema}".mnr_locality mnr_locality
                on mnr_locality.feat_id = mnr_netw2locality.locality_id
                

            group by mnr_netw_route_link.feat_id,
            mnr_netw_route_link,
            mnr_netw_geo_link.geom,
            pp.postal_code,
            mnr_locality.locality,
            mnr_locality.country
            )
            
        select 
                buffers.index_searched_query
            ,   buffers.coordinates
            ,   st_astext(buffers.buffer) buffer
            ,  '{mnr_version}' as version_checked
            ,   hnr.left_variance
            ,   hnr.left_first
            ,   hnr.left_first_interpolated
            ,   hnr.left_intermediates
            ,   hnr.left_last
            ,   hnr.left_last_interpolated
            ,   hnr.right_variance
            ,   hnr.right_first
            ,   hnr.right_first_interpolated
            ,   hnr.right_intermediates
            ,   hnr.right_last
            ,   hnr.right_last_interpolated
            ,   hnr.pri_name as street_name
            ,   hnr.locality as place_name
            ,   hnr.postal_code
            ,   hnr.country
            ,   st_astext(hnr.geom) geom
            from buffers 
            join hnr on 
                ST_Intersects(buffers.buffer, hnr.geom)""".format(mnr_version = row.date,
                                                                  query_coordinates = query_coordinates,
                                                                  schema = row.nspname,
                                                                  radius = radius)
        
        
        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_hsn_ranges, conn, geom_col='coordinates')
        spatial_query_result['buffer'] = gpd.GeoSeries.from_wkt(spatial_query_result['buffer'])
        spatial_query_result['geom'] = gpd.GeoSeries.from_wkt(spatial_query_result['geom'])


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
    
    return gpd.GeoDataFrame(lookup_df)


def lookup_address_components(coordinates:gpd.GeoSeries,  schemas:pd.DataFrame=None):
    """Looks up the address components in MNR

    :param coordinates: series indicating the coordinates as a geoseries
    :type coordinates: gpd.GeoSeries
    :param schemas: DataFrame containing the schemas, defaults to None
    :type schemas: pd.DataFrame, optional
    :return: DataFrame containing responses by locality, postal code and road name
    :rtype: pd.DataFrame
    """
    
    
    # Create query for addresses to reverse lookup
    query_coordinates =  """select index_searched_query
    ,  st_geomfromtext (coordinates, 4326)  coordinates 
    from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"


    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()

        # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', row.db)

        query_components = """with sample as ({query_coordinates})

         , sample_road as (
        select 
            sample.index_searched_query
        ,	sample.coordinates
        ,	array_agg(distinct road.road_names) road_name
        ,   array_agg(distinct road.feat_id) road_id
        
        from sample 

        left join  lateral(
            select  netw.name, geo.geom, netw.feat_id, name.name road_names
            from {schema}.mnr_netw_geo_link geo 
            join  {schema}.mnr_netw_route_link netw on netw.feat_id = geo.feat_id
            join {schema}.mnr_netw2nameset netw2nameset on netw2nameset.netw_id = netw.feat_id
            join {schema}.mnr_nameset2name nameset2name on nameset2name.nameset_id = netw2nameset.nameset_id
            join {schema}.mnr_name name on name.name_id = nameset2name.name_id
            where geo.ft_road_element = true 
            and netw.name is not null
            ORDER BY geo.geom <-> sample.coordinates
            limit 25
                        ) road 
            on true 

        group by
            sample.index_searched_query
        ,	sample.coordinates
        )

        select 
            sample.index_searched_query
        ,	sample.coordinates
        ,	postcode.postal_code
        ,	road_name
        ,   '{mnr_version}' as version_checked
        ,	array_agg(pp.postal_code_extended) postal_code_extended
        ,   aa0.names as country_name
        ,	aa1.names as admin_area_1
        ,	aa2.names as admin_area_2
        ,	state.names as admin_area_8_name
        ,	state.city_center_names as admin_area_8_cc_name
        ,	city.names as admin_area_9_name
        ,	city.city_center_names as admin_area_9_cc_name
        ,   loc.localities
        from sample_road sample 

        left outer join {schema}.mnr_postal_district postcode
            on ST_Intersects(postcode.geom, sample.coordinates)

        left join lateral (
                        SELECT postal_code postal_code_extended
                        FROM {schema}.mnr_postal_point mpp 
                        ORDER BY mpp.geom <-> sample.coordinates

                        LIMIT 10
                        ) AS pp
        on true


        left outer join (
                select 
                    aa.geom
                ,   aa.feat_id 
                ,   array_agg(distinct n.name) as names
                from {schema}.mnr_admin_area aa

                left join {schema}.mnr_admin_area2nameset maan 
                    on maan.admin_area_id = aa.feat_id

                left join {schema}.mnr_nameset2name mnn 
                    on mnn.nameset_id = maan.nameset_id

                left join {schema}.mnr_name n
                    on n.name_id = mnn.name_id

                where aa.feat_type = 1111

                group by 
                    aa.geom
                ,   aa.feat_id 
                ) aa0
        on ST_Intersects(aa0.geom, sample.coordinates)


        left outer join (
                        select 
                            aa.geom
                        ,   aa.feat_id 
                        ,   array_agg(distinct n.name) as names
                        from {schema}.mnr_admin_area aa
                        
                        left join {schema}.mnr_admin_area2nameset maan 
                            on maan.admin_area_id = aa.feat_id
				
                        left join {schema}.mnr_nameset2name mnn 
                            on mnn.nameset_id = maan.nameset_id

                        left join {schema}.mnr_name n
                            on n.name_id = mnn.name_id
                        
                        where aa.feat_type = 1112 
                        
                        group by 
                            aa.geom
                        ,   aa.feat_id 
                        ) aa1
        on ST_Intersects(aa1.geom, sample.coordinates)

        
        left outer join (
        select 
            aa.geom
        ,   aa.feat_id 
        ,   array_agg(distinct n.name) as names
        from "{schema}".mnr_admin_area aa
        
        left join {schema}.mnr_admin_area2nameset maan 
            on maan.admin_area_id = aa.feat_id

        left join {schema}.mnr_nameset2name mnn 
            on mnn.nameset_id = maan.nameset_id

        left join {schema}.mnr_name n
            on n.name_id = mnn.name_id

        
        where aa.feat_type = 1118
        
        group by 
            aa.geom
        ,   aa.feat_id 
        ) aa2 
            on ST_Intersects(aa2.geom, sample.coordinates)
        
            
        left outer join (select 
                        	aa.geom
                        ,	aa.feat_id
                        ,	array_agg(distinct n.name) as names
                        ,	array_agg(distinct name_cc.name) as  city_center_names
                        from {schema}.mnr_admin_area aa

                        left join {schema}.mnr_admin_area2nameset maan 
                            on maan.admin_area_id = aa.feat_id

                        left join {schema}.mnr_nameset2name mnn 
                            on mnn.nameset_id = maan.nameset_id

                        left join {schema}.mnr_name n
                            on n.name_id = mnn.name_id

                        left join {schema}.mnr_citycenter2nameset mcn 
                            on mcn.citycenter_id = aa.citycenter_id

                        left join {schema}.mnr_nameset2name nameset_cc
                            on nameset_cc.nameset_id = mcn.nameset_id

                        left join {schema}.mnr_name name_cc
                            on name_cc.name_id = nameset_cc.name_id	
                        
                        where aa.feat_type = 1119
                        
                        group by 
                            aa.geom
                        ,	aa.feat_id
                        
                        ) state 
            on ST_Intersects(state.geom, sample.coordinates)
            
            
        left outer join (
                        select 
                        	aa.geom
                        ,	aa.feat_id
                        ,	array_agg(distinct n.name) as names
                        ,	array_agg(distinct name_cc.name) as  city_center_names
                        from {schema}.mnr_admin_area aa

                        left join {schema}.mnr_admin_area2nameset maan 
                            on maan.admin_area_id = aa.feat_id

                        left join {schema}.mnr_nameset2name mnn 
                            on mnn.nameset_id = maan.nameset_id

                        left join {schema}.mnr_name n
                            on n.name_id = mnn.name_id

                        left join {schema}.mnr_citycenter2nameset mcn 
                            on mcn.citycenter_id = aa.citycenter_id

                        left join {schema}.mnr_nameset2name nameset_cc
                            on nameset_cc.nameset_id = mcn.nameset_id

                        left join {schema}.mnr_name name_cc
                            on name_cc.name_id = nameset_cc.name_id	
                        
                        where aa.feat_type = 1120 
                        
                        group by 
                            aa.geom
                        ,	aa.feat_id
        ) city 
            on ST_Intersects(city.geom, sample.coordinates)


        left outer join (
        select 
            sample_road.index_searched_query
        ,	array_agg(distinct n.name) as localities
        from {schema}.mnr_netw2locality mnl 

        inner join sample_road on sample_road.road_id[1] = mnl.netw_id

        left join {schema}.mnr_locality locality on locality.feat_id = mnl.locality_id
        
        left join {schema}.mnr_locality2nameset mln  on mln.locality_id = locality.feat_id
	
        left join {schema}.mnr_nameset2name mnn  on mln.nameset_id = mnn.nameset_id

        left join {schema}.mnr_name n on n.name_id = mnn.name_id

        where locality.citycenter_id is not null

        group by 
                sample_road.index_searched_query

        ) loc 
        on loc.index_searched_query = sample.index_searched_query


            
        group by 
            sample.index_searched_query
        ,	sample.coordinates
        ,	sample.road_name
        ,	postcode.geom
        ,	postcode.postal_code
        ,	state.names
        ,	state.city_center_names
        ,	city.names
        ,   aa0.names
        ,	aa1.names
        ,	aa2.names
        ,	city.city_center_names
        ,   loc.localities""".format(mnr_version = row.date,
                                            query_coordinates = query_coordinates,
                                            schema = row.nspname)


        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_components, conn, geom_col='coordinates')

        
            # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
    
    return gpd.GeoDataFrame(lookup_df)

    
def left_hnr(x:pd.Series) -> typing.List[str]:
    """Returns an array of house number ranges on the left side

    :param x: a row of the result of querying the address range lookup
    :type x: pd.Series
    :return: list containing the range of house numbers
    :rtype: typing.List[str]
    """
    if x.left_variance is None:
        return []
    elif x.left_intermediates is None:
        try:
            if x.left_variance in ['Odd', 'Even']:
                return np.arange(min([int(x.left_first_numeric), int(x.left_last_numeric)]),
                                max([int(x.left_first_numeric), int(x.left_last_numeric)]) + 2,
                                2)
            if x.left_variance in ['Numeric Mixed']:
                return np.arange(min([int(x.left_first_numeric), int(x.left_last_numeric)]),
                                max([int(x.left_first_numeric), int(x.left_last_numeric)]) + 1,
                                1)
            if x.left_variance in ['Irregular']:
                return [x.left_first] + [x.left_last]
            
            try:
                if x.left_variance in ['Alphabetic']:
                        # For errors of digitalization, convert to odd
                        if x.left_first_numeric != x.left_last_numeric:
                            return np.arange(min([int(x.left_first_numeric), int(x.left_last_numeric)]),
                                        max([int(x.left_first_numeric), int(x.left_last_numeric)]) + 2,
                                        2)


                        return [x.left_first_numeric + chr(i) for i in range(min([ord(x.left_first_char.lower()), ord(x.left_last_char.lower())]),
                                                    max([ord(x.left_first_char.lower()), ord(x.left_last_char.lower())])+1)]
            except Exception as e:
                print('HNR not parsed correctly ', e)
                return [x.left_first] + [x.left_last]
        
        
        except Exception as e:
            print('HNR not parsed correctly ', e)
            return [x.left_first] + [x.left_last]
            
            
    else:
        return [x.left_first] + x.left_intermediates + [x.left_last]
    
    
def right_hnr(x:pd.Series) -> typing.List[str]:
    """Returns an array of house number ranges on the right side

    :param x: a row of the result of querying the address range lookup
    :type x: pd.Series
    :return: list containing the range of house numbers
    :rtype: typing.List[str]
    """
    
    if x.right_variance is None:
        return []
    elif x.right_intermediates is None:
        try:
            if x.right_variance in ['Odd', 'Even']:
                return np.arange(min([int(x.right_first_numeric), int(x.right_last_numeric)]),
                                max([int(x.right_first_numeric), int(x.right_last_numeric)]) + 2,
                                2)
            if x.right_variance in ['Numeric Mixed']:
                return np.arange(min([int(x.right_first_numeric), int(x.right_last_numeric)]),
                                max([int(x.right_first_numeric), int(x.right_last_numeric)]) + 1,
                                1)
            if x.right_variance in ['Irregular']:
                return [x.right_first] + [x.right_last]
            
            try:
                if x.right_variance in ['Alphabetic']:
                        # For errors of digitalization, convert to odd
                        if x.right_first_numeric != x.right_last_numeric:
                            return np.arange(min([int(x.right_first_numeric), int(x.right_last_numeric)]),
                                        max([int(x.right_first_numeric), int(x.right_last_numeric)]) + 2,
                                        2)


                        return [x.right_first_numeric + chr(i) for i in range(min([ord(x.right_first_char.lower()), ord(x.right_last_char.lower())]),
                                                    max([ord(x.right_first_char.lower()), ord(x.right_last_char.lower())])+1)]
            except Exception as e:
                print('HNR not parsed correctly ', e)
                return [x.right_first] + [x.right_last]
        except Exception as e:
            print('HNR not parsed correctly ', e)
            return [x.right_first] + [x.right_last]
            
    else:
        return [x.right_first] + x.right_intermediates + [x.right_last]


def apt_call_radius(country:str, df:pd.DataFrame, libpostal_df:pd.DataFrame, radius:float, 
                    inner_radius:float=0, stopwords_pattern: str = '') -> pd.DataFrame:
    """Performs matching after making call in a given radius

    :param country: country to call in MNR
    :type country: str
    :param df: DataFrame containing the sample addresses (must have coordinates)
    :type df: pd.DataFrame
    :param libpostal_df: DataFrame containing libpostal components for sample (df) addresses
    :type libpostal_df: pd.DataFrame
    :param radius: radius of the buffer
    :type radius: float
    :param inner_radius: radius in meters of a smaller buffer. When bigger than zero, we are essentially getting the point in a disk, defaults to 0
    :type inner_radius: int or float, optional
    :param stopwords_pattern: regex pattern to remove stopwords, if needed. Optional, defaults to None
    :type stopwords_pattern: str
    :return: DataFrame with the APTs that matched
    :rtype: pd.DataFrame
    """
    df_copy = df.copy()
    
    
    country_schemas = find_country_schemas(country, latest=True)
    lookup_df = lookup_by_coordinates(coordinates=df_copy.coordinates, schemas=country_schemas, radius=radius, 
                                      inner_radius=inner_radius)
    lookup_df = lookup_df.drop_duplicates(['index_searched_query', 'address']).reset_index(drop=True)
    
    
    # Merge to get original queries information
    lookup_df_merged = lookup_df.merge(df_copy[['searched_query', 'lat', 'lon', 'searched_query_unidecode']].drop_duplicates().reset_index(drop=True),
                                       how='right', 
                                       left_on='index_searched_query', 
                                       right_index=True).reset_index(drop=True)

    lookup_df_merged['mnr_lat'] = lookup_df_merged.geom.apply(lambda p: p.y if p else 9999)
    lookup_df_merged['mnr_lon'] = lookup_df_merged.geom.apply(lambda p: p.x if p else 9999)
    lookup_df_merged['mnr_query_distance'] = lookup_df_merged.apply(lambda x: haversine_distance(x.mnr_lat, x.mnr_lon,
                                                                                               x.lat, x.lon)
                                                                  if not np.isnan(x.lat) else 1e7
                                                                  , axis=1)

    apts_df_lookup = lookup_df_merged.copy().rename(columns={'country':'country_mnr'})
    apts_df_lookup['country'] = country


    # Fill NAs
    apts_df_lookup[['address', 'street_name', 'hsn', 'postal_code',
                    'postal_code', 'place_name', 'name']] = apts_df_lookup[['address', 'street_name', 'hsn', 'postal_code',
                                                                            'postal_code', 'place_name', 'name']].fillna('')

    # Drop dupllicates
    apts_df_lookup = apts_df_lookup.drop_duplicates(['searched_query', 'address']).reset_index(drop=True)
    
    
    # Create extra columns for stopwords, optional unidecode 
    cols_stopwords = ['address', 'street_name', 'place_name']
    for col in cols_stopwords:
        col_create = col + '_no_stopwords'
        apts_df_lookup[col_create] =  apts_df_lookup[col].str.replace(stopwords_pattern, '', case=False, regex=True)
        
    for col in cols_stopwords:
        col_create = col + '_no_stopwords_unidecode'
        apts_df_lookup[col_create] =  apts_df_lookup[col+'_no_stopwords'].apply(lambda x: unidecode.unidecode(x))
        
    
   # Merge to APTs
    apts_df_lookup = apts_df_lookup.merge(libpostal_df.drop(columns=['country', 'searched_query_unidecode']),
                                          how='left', 
                                          on=['searched_query'])
    apts_df_lookup['libpostal_road_no_stopwords'] = apts_df_lookup.libpostal_road.str.replace(stopwords_pattern, '', case=False, regex=True)



    # House number similarity: filter obvious non matches
    apts_df_lookup['hsn_similarity'] = list(map(fuzz.token_set_ratio, apts_df_lookup.libpostal_house_number, apts_df_lookup.hsn))
    apts_df_lookup['re_pattern'] = '\\b' + apts_df_lookup.hsn.astype(str) + '\\b'
    apts_df_lookup['hsn_in_query'] = apts_df_lookup.apply(lambda x: bool(re.search(x.re_pattern, x.searched_query)), axis=1)
    apts_df_lookup['hsn_similarity'] = np.where((apts_df_lookup.hsn_in_query), 100, apts_df_lookup.hsn_similarity)

    apts_df_lookup = apts_df_lookup.loc[apts_df_lookup.hsn_similarity > 60].reset_index(drop=True)
    

    # Postal code similarity
    apts_df_lookup['postcode_similarity'] = list(map(fuzz.WRatio, 
                                                     apts_df_lookup.libpostal_postcode, 
                                                     apts_df_lookup.postal_code.fillna('').astype(str)))
    apts_df_lookup['postcode_similarity'] = np.where(apts_df_lookup.libpostal_postcode=='', np.nan,
                                                     np.where(apts_df_lookup.postal_code=='', 50, apts_df_lookup.postcode_similarity))

    
    # Road similarity
    apts_df_lookup['road_similarity'] = list(map(fuzz.token_set_ratio, 
                                                 apts_df_lookup.libpostal_road_no_stopwords, 
                                                 apts_df_lookup.street_name_no_stopwords))
    apts_df_lookup['road_similarity_unidecode'] = list(map(fuzz.token_set_ratio, 
                                                           apts_df_lookup.libpostal_road_no_stopwords, 
                                                           apts_df_lookup.street_name_no_stopwords_unidecode)) 
    apts_df_lookup['road_similarity'] = apts_df_lookup[['road_similarity', 'road_similarity_unidecode']].max(axis=1)
    
    # Locality similarity
    apts_df_lookup['searched_query_tokens'] = (apts_df_lookup.libpostal_road.astype(str) + ' ' + 
                                               apts_df_lookup.libpostal_house_number.astype(str) + ' ' + 
                                               apts_df_lookup.libpostal_postcode.astype(str))
    
    apts_df_lookup['provider_tokens'] = (apts_df_lookup.street_name.astype(str) + ' ' + 
                                         apts_df_lookup.hsn.astype(str) + ' ' + apts_df_lookup.postal_code.astype(str))
    apts_df_lookup['aux_searched_query'] = apts_df_lookup.apply(lambda x: automatic_matching.replace_tokens(x.searched_query_unidecode, x.searched_query_tokens), axis=1)
    apts_df_lookup['aux_provider_address'] = apts_df_lookup.apply(lambda x: automatic_matching.replace_tokens(x.address, x.provider_tokens), axis=1)
    apts_df_lookup['aux_provider_address'] = apts_df_lookup.aux_provider_address.fillna('').apply(lambda x: unidecode.unidecode(x))
    apts_df_lookup['locality_wratio'] = apts_df_lookup.apply(lambda x: fuzz.WRatio(str(x.aux_searched_query).lower(), str(x.aux_provider_address).lower()), axis=1)
    apts_df_lookup['locality_city_state_ratio'] = apts_df_lookup.apply(lambda x: fuzz.WRatio(str(x.libpostal_city) + ' ' + str(x.libpostal_state),
                                                                                            str(x.place_name) + ' ' + str(x.name)), axis=1)
    apts_df_lookup['locality_similarity'] = apts_df_lookup[['locality_wratio', 'locality_city_state_ratio']].mean(axis=1)

    
    # Compute mean similarity
    apts_df_lookup['mean_similarity'] = (apts_df_lookup[['locality_similarity', 'hsn_similarity', 
                                                         'postcode_similarity', 'road_similarity']].mean(axis=1)
                                        * np.where(apts_df_lookup.hsn_similarity >= 70 , 1, 0)
                                        * np.where(apts_df_lookup.road_similarity >= 60 , 1, 0)  
                                        * np.where(apts_df_lookup.mnr_query_distance > 1000, 0, 1)
                                        )


    apts_df_matching = apts_df_lookup.sort_values(by='mnr_query_distance').loc[apts_df_lookup.groupby(['searched_query']).mean_similarity.idxmax()].reset_index(drop=True)


    # Compute matching
    apts_df_matching['match'] = pd.NaT
    apts_df_matching['match'] = np.where(apts_df_matching.mean_similarity >= 70, 1, pd.NaT) #90 so far best


    return apts_df_matching


def apt_recursive_radius_calls(df:pd.DataFrame, country:str, libpostal_df:pd.DataFrame, 
                               radius_list:typing.List[float], stopwords_pattern:str = '') -> typing.Tuple[pd.DataFrame, pd.DataFrame]:
    """Performs recursive calls in meters to get APTs near a pair of coordinates

    :param country: country to call in MNR
    :type country: str
    :param df: DataFrame containing the sample addresses (must have coordinates)
    :type df: pd.DataFrame
    :param libpostal_df: DataFrame containing libpostal components for sample (df) addresses
    :type libpostal_df: pd.DataFrame
    :param radius_list: list of buffer radius to make calls
    :type radius_list: typing.List[float]
    :param stopwords_pattern: regex pattern to remove stopwords, if needed. Optional, defaults to None
    :type stopwords_pattern: str
    :return: tuples with DataFrame with the APTs that matched and DataFrame with all the relevant APTs
    :rtype: typing.Tuple[pd.DataFrame, pd.DataFrame]
    """
    
    df_copy = df.copy()
    
    
    # Compute first result
    radius_result = apt_call_radius(country, df, libpostal_df, radius_list[0], 0, stopwords_pattern)
    apt_match_df = radius_result.loc[radius_result.match==1].reset_index(drop=True)
    missing_apts_df = df_copy.loc[~df_copy.searched_query.isin(apt_match_df.searched_query)].reset_index(drop=True)
    
    
    # Compute remaining results for other radius
    if len(radius_list) > 1:
        for idx, radius in enumerate(radius_list[1:]):
            radius_result = apt_call_radius(country, missing_apts_df, libpostal_df, radius, radius_list[idx]-5, stopwords_pattern)
            matching_found = radius_result.loc[radius_result.match==1].reset_index(drop=True)
            
            # Concatenate to existing DF
            apt_match_df = pd.concat([apt_match_df, matching_found], ignore_index=True)
            missing_apts_df = df_copy.loc[~df_copy.searched_query.isin(apt_match_df.searched_query)]
    
    
    # Add latest results but missing
    radius_result['match'] = radius_result.match.fillna(0)
    matching_not_found = radius_result.loc[radius_result.match==0].reset_index(drop=True)
    apt_match_df = pd.concat([apt_match_df, matching_not_found], ignore_index=True)
    
    
    # Merge back to original dataframe and fill NA with 0s
    apt_match_df = df_copy.merge(apt_match_df.drop(columns=['lat', 'lon', 'country', 'coordinates', 'searched_query_unidecode']),
                                 on='searched_query',
                                 how='left')
    apt_match_df['match'] = apt_match_df.match.fillna(0)

    return apt_match_df
    

def poi_lookup_radius(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, radius:int or float=50) -> pd.DataFrame:
    """Performs spatial queries of a list of coordinates in MNR to get the POIS near a pair of coordinates
    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the POI to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param radius: radius in meters to look around the coordinates to retrieve the nearby POI,  defaults to 50
    :type radius: int or float, optional
    :return: POI in MNR near the coordinates
    :rtype: gpd.DataFrame
    """
    
    # Create query for POIS to reverse lookup
    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                         from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    
    
    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', row.db)
        
        query_pois = """
    with sample as ({query_coordinates})

    , buffers as (
    select  
        sample.index_searched_query
        , sample.coordinates
        , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
    from sample
    )
            
    , unique_bn as( -- get only one bn, not the complete set
                        SELECT p2n.poi_id, mn.name
                            FROM (select poi_id, cast(min(cast(nameset_id as text)) as uuid) nameset_id
                                    from {schema}.mnr_poi2nameset 
                                    where nt_brand_name group by 1) p2n
                                join {schema}.mnr_nameset2name mnn
                                    on p2n.nameset_id = mnn.nameset_id
                                join {schema}.mnr_name mn
                                    on mnn.name_id = mn.name_id
                    )
    , sample_pois as( -- select the right amount of POIS by category/country
        SELECT mp.feat_id poi_id
                    , mp.feat_type poi_type
                    , mp.poi_address_id 
                    , mp.name as poi_name
                    , bn.name as poi_bn
                    , mp.email
                    , mp.internet 
                    , mp.telephone_num
                    , st_astext(mp.geom) as wkt
                    , buffers.index_searched_query
                    , buffers.coordinates 
                    , st_astext(buffers.buffer) buffer
                    FROM {schema}.mnr_poi mp
                    join buffers on ST_Intersects(buffers.buffer, mp.geom)
                    left join unique_bn bn on mp.feat_id = bn.poi_id
    )

    , single_name as (-- get only one stn name, not the complete set
        select nameset_id
            , min(name_id::text) name_id
        from {schema}.mnr_nameset2name
        group by nameset_id
    )
    , external_ids as( -- get external_ids from the db
        SELECT pa.poi_id , value_varchar as external_id
        FROM {schema}.mnr_attribute a
        join {schema}.mnr_poi2attribute as pa on a.attribute_id = pa.attribute_id
        where attribute_type = 'EI'
    )
    SELECT mp.poi_id
                , ei.external_id
                , mp.poi_type
                , mp.poi_address_id 
                , '{mnr_version}' as version_checked
                , mp.poi_name
                , mp.poi_bn as poi_brand
                , mn.name as streetname
                , mpa.hsn as housenumber
                , mp.email
                , mp.internet 
                , mp.telephone_num
                , mp.wkt as geom
                , mp.index_searched_query
                , mp.buffer
                , mp.coordinates
                FROM sample_pois mp
                left join {schema}.mnr_poi_address mpa 
                    on mp.poi_address_id= mpa.poi_address_id
                left join single_name mnn
                    on mpa.street_nameset_id = mnn.nameset_id
                left join {schema}.mnr_name mn
                    on mnn.name_id::uuid = mn.name_id
                left join external_ids ei
                    on ei.poi_id=mp.poi_id
        """.format(mnr_version = row.date,
                   query_coordinates = query_coordinates,
                   schema = row.nspname,
                   radius = radius)

        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_pois, conn, geom_col='coordinates')
        spatial_query_result['buffer'] = gpd.GeoSeries.from_wkt(spatial_query_result['buffer'])
        spatial_query_result['geom'] = gpd.GeoSeries.from_wkt(spatial_query_result['geom'])


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
    
    return gpd.GeoDataFrame(lookup_df)


def find_categories_population(country:str, schemas:pd.DataFrame) -> pd.DataFrame:
    """Find the country's category population in MNR

    :param country: ISO2 or ISO3 of the country
    :type country: str
    :param schemas: schemas in MNR to search for
    :type schemas: pd.DataFrame
    :return:  Counts for categories in the country
    :rtype: pd.DataFrame
    """
    
    categories_population = pd.DataFrame()
    
     # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', row.db)
        
        query_categories = """
        select 
            feat_type
        ,   '{mnr_version}' as mnr_version
        ,   '{country}' as country
        ,   count(1) qty
        from "{schema}".mnr_poi mp 
        
        group by feat_type 
        """.format(mnr_version = row.date,
                   schema = row.nspname,
                   country=country)
        
        
        df = pd.read_sql(query_categories, conn)
        categories_population = pd.concat([categories_population, df], ignore_index=True)
        categories_population['feat_type'] = categories_population.feat_type.astype(int)
    
    return categories_population


def hnr_matching(df:pd.DataFrame, country:str, libpostal_df:pd.DataFrame, stopwords_pattern:str) -> pd.DataFrame:
    """Performs matching on HNR

    :param df: pandas DataFrame containing addresses to search
    :type df: pd.DataFrame
    :param country: country to match
    :type country: str
    :param libpostal_df: DataFrame containing parsed searched queries
    :type libpostal_df: pd.DataFrame
    :param stopwords_pattern: regex pattern for the stopwords that musn't be considered
    :type stopwords_pattern: str
    :return: DataFrame containing responses (positive or negative) for the addresses
    :rtype: pd.Dataframe
    """
    
    df_copy = df.copy()
    
    # Return empty dataframe if input is empty
    if df_copy.shape[0] == 0:
        return pd.DataFrame(columns=['searched_query', 'address', 'match','street_name', 'place_name', 'coordinates', 'mnr_lat', 'mnr_lon', 'mnr_query_distance'])
    
    # Get MNR schema
    country_schemas = find_country_schemas(country, latest=True)

    # Perform lookup
    country_lookup_df = lookup_address_ranges(coordinates=df_copy.coordinates, schemas=country_schemas, radius=1000)

    # Merge to get original queries information
    country_hnr_df_lookup = country_lookup_df.merge(df_copy[['searched_query', 'lat', 'lon', 'searched_query_unidecode']],
                                                    how='right', 
                                                    left_on='index_searched_query', 
                                                    right_index=True).reset_index(drop=True)

    country_hnr_df_lookup = country_hnr_df_lookup.loc[~country_hnr_df_lookup.street_name.isna()].reset_index(drop=True)

    # Return empty dataframe if HNR is empty after filtering out null street names
    if country_hnr_df_lookup.shape[0] == 0:
        return pd.DataFrame(columns=['searched_query', 'address', 'match','street_name', 'place_name', 'coordinates', 'mnr_lat', 'mnr_lon', 'mnr_query_distance'])


    # Get only numeric components
    country_hnr_df_lookup['street_name_no_stopwords'] = country_hnr_df_lookup.street_name.str.replace(stopwords_pattern, '', case=False, regex=True)
    country_hnr_df_lookup['street_name_no_stopwords_unidecode'] = country_hnr_df_lookup.street_name.apply(lambda x: unidecode.unidecode(x))
    country_hnr_df_lookup['left_first_numeric'] = country_hnr_df_lookup.left_first.str.replace('[^0-9]+', '', regex=True)
    country_hnr_df_lookup['left_last_numeric'] = country_hnr_df_lookup.left_last.str.replace('[^0-9]+', '', regex=True)
    country_hnr_df_lookup['right_first_numeric'] = country_hnr_df_lookup.right_first.str.replace('[^0-9]+', '', regex=True)
    country_hnr_df_lookup['right_last_numeric'] = country_hnr_df_lookup.right_last.str.replace('[^0-9]+', '', regex=True)


    # Get only characters
    country_hnr_df_lookup['left_first_char'] = country_hnr_df_lookup.left_first.str.replace('[^a-zA-Z]', '', regex=True).replace({'':'a'})
    country_hnr_df_lookup['left_last_char'] = country_hnr_df_lookup.left_last.str.replace('[^a-zA-Z]', '', regex=True).replace({'':'a'})
    country_hnr_df_lookup['right_first_char'] = country_hnr_df_lookup.right_first.str.replace('[^a-zA-Z]', '', regex=True).replace({'':'a'})
    country_hnr_df_lookup['right_last_char'] = country_hnr_df_lookup.right_last.str.replace('[^a-zA-Z]', '', regex=True).replace({'':'a'})


    # Compute HNR (CHECK IF TRUE)
    country_hnr_df_lookup['left_array'] = country_hnr_df_lookup.apply(left_hnr, axis=1)
    country_hnr_df_lookup['right_array'] = country_hnr_df_lookup.apply(right_hnr, axis=1)
    country_hnr_df_lookup['hnr_array'] = country_hnr_df_lookup.apply(lambda x: list(x.left_array) + list(x.right_array), axis=1)
    country_hnr_df_lookup['hnr_array'] = country_hnr_df_lookup.hnr_array.apply(lambda x: list(set([str(el) for el in x])))


    # Join with libpostal
    country_hnr_df_lookup = country_hnr_df_lookup.merge(libpostal_df.drop(columns=['country', 'searched_query_unidecode']), on='searched_query')


    # Compute road similarity
    country_hnr_df_lookup['road_similarity_hnr'] = list(map(fuzz.token_set_ratio, country_hnr_df_lookup.libpostal_road_no_stopwords, 
                                                            country_hnr_df_lookup.street_name_no_stopwords))
    country_hnr_df_lookup['road_similarity_hnr_unidecode'] = list(map(fuzz.token_set_ratio, country_hnr_df_lookup.libpostal_road_no_stopwords, 
                                                            country_hnr_df_lookup.street_name_no_stopwords_unidecode))
    country_hnr_df_lookup['road_similarity_hnr'] = country_hnr_df_lookup[['road_similarity_hnr', 'road_similarity_hnr_unidecode']].max(axis=1)


    # Compute similarity for HSN
    country_hnr_df_lookup = country_hnr_df_lookup.loc[country_hnr_df_lookup.road_similarity_hnr >= 85].reset_index(drop=True)

    if country_hnr_df_lookup.shape[0] > 0:
        country_hnr_df_lookup['hnr_ratios'] = country_hnr_df_lookup.apply(lambda x: process.extractOne(x.libpostal_house_number, 
                                                                                                        x.hnr_array,
                                                                                                        scorer=token_set_ratio)[1], axis=1)
        country_hnr_df_lookup['hnr_regex_bool'] = country_hnr_df_lookup.apply(lambda x: max([bool(re.search('\\b'+j+'\\b', x.searched_query)) for j in x.hnr_array]), axis=1)

        # Compute match
        country_hnr_df_lookup['match'] = country_hnr_df_lookup.apply(lambda x: 1 
                                                                        if x.road_similarity_hnr >= 85 and x.hnr_regex_bool else 0, axis=1)

        country_hnr_df_lookup_final = country_hnr_df_lookup.loc[country_hnr_df_lookup.groupby('searched_query').match.idxmax()].reset_index(drop=True)
        country_hnr_df_lookup_final['address'] = (country_hnr_df_lookup_final.libpostal_house_number + ', ' + 
                                                    country_hnr_df_lookup_final.street_name + ', ' + country_hnr_df_lookup_final.place_name)
        country_hnr_df_lookup_final['type'] = 'Address Range'

        country_hnr_df_lookup_final['provider_coordinates'] = country_hnr_df_lookup_final.geom.centroid
        country_hnr_df_lookup_final['mnr_lat'] = country_hnr_df_lookup_final.provider_coordinates.apply(lambda p: p.y)
        country_hnr_df_lookup_final['mnr_lon'] = country_hnr_df_lookup_final.provider_coordinates.apply(lambda p: p.x)

        country_hnr_df_lookup_final['mnr_query_distance'] = country_hnr_df_lookup_final.apply(lambda p: haversine_distance(p.mnr_lat, p.mnr_lon,
                                                                                                                          p.lat, p.lon), axis=1)

        return country_hnr_df_lookup_final
    else:
        return pd.DataFrame(columns=['searched_query', 'address', 'match','street_name', 'place_name', 'coordinates', 'mnr_lat', 'mnr_lon', 'mnr_query_distance'])


def appPandas_mnr_recursive_calls(df:pd.DataFrame, libpostal_df:pd.DataFrame, 
                                  radius_list:typing.List[float], stopwords_dict:dict) -> typing.Tuple[pd.DataFrame, pd.DataFrame]:
    """Performs recursive calls in meters to get APTs near a pair of coordinates

    :param country: country to call in MNR
    :type country: str
    :param df: DataFrame containing the sample addresses (must have coordinates)
    :type df: pd.DataFrame
    :param libpostal_df: DataFrame containing libpostal components for sample (df) addresses
    :type libpostal_df: pd.DataFrame
    :param radius_list: list of buffer radius to make calls
    :type radius_list: typing.List[float]
    :param stopwords_pattern: regex pattern to remove stopwords, if needed. Optional, defaults to None
    :type stopwords_pattern: str
    :return: tuples with DataFrame with the APTs that matched and DataFrame with all the relevant APTs
    :rtype: typing.Tuple[pd.DataFrame, pd.DataFrame]
    """
    
    # We try to make the geospatial call, if not, we return an empty DataFrame with the same columns
    cols_select = ['country', 'sample_id', 'searched_query_type', 'searched_query', 'partition_id', 'lat', 'lon', 'searched_query_unidecode', 'coordinates',
              'version_checked', 'address', 'hsn', 'street_name', 'place_name', 'name', 'postal_code', 'country_mnr', 'mnr_lat', 'mnr_lon',
              'mnr_query_distance', 'sampling_run_id', 'mean_similarity', 'match', 'type']
    
    try:
      df_copy = df.copy()
      libpostal_df_copy = libpostal_df.copy()

      df_copy['coordinates'] = gpd.GeoSeries.from_wkt(df_copy.coordinates.astype(str))
      df_copy[['lat', 'lon']] = df_copy[['lat', 'lon']].astype(float)
      df_copy = gpd.GeoDataFrame(df_copy, geometry='coordinates')


      # Get inputs
      country = df_copy.country.unique()[0]
      stopwords_pattern = stopwords_dict.get(country, '')
      partition_id = df_copy.partition_id.unique()[0]


      libpostal_columns = ['searched_query_unidecode', 'libpostal_road', 'libpostal_city', 'libpostal_state']
      for col in libpostal_columns:
          col_create = col + '_no_stopwords'
          libpostal_df_copy[col_create] = libpostal_df_copy[col].str.replace(stopwords_pattern, '', case=False, regex=True)


      # Compute first result
      radius_result = apt_call_radius(country, df_copy, libpostal_df_copy, radius_list[0], 0, stopwords_pattern)
      apt_match_df = radius_result.loc[radius_result.match==1].reset_index(drop=True)
      missing_apts_df = df_copy.loc[~df_copy.searched_query.isin(apt_match_df.searched_query)].reset_index(drop=True)


      # Compute remaining results for other radius
      if len(radius_list) > 1 and missing_apts_df.shape[0] > 0:
          for idx, radius in enumerate(radius_list[1:]):
              radius_result = apt_call_radius(country, missing_apts_df, libpostal_df_copy, radius, radius_list[idx]-5, stopwords_pattern)
              matching_found = radius_result.loc[radius_result.match==1].reset_index(drop=True)

              # Concatenate to existing DF
              apt_match_df = pd.concat([apt_match_df, matching_found], ignore_index=True)
              missing_apts_df = df_copy.loc[~df_copy.searched_query.isin(apt_match_df.searched_query)]


      # Add latest results but missing
      radius_result['match'] = radius_result.match.fillna(0)
      matching_not_found = radius_result.loc[radius_result.match==0].reset_index(drop=True)
      apt_match_df = pd.concat([apt_match_df, matching_not_found], ignore_index=True)


      # Merge back to original dataframe and fill NA with 0s
      apt_match_df = df_copy.merge(apt_match_df.drop(columns=['lat', 'lon', 'country', 'coordinates', 'searched_query_unidecode']),
                                   on='searched_query',
                                   how='left')
      apt_match_df['match'] = apt_match_df.match.fillna(0)


      # One last run to avoid issues with SQL
      partial_df = apt_match_df.loc[apt_match_df.match==1].reset_index(drop=True)
      missing_queries = apt_match_df.loc[(apt_match_df.match==0) | (apt_match_df.match.isna())].searched_query
      country_sample_missing_gdf = df_copy.loc[df_copy.searched_query.isin(missing_queries)].reset_index(drop=True)


      missing_results_df = apt_call_radius(df=country_sample_missing_gdf,
                                           country=country,
                                           libpostal_df=libpostal_df_copy, 
                                           radius=250,
                                           inner_radius=0,
                                           stopwords_pattern=stopwords_pattern)

      apt_match_final_df = pd.concat([partial_df, missing_results_df], ignore_index=True)
      apt_match_final_df['match'] = apt_match_final_df.match.fillna(0)


      # Now perform matching on HNR
      missing_queries = apt_match_final_df.loc[(apt_match_final_df.match==0) | (apt_match_final_df.match.isna())].searched_query
      country_sample_missing_gdf = df_copy.loc[df_copy.searched_query.isin(missing_queries)].reset_index(drop=True)
      hnr_match_df = hnr_matching(df=country_sample_missing_gdf, country=country, libpostal_df=libpostal_df_copy, stopwords_pattern=stopwords_pattern)


      # Merge all results
      countries_apt_final_matching_df = df_copy.merge(apt_match_final_df.drop(columns=['lat', 'lon', 'country', 'coordinates', 
                                                                                       'searched_query_unidecode', 'sample_id', 'searched_query_type']),
                                                      on='searched_query',
                                                      how='left')
      countries_apt_final_matching_df['match'] = countries_apt_final_matching_df.match.fillna(0)
      countries_apt_final_matching_df['type'] = 'Point Address'

      # Get HNR matches
      countries_apt_final_matching_df = countries_apt_final_matching_df.merge(hnr_match_df[['searched_query', 'address', 'match','street_name', 'place_name',
                                                                                                           'coordinates', 'mnr_lat', 'mnr_lon', 'mnr_query_distance']],
                                                                              on='searched_query',
                                                                              how='left',
                                                                              suffixes=('', '_hnr'))

      countries_apt_final_matching_df['type'] = np.where(countries_apt_final_matching_df.match_hnr > countries_apt_final_matching_df.match, 'Address Range', 
                                                        countries_apt_final_matching_df['type'])

      # Complement with HNR matches
      cols_imputation = ['address', 'mnr_lat', 'mnr_lon', 'mnr_query_distance', 'street_name', 'place_name', 'match']
      for col in cols_imputation:
          countries_apt_final_matching_df[col] = np.where(countries_apt_final_matching_df.match_hnr > countries_apt_final_matching_df.match, 
                                                          countries_apt_final_matching_df[col+'_hnr'], countries_apt_final_matching_df[col])

      countries_apt_final_matching_df['partition_id'] = partition_id


      return countries_apt_final_matching_df[cols_select].fillna('').astype(str)
    
    except Exception as e:
        print(e)
        return pd.DataFrame(columns=cols_select, dtype=str)


def appPandas_tt_poi_lookup(df:pd.DataFrame,  sampling_configuration_df:pd.DataFrame, poi_osm_mapping_merged:pd.DataFrame) -> pd.DataFrame:
    """Finds the POIs of similar category for sample POIs

    :param df: DataFrame containing at least 'coordinates' and 'category_id_tt' columns
    :type df: gpd.GeoDataFrame
    :param mapping_df: mapping category for similar POIs, given a category
    :type mapping_df: pd.DataFrame
    :param radius: radius to lookup, defaults to 500
    :type radius: int or float, optional
    :return: DataFrame containing only the relevant POIs similar to the category in question
    :rtype: gpd.GeoDataFrame
    """
    
    df_copy = df.copy()
    df_copy['coordinates'] = gpd.GeoSeries.from_wkt(df_copy.wkt)
    df_copy = gpd.GeoDataFrame(df_copy, geometry='coordinates')
    
    
    # Find country schema
    country = df_copy.country.unique()[0]
    schema = find_country_schemas(country)
    
    
    # Initiate mapping dataframe if not initialized
    category = df_copy.category_id_tt.unique()[0]
    radius = sampling_configuration_df.loc[sampling_configuration_df.category_id_tt==category].radius_m.iloc[0]
    mapping_df = poi_osm_mapping_merged.loc[poi_osm_mapping_merged.category_code==category].reset_index(drop=True)
    
    
    # Create mapping SQL query
    categories_query = str(mapping_df.category_id.to_list()).replace('[', '(').replace(']', ')')
    

    # Create base query for spatial lookups
    query_coordinates = """select index_searched_query,  st_geomfromtext (coordinates, 4326)  coordinates, category_id
                    from """ + utils.convert_poi_to_query(df_copy) + " as t (index_searched_query, coordinates, category_id)"
                    
    
        # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schema.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', row.db)
    
        # Create query
        query_complete = """ 
        with sample as ({query_coordinates})
        
        , buffers as (
        select  
            sample.index_searched_query
            , sample.coordinates
            , sample.category_id
            , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
        from sample
        )  

        , pois as (
        select 
            buffers.index_searched_query
        ,   buffers.category_id
        ,	poi.feat_id
        ,	poi2poi.belonging_poi_id
        ,	poi.feat_type::text as feat_type 
        ,	poi.name 
        ,   brand.default_brand_name
        ,	poi.geom
        ,   poi_address.hsn
        ,	postal_point.postal_code
        ,   array_agg(distinct street_name.name) as street_names
        ,   array_agg(distinct place_name.name) as place_names	
        ,   array_agg(distinct poi_name.name) as poi_names

        from "{schema}".mnr_poi poi
        
        join buffers on ST_Intersects(poi.geom, buffers.buffer)

        left join "{schema}".mnr_poi2poi poi2poi 
            on poi2poi.poi_id = poi.feat_id

        left join "{schema}".mnr_poi_address poi_address 
            on poi_address.poi_address_id = poi.poi_address_id

        left join "{schema}".mnr_poi2nameset poi2nameset 
            on poi2nameset.poi_id = poi.feat_id

        left join "{schema}".mnr_nameset2name mnn
            on mnn.nameset_id = poi2nameset.nameset_id

        left join "{schema}".mnr_name poi_name
            on poi_name.name_id = mnn.name_id
            
        left join "{schema}".mnr_poi_brand_info brand 
            on brand.brand_id = poi2nameset.brand_id

        left join "{schema}".mnr_nameset2name street_nameset 
            on street_nameset.nameset_id  = poi_address.street_nameset_id

        left join "{schema}".mnr_name street_name
            on street_name.name_id  = street_nameset.name_id

        left join "{schema}".mnr_nameset2name place_nameset 
            on place_nameset.nameset_id  = poi_address.place_nameset_id

        left join "{schema}".mnr_name place_name
            on place_name.name_id  = place_nameset.name_id

        left join "{schema}".mnr_postal_point postal_point
            on postal_point.feat_id  = poi_address.postal_point_id

        where poi.feat_type::text in {categories_query}

        group by 
            buffers.index_searched_query
        ,   buffers.category_id
        ,	poi.feat_id 
        ,	poi2poi.belonging_poi_id
        ,	poi.feat_type 
        ,	poi.name 
        ,   brand.default_brand_name
        ,	poi.geom
        ,   poi_address.hsn
        ,	postal_point.postal_code
        )


        select 
          index_searched_query
        , category_id
        , name as name_response
        , default_brand_name as brand_name
        , '{mnr_version}' as product_version
        , feat_id
        , geom as way
        , st_x(geom) as provider_lon
        , st_y(geom) as provider_lat
        , feat_type as category_poi
        , hsn as hsn_response
        , postal_code as postal_code_response
        , street_names as street_names_response
        , place_names as place_names_response
        , poi_names as poi_names_response
        
        
        from pois
      

        """.format(mnr_version=row.date, categories_query=categories_query, schema=row.nspname, radius=radius, query_coordinates=query_coordinates)
        
        
        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_complete, conn, geom_col='way')


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
        
        
    lookup_merged_df = pd.DataFrame(lookup_df).merge(df_copy, how='right', left_on='index_searched_query', right_index=True)
    lookup_merged_df = lookup_merged_df.astype(str)
    
    # Fill some NAs
    lookup_merged_df['product_version'] = np.where(lookup_merged_df.product_version=='nan', pd.NA, lookup_merged_df.product_version)
    lookup_merged_df['product_version'] = lookup_merged_df.product_version.fillna(str(row.date))
    lookup_merged_df = lookup_merged_df.replace({'nan':''})
    
    
    return lookup_merged_df


if __name__=='__main__':
    # Create test dataframe
    test_addresses = [('11-97 DE ENTREE AMSTERDAM 1101 HE NLD', 52.31177019833552, 4.939634271503648),
    ('Aalsterweg 303, 5644 RL Eindhoven, NL', 51.41176179168882, 5.482757611072691),
    ('Ammunitiehaven 343 2511 XM s Gravenhage NL', 52.07742315143409, 4.3212179573462075),
     ('Baarsweg 148, 3192 VB, Hoogvliet Rotterdam, Ne...', 51.856975720153564, 4.350903401715045),
     ('Baas Gansendonckstraat 3, 1061CZ Amsterdam, NL', 52.37733757641722, 4.840407597295104)
     ]


    test_df = pd.DataFrame(test_addresses, columns=['searched_query', 'lat', 'lon'])
    test_df['coordinates'] = test_df.apply(lambda x: shapely.geometry.Point(x.lon, x.lat), axis=1)
    test_gdf = gpd.GeoDataFrame(test_df, geometry='coordinates')

    print(lookup_address_components(test_gdf.coordinates))

    # Test functions
    nld_schemas = find_country_schemas('nld', latest=True)
    lookup_df = lookup_by_coordinates(test_gdf.coordinates, nld_schemas, 50)
    address_ranges = lookup_address_ranges(test_gdf.coordinates, nld_schemas, 50)
    
    print('Lookup of APTs: \n')
    print(lookup_df.iloc[0:5, ])
    
    print('\nLookup of AddressRanges: \n')
    print(address_ranges.iloc[0:5, ])
    
    
    # Test on APT matching
    glp_sample_df = pd.read_csv('glp_sample_pbf.csv')
    glp_sample_gdf = gpd.GeoDataFrame(glp_sample_df)
    glp_sample_gdf['coordinates'] = gpd.GeoSeries.from_wkt(glp_sample_df.coordinates)
    glp_sample_gdf['searched_query_unidecode'] = glp_sample_gdf.searched_query.apply(lambda x: unidecode.unidecode(x))

    libpostal_glp_pbf = pd.read_csv('libpostal_glp_pbf.csv', dtype={'libpostal_postcode':str})
    libpostal_glp_pbf = libpostal_glp_pbf.fillna('')

    apts_df_lookup = apt_recursive_radius_calls('gp', glp_sample_gdf, libpostal_glp_pbf, [50, 100], '')
    apts_df_lookup.match.fillna(0).mean()
    apts_df_lookup.match.mean()

