import requests
import pandas as pd
import json




if __name__ == '__main__':

    MNR_request = "https://toby.tt-lns-os.com/search?q=250009007907361&mv=2021.03.010_01&searchResultsTable_length=20"

    response = requests.get(MNR_request)
    print(response.status_code)

    # Convert response to dictionary
    jsonTomTomString = json.loads(response.text)
    results = jsonTomTomString['results']

    # Convert dictionary (response) to DataFrame
    df_MNR_results = pd.DataFrame(results)

