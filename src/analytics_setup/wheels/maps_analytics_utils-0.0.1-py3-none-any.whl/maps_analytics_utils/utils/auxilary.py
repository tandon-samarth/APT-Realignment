import datetime


def get_today_date() -> str:
    date_value = datetime.datetime.now().strftime('%Y%m%d')
    return date_value


def manual_create_run_id(response: int, date: str, digits_len_int: int) -> str:
    run_id_value = date+"-"+format(response+1, "0" + str(digits_len_int))
    return run_id_value