import pandas
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder


class AzureDataExplorer():
    def execute_adx_query(self, query, cluster, database, client_id, secret_id, tenant_id):
        """Method to execute an adx query.

        Args:
            query ([str]): String input with Kusto format query.
            cluster ([str]): Sting input with name of cluster to connect in ADX.
            database ([str]): String input with name od database to make Kusto query in ADX.
            client_id ([str]): String input with app registry client_id value.
            secret_id ([str]): String input with app registry secret_id value.
            tenant_id ([str]): String input with app registry tenant_id value.

        Returns:
            [pandas.core.frame.DataFrame]: Output pandas dataframe with table queried in ADX.
            [azure.kusto.data.response.KustoResponseDataSetV2]: Output response of the ADX query.
        """
        kcsb = KustoConnectionStringBuilder.with_aad_application_key_authentication(cluster, client_id, secret_id, tenant_id)
        client = KustoClient(kcsb)
        response = client.execute(database, query)
        out_df = pandas.DataFrame(data=response.tables[1].to_dict()["data"])
        return out_df, response