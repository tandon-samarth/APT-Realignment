# -*- coding: utf-8 -*-
"""
The main purpose of this script, is to encapsulate all the functionalities for
PostgreSQL connections. Letting the user to read, write, edit (depending on their
permissions in the case of azure).
Credits:
    -------
    Author: Lucas Mengual (@LucasMengual-TomTom)
    License: MIT License 2021
    Reference:
    ----------
    [1] https://pandas.pydata.org/pandas-docs/stable/reference/index.html#api
    [2] https://www.psycopg.org/docs/
"""

import pandas as pd
import psycopg2
from .connections_utils import check_input, check_name, get_poi_secrets, get_assr_secrets

#TODO

def initiate_spark_reader(driver, url, table, user, password):
    """
    Function that initiates the reader for the Azure server, with Python´s spark library.

    :param driver: A <org.postgresql.Driver> object
    :param url: Input string with url to the posgres server, including the host, port, and database information
    :param table: Input string with a SCHEMA.TABLENAME format to read the table.
    :param user: Input string with the username to access the postgres server
    :param password: Input string with the password to access the postgres server
    :return: spark_reader: <pyspark.sql.readwriter.DataFrameReader> object from spark library.
    """
    spark_reader = spark.read.format("jdbc")\
        .option("driver", driver)\
        .option("url", url)\
        .option("dbtable", table)\
        .option("user", user)\
        .option("password", password)
    return spark_reader


def initiate_psycopg2_reader(database, host, user, password, port, table, keepalives = 1, 
                            keepalives_idle = 60, keepalives_interval = 10, keepalives_count = 5):
    """
    Function that initiates the reader for the local input server, with the psycopg2 library.

    :param database: Input string with the DDBB database name of the postgres server
    :param host: Input string with the host name of the postgres server
    :param user: Input string with the username to access the postgres server
    :param password: Input string with the password to access the postgres server
    :param port: Integers with the port (default is 5432) to access the postgres server
    :param table: Input string with a SCHEMA.TABLENAME format to read the table.
    :return: psycopg2_reader: <cursor> object from psycopg2 library.
    :return: query: Output string type with SQL query.
    """
    # Add keepalive arguments to the connection string
    keepalive_kwargs = {"keepalives": keepalives, 
                    "keepalives_idle": keepalives_idle, 
                    "keepalives_interval": keepalives_interval, 
                    "keepalives_count": keepalives_count}

    # Connect to your postgres DB
    conn = psycopg2.connect(dbname=database, host=host, user=user, password=password, port=port,  **keepalive_kwargs)
    # Set connection to commit with every execution
    conn.set_session(autocommit=True)
    # Open a cursor to perform database operations
    psycopg2_reader = conn.cursor()
    # Execute a query
    query = "SELECT * FROM "+table
    return psycopg2_reader, query


def connect_to_postgres(name, input, schema, table):
    """
    Function which creates the reader object for the postgres server connection. Depending on the
    name (local or azure) the function will load the required secrets and initiate the reader.

    :param name: Input string with either "poi" or "assr" options accepted
    :param input: Input string with either "local" or "azure" options accepted
    :param schema: Input string with the Schema name related to the postgreSQL
    :param table: Input string with the Table name related to the postgreSQL
    :return: reader: Either <pyspark.sql.readwriter.DataFrameReader> or <cursor> object.
    :return: query: Output string type with SQL query or None type (if input=azure).
    """
    if input == "azure":
        driver = "org.postgresql.Driver"
        if name == "poi":
            user, password, port, database, host, url = get_poi_secrets()
            table = schema+"."+table
            reader = initiate_spark_reader(driver, url, table, user, password)
            query = None
        if name == "assr":
            user, password, port, database, host, url = get_assr_secrets()
            table = schema+"."+table
            reader = initiate_spark_reader(driver, url, table, user, password)
            query = None
    if input == "local":
        if name == "poi":
            user, password, port, database, host, url = get_poi_secrets()
            table = schema + "." + table
            reader, query = initiate_psycopg2_reader(database, host, user, password, port, table)
        if name == "assr":
            user, password, port, database, host, url = get_assr_secrets()
            table = schema + "." + table
            reader, query = initiate_psycopg2_reader(database, host, user, password, port, table)
    return reader, query


def get_postgres_data(name, input, schema, table):
    """
    Function which encapsulates all the connections with postgres server either incoming from a local
    IP or Azure´s server IP range. Currently the postgres servers that can be accessed are those related
    to the POI and ASSR metrics. The function requires some mandatory parameters to successfully connect,
    like the name of postgres server, input location that can be either Azure or local, and the schema and
    table which wants to be extracted.

    :param name: Input string with either "poi" or "assr" options accepted
    :param input: Input string with either "local" or "azure" options accepted
    :param schema: Input string with the Schema name related to the postgreSQL
    :param table: Input string with the Table name related to the postgreSQL
    :return: out_df: <DataFrame> A pandas or pyspark dataframe depending on the input choice.
    """
    check_name(name)
    check_input(input)

    try:
        reader, query = connect_to_postgres(name, input, schema, table)
    except:
        raise Exception("Error creating reader from postgreSQL connection.")

    if input == "azure":
        out_df = reader.load()
    if input == "local":
        reader.execute(query)
        out_df = pd.DataFrame(data=reader.fetchall(), columns=[desc[0] for desc in reader.description])
    return out_df


def extract_pssr_sample(table: str = 'data.reference_pois') -> pd.DataFrame:
    """Queries the PSSR database to extract locality and category information 

    :param table: Name of the table of the database, defaults to 'data.reference_pois'
    :type table: str, optional
    :return: Dataframe with the result
    :rtype: pd.DataFrame
    """    

    # Gets the credentials for accessing the database
    user, password, port, database, host, url = get_poi_secrets()

    # Initiates the reader for the local input server
    reader, query = initiate_psycopg2_reader(database, host, user, password, port, table)
    
    query = """
    SELECT country, location, classification, address
    from data.reference_pois
    where "business_status" = 'OPERATIONAL';
    """

    # Executes the query
    reader.execute(query)
    out_df = pd.DataFrame(data=reader.fetchall(), columns=[desc[0] for desc in reader.description])
    return out_df