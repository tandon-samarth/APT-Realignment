import typing

import country_converter
import pyspark
from outscraper import ApiClient
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from shapely.geometry import Point

from ..utils.auxilary import get_today_date, manual_create_run_id
from .api_call import ApiCall

# Create Databricks Spark session from ancillary function
#from ..utils.spark_utils import get_dbutils


spark = SparkSession.builder.getOrCreate()


class OutscrapperApi(ApiCall):
    """
    Class that represents the Outscrapper API with the methods to call it
    """

    @property
    def api_key(self) -> str:
        """Key to get the access to the API"""
        return "YXV0aDB8NjFlYTlkZWEwYWQ0M2UwMDY5ZTQ2OWE1fDEyN2M3ZTdmYjA"

    @property
    def provider_id(self) -> str:
        """Id to identify the provider"""
        return "ou-gg"

    def get_geocode_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for geocoding using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for geocoding
        :rtype: str
        """
        pass

    def get_reverse_geocode_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for reverse geocoding using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for reverse geocoding
        :rtype: str
        """
        pass

    def get_search_poi_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for search POI using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for poi search
        :rtype: str
        """
        api_client = ApiClient(api_key=self.api_key)
        query = param_dict.get("query")
        # Specify a low limit, as opposed to the default value of 500, not to retrieve values in the whole world
        limit = param_dict.get("limit", self.pois_limit)
        latitude = param_dict.get("latitude", None)
        longitude = param_dict.get("longitude", None)
        zoom = param_dict.get("zoom", None)
        # Specify country (convert ISO3 to ISO2) for better results
        country = param_dict.get("country", None)
        region = country_converter.convert(
            names=country, to="ISO2") if country is not None else None

        result = api_client.google_maps_search(query=query,
                                               coordinates=f"""@{latitude}, {longitude}, {zoom}z""",
                                               language="en",
                                               region=region,
                                               limit=limit)

        return result

    def get_search_poi_reviews_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for search POI reviews using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for poi review search
        :rtype: str
        """
        api_client = ApiClient(api_key=self.api_key)
        query = param_dict.get("query")
        # Specify a low limit, as opposed to the default value of 500, not to retrieve values in the whole world
        limit = param_dict.get("limit", self.pois_limit)
        latitude = param_dict.get("latitude", None)
        longitude = param_dict.get("longitude", None)
        zoom = param_dict.get("zoom", None)
        # Specify country (convert ISO3 to ISO2) for better results
        country = param_dict.get("country", None)
        region = country_converter.convert(
            names=country, to="ISO2") if country is not None else None

        # Additional parameters: "reviewsLimit" and "sort".
        # # For the latter, choose between: ["most_relevant", "newest", "highest_rating", "lowest_rating"]. Raise ValueError if needed
        reviews_limit = param_dict.get("reviews_limit", 5)
        sort = param_dict.get("sort", "most_relevant")

        if sort not in ["most_relevant", "newest", "highest_rating", "lowest_rating"]:
            raise ValueError(
                "Please, choose a valid sorting method between: ['most_relevant', 'newest', 'highest_rating', 'lowest_rating']")

        result = api_client.google_maps_reviews(query=query,
                                                coordinates=f"""@{latitude}, {longitude}, {zoom}z""",
                                                language="en",
                                                region=region,
                                                limit=limit,
                                                reviewsLimit=reviews_limit,
                                                sort=sort)

        return result

    @staticmethod
    def flatten_list_of_query_result_sublists(api_result: typing.List[typing.List[typing.Dict]],
                                              api_result_field: str) -> typing.List[typing.Any]:
        """
        Given the result of an an outscrapper call, retrieve flattened list from the lists of dictionaries for a given query field

        :param api_result: Output from outscrapper query call
        :type api_result: typing.List[typing.List[typing.Dict]]
        :param api_result_field: Field to be retrieved (dictionary key) for each of the query results
        :type api_result_field: str
        :return: Flattened list with field value for each of the query results
        :rtype: typing.List[typing.Any]
        """

        # Retrieve field value for each element
        api_result_field = [[r.get(api_result_field, None)
                             for r in result] for result in api_result]

        # Flatten list of lists
        flattened_api_result_field = [
            item for sublist in api_result_field for item in sublist]

        return flattened_api_result_field

    def perform_outscrapper_api_on_pois_df(self,
                                           df_pois: pyspark.sql.dataframe.DataFrame,
                                           search_by: str,
                                           col_for_search_by: str,
                                           limit: int) -> typing.Tuple[typing.List[typing.List[str]],
                                                                       typing.List[typing.List[float]],
                                                                       typing.List[typing.List[int]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[float]],
                                                                       typing.List[typing.List[float]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[str]],
                                                                       typing.List[typing.List[typing.Dict]]]:
        """
        From a DataFrame with POI information, perform outscrapper API call

        :param df_pois: DataFrame with information about POIs to search: name, category, longirude, latitude,...
        :type df_pois: pyspark.sql.dataframe.DataFrame
        :param search_by: Either "name" or "category" for POI search
        :type search_by: str
        :param col_for_search_by: DataFrame column corresponding to the name/category to be queried
        :type col_for_search_by: str
        :param limit: POI search limit
        :type limit: int
        :raises ValueError: Invalid "search_by" method
        :return: Flattened lists for each relevant API call field where each element is a list (to be converted to a Spark DataFrame)
        :rtype: typing.Tuple[typing.List[typing.List[str]], typing.List[typing.List[float]], typing.List[typing.List[int]], typing.List[typing.List[str]], typing.List[typing.List[float]], typing.List[typing.List[float]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[typing.Dict]]]
        """

        # Raise ValueError if invalid "search_by" method
        if (search_by not in "name") & (search_by not in "category"):

            raise ValueError(
                "Please, introduce a valid search_by method")

        # Output - initially empty lists
        list_api2_run_id = []  # manually generated
        list_api_score = []
        list_api_search_rank = []  # range(n) withing each query
        list_api_poi_id = []
        list_api_lat = []
        list_api_lon = []
        list_api_street_number = []
        list_api_postal_code = []
        list_api_municipality = []
        list_api_local_name = []
        list_api_street_name = []
        list_api_country_code_iso3 = []
        list_api_country_code = []
        list_api_address = []
        list_api_name = []
        list_api_url = []
        list_api_phone = []
        list_api_code = []
        list_api_result = []

        # Iterate over each row of the DataFrame
        counter = -1  # Ancillary function adds 1

        for row in df_pois.rdd.collect():

            counter += 1

            try:

                # Retrieve coordinates and country
                lat, lon, country = row["latitude"], row["longitude"], row["country"]

                # Retrieve zoom
                if "zoom" in df_pois.columns:

                    zoom = row["zoom"]

                else:

                    # In the value for "site", the outscrapper API retrieves a zoom 14.
                    # To get reasonable values, initialize to zoom 16 (~611 m per square side)
                    # https://developer.tomtom.com/map-display-api/documentation/zoom-levels-and-tile-grid

                    zoom = 16

                # Perform query
                temp_result = self.get_search_poi_request(param_dict={"query": row[f"""{col_for_search_by}"""],
                                                                      "longitude": lon,
                                                                      "latitude": lat,
                                                                      "zoom": zoom,
                                                                      "country": country,
                                                                      "limit": limit})

                # Append flattened results to initially empty lists
                api_score = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                       api_result_field="rating")

                api_poi_id = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                        api_result_field="place_id")

                api_lat = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                     api_result_field="latitude")

                api_lon = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                     api_result_field="longitude")

                api_postal_code = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                             api_result_field="postal_code")

                api_municipality = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                              api_result_field="state")

                api_local_name = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                            api_result_field="city")

                api_country_code = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                              api_result_field="country_code")

                api_country_code_iso3 = [country_converter.convert(
                    names=c, to="ISO3") for c in api_country_code]

                api_address = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                         api_result_field="full_address")

                api_name = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                      api_result_field="name")

                api_url = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                     api_result_field="site")

                api_phone = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                       api_result_field="phone")

                api_code = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                      api_result_field="type")

                # Run ID
                api2_run_id = [manual_create_run_id(response=counter,
                                                    date=get_today_date(),
                                                    digits_len_int=4)
                               for _ in range(len(api_score))]

                # Street number and name from "street" field
                api_street = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                        api_result_field="street")

                api_street_number = ["".join([i for i in s if i.isdigit()]).replace(
                    ",", "") if s is not None else None for s in api_street]
                api_street_name = ["".join([i for i in s if not i.isdigit()]).replace(
                    ",", "") if s is not None else None for s in api_street]

                del api_street

                # Rank
                api_search_rank = [i for i in range(len(api_poi_id))]

                # Raw API output
                flat_api_result = [
                    item for sublist in temp_result for item in sublist]

                list_api2_run_id.append(api2_run_id)
                list_api_score.append(api_score)
                list_api_search_rank.append(api_search_rank)
                list_api_poi_id.append(api_poi_id)
                list_api_lat.append(api_lat)
                list_api_lon.append(api_lon)
                list_api_street_number.append(api_street_number)
                list_api_postal_code.append(api_postal_code)
                list_api_municipality.append(api_municipality)
                list_api_local_name.append(api_local_name)
                list_api_street_name.append(api_street_name)
                list_api_country_code_iso3.append(api_country_code_iso3)
                list_api_country_code.append(api_country_code)
                list_api_address.append(api_address)
                list_api_name.append(api_name)
                list_api_url.append(api_url)
                list_api_phone.append(api_phone)
                list_api_code.append(api_code)
                list_api_result.append(flat_api_result)

                del api2_run_id
                del api_score
                del api_search_rank
                del api_poi_id
                del api_lat
                del api_lon
                del api_street_number
                del api_postal_code
                del api_municipality
                del api_local_name
                del api_street_name
                del api_country_code_iso3
                del api_country_code
                del api_address
                del api_name
                del api_url
                del api_phone
                del api_code
                del flat_api_result

            except Exception as err:

                print(
                    f"""An unknown error happened {type(err).__name__}: {err.args[0]}""")

        # Process output for Spark DataFrame
        list_api2_run_id = [[item]
                            for sublist in list_api2_run_id for item in sublist]
        list_api_score = [[item]
                          for sublist in list_api_score for item in sublist]
        list_api_search_rank = [[item]
                                for sublist in list_api_search_rank for item in sublist]
        list_api_poi_id = [[item]
                           for sublist in list_api_poi_id for item in sublist]
        list_api_lat = [[item] for sublist in list_api_lat for item in sublist]
        list_api_lon = [[item] for sublist in list_api_lon for item in sublist]
        list_api_street_number = [
            [item] for sublist in list_api_street_number for item in sublist]
        list_api_postal_code = [[item]
                                for sublist in list_api_postal_code for item in sublist]
        list_api_municipality = [
            [item] for sublist in list_api_municipality for item in sublist]
        list_api_local_name = [[item]
                               for sublist in list_api_local_name for item in sublist]
        list_api_street_name = [[item]
                                for sublist in list_api_street_name for item in sublist]
        list_api_country_code_iso3 = [
            [item] for sublist in list_api_country_code_iso3 for item in sublist]
        list_api_country_code = [
            [item] for sublist in list_api_country_code for item in sublist]
        list_api_address = [[item]
                            for sublist in list_api_address for item in sublist]
        list_api_name = [[item]
                         for sublist in list_api_name for item in sublist]
        list_api_url = [[item] for sublist in list_api_url for item in sublist]
        list_api_phone = [[item]
                          for sublist in list_api_phone for item in sublist]
        list_api_code = [[item]
                         for sublist in list_api_code for item in sublist]
        list_api_result = [[item]
                           for sublist in list_api_result for item in sublist]

        return (list_api2_run_id,
                list_api_score,
                list_api_search_rank,
                list_api_poi_id,
                list_api_lat,
                list_api_lon,
                list_api_street_number,
                list_api_postal_code,
                list_api_municipality,
                list_api_local_name,
                list_api_street_name,
                list_api_country_code_iso3,
                list_api_country_code,
                list_api_address,
                list_api_name,
                list_api_url,
                list_api_phone,
                list_api_code,
                list_api_result)

    def process_api_results(self,
                            df_pois: pyspark.sql.dataframe.DataFrame,
                            search_by: str,
                            col_for_search_by: str,
                            limit: int = 20) -> pyspark.sql.dataframe.DataFrame:
        """
        Process multiple outscrapper API calls and retrieve a DataFrame

        :param df_pois: DataFrame with information about POIs to search: name, category, longitude, latitude,...
        :type df_pois: pyspark.sql.dataframe.DataFrame
        :param search_by: Either "name" or "category" for POI search
        :type search_by: str
        :param col_for_search_by: DataFrame column corresponding to the name/category to be queried
        :type col_for_search_by: str
        :param limit: POI search limit, defaults to 20
        :type limit: int, optional
        :return: DataFrame with API POIs table (v2) columns
        :rtype: pyspark.sql.dataframe.DataFrame
        """

        # Columns needed:
        #api2_run_id: string (nullable = false)
        #api_provider_id: string (nullable = false)
        #api_score: string (nullable = true)
        #api_search_rank: integer (nullable = false)
        #api_poi_id: string (nullable = true)
        #api_lat: string (nullable = true)
        #api_lon: string (nullable = true)
        #api_countrySecondarySubdivision: string (nullable = true)
        #api_streetNumber: string (nullable = true)
        #api_postalCode: string (nullable = true)
        #api_municipality: string (nullable = true)
        #api_countrySubdivision: string (nullable = true)
        #api_localName: string (nullable = true)
        #api_streetName: string (nullable = true)
        #api_countryCodeISO3: string (nullable = true)
        #api_countryCode: string (nullable = true)
        #api_municipalitySubdivision: string (nullable = true)
        #api_freeformAddress: string (nullable = true)
        #api_poiName: string (nullable = true)
        #api_poiURL: string (nullable = true)
        #api_poiBrand: string (nullable = true)
        #api_poiPhone: string (nullable = true)
        #api_categoryId: string (nullable = true)
        #api_code: string (nullable = true)
        #api_results: map (nullable = true)
        # | key: string
        # | value: string (valueContainsNull = true)

        # Retrieve necessary lists via ancillary function
        (list_api2_run_id,
         list_api_score,
         list_api_search_rank,
         list_api_poi_id,
         list_api_lat,
         list_api_lon,
         list_api_street_number,
         list_api_postal_code,
         list_api_municipality,
         list_api_local_name,
         list_api_street_name,
         list_api_country_code_iso3,
         list_api_country_code,
         list_api_address,
         list_api_name,
         list_api_url,
         list_api_phone,
         list_api_code,
         list_api_result) = self.perform_outscrapper_api_on_pois_df(df_pois=df_pois,
                                                                    search_by=search_by,
                                                                    col_for_search_by=col_for_search_by,
                                                                    limit=limit)

        # Schema
        schema = StructType([
            StructField("api2_run_id", StringType(), True),
            StructField("api_provider_id", StringType(), True),
            StructField("api_score", StringType(), True),
            StructField("api_search_rank", IntegerType(), True),
            StructField("api_poi_id", StringType(), True),
            StructField("api_lat", StringType(), True),
            StructField("api_lon", StringType(), True),
            StructField("api_countrySecondarySubdivision", StringType(), True),
            StructField("api_streetNumber", StringType(), True),
            StructField("api_postalCode", StringType(), True),
            StructField("api_municipality", StringType(), True),
            StructField("api_countrySubdivision", StringType(), True),
            StructField("api_localName", StringType(), True),
            StructField("api_streetName", StringType(), True),
            StructField("api_countryCodeISO3", StringType(), True),
            StructField("api_countryCode", StringType(), True),
            StructField("api_municipalitySubdivision", StringType(), True),
            StructField("api_freeformAddress", StringType(), True),
            StructField("api_poiName", StringType(), True),
            StructField("api_poiURL", StringType(), True),
            StructField("api_poiBrand", StringType(), True),
            StructField("api_poiPhone", StringType(), True),
            StructField("api_categoryId", StringType(), True),
            StructField("api_code", StringType(), True),
            StructField("api_results", MapType(
                StringType(), StringType(), True))
        ])

        # Data
        data = [(a[0], self.provider_id, b[0], c[0], d[0], e[0], f[0], None, g[0], h[0], i[0], None, j[0], k[0], l[0], m[0], None, n[0], o[0], p[0], None, q[0], None, r[0], s[0])
                for a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s
                in zip(list_api2_run_id,
                       list_api_score,
                       list_api_search_rank,
                       list_api_poi_id,
                       list_api_lat,
                       list_api_lon,
                       list_api_street_number,
                       list_api_postal_code,
                       list_api_municipality,
                       list_api_local_name,
                       list_api_street_name,
                       list_api_country_code_iso3,
                       list_api_country_code,
                       list_api_address,
                       list_api_name,
                       list_api_url,
                       list_api_phone,
                       list_api_code,
                       list_api_result)]

        df = spark.createDataFrame(data=data, schema=schema)

        del data

        return df

    def perform_batch_outscrapper_api_on_pois_df(self,
                                                 df_pois: pyspark.sql.dataframe.DataFrame,
                                                 limit: int) -> typing.Tuple[typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[str]],
                                                                             typing.List[typing.List[typing.Dict]]]:
        """
        From a DataFrame with POI information, perform mutli-query outscrapper API call by group: (category_name, zoom)
        # TODO: This function is intended to retrieve results for Aitor's api_1. Modify appropriately (col_for_search_by)

        :param df_pois: DataFrame with information about POIs to search: name, category, longirude, latitude,...
        :type df_pois: pyspark.sql.dataframe.DataFrame
        :param limit: POI search limit
        :type limit: int
        :return: Flattened lists for each relevant API call field where each element is a list (to be converted to a Spark DataFrame)
        :rtype: typing.Tuple[typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[str]], typing.List[typing.List[typing.Dict]]]
        """

        list_api1_run_id = []
        list_sample_id = []
        list_provider_id = []
        list_reference_id = []
        list_country = []
        list_wkt = []
        list_lat = []
        list_lon = []
        list_name = []
        list_category_name = []
        list_category_id_tt = []
        list_category_name_tt = []
        list_full_address = []
        list_street_name = []
        list_city = []
        list_postal_code = []
        list_house_number = []
        list_business_status = []
        list_rating_count = []
        list_avg_rating_score = []
        list_search_rank = []
        list_poi_brand_boolean = []
        list_api1_result = []

        for sample_id, zoom in df_pois.select("sample_id", "zoom").distinct().collect():

            df_temp = df_pois.where((col("sample_id") == sample_id)
                                    & (col("zoom") == zoom))

            if df_temp.count() > 0:

                try:

                    query = [x["category_name_tt"]
                             for x in df_temp.select("category_name_tt").collect()]

                    # Latitude, longitude and country are the same for each "sample_id" - group
                    lat = df_temp.select("latitude").first()["latitude"]
                    lon = df_temp.select("longitude").first()["longitude"]
                    country = df_temp.select("country").first()["country"]

                    # Perform query
                    temp_result = self.get_search_poi_request(param_dict={"query": query,
                                                                          "longitude": lon,
                                                                          "latitude": lat,
                                                                          "zoom": zoom,
                                                                          "country": country,
                                                                          "limit": limit})

                    api_reference_id = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                                  api_result_field="place_id")

                    api_name = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                          api_result_field="name")

                    api_lat = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                         api_result_field="latitude")

                    api_lon = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                         api_result_field="longitude")

                    # Note the conversion to str
                    api_wkt = [str(Point(x)) for x in zip([float(lo) for lo in api_lon],
                                                          [float(la) for la in api_lat])]

                    api_category_name = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                                   api_result_field="type")

                    # As not all the original categories got a non-empty query result,
                    # map the retrieved categories with the (filtered) input DataFrame
                    # to retrieve api_category_id_tt, api_category_name_tt
                    api_query = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                           api_result_field="query")

                    api_category_id_tt = [df_temp.where(col("category_name_tt") == cat).select(
                        "category_id_tt").first()["category_id_tt"] for cat in api_query]
                    api_category_name_tt = [df_temp.where(col("category_name_tt") == cat).select(
                        "category_name_tt").first()["category_name_tt"] for cat in api_query]

                    del api_query

                    api_full_address = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                                  api_result_field="full_address")

                    api_city = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                          api_result_field="city")

                    api_postal_code = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                                 api_result_field="postal_code")

                    # House number and name from "street" field
                    api_street = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                            api_result_field="street")

                    api_house_number = ["".join([i for i in s if i.isdigit()]).replace(
                        ",", "") if s is not None else None for s in api_street]
                    api_street_name = ["".join([i for i in s if not i.isdigit()]).replace(
                        ",", "") if s is not None else None for s in api_street]

                    del api_street

                    api_business_status = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                                     api_result_field="business_status")

                    api_rating_count = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                                  api_result_field="reviews")

                    api_avg_rating_score = self.flatten_list_of_query_result_sublists(api_result=temp_result,
                                                                                      api_result_field="rating")

                    # Rank
                    api_search_rank = [i for i in range(len(api_reference_id))]

                    # Empty column
                    api_poi_brand_boolean = [
                        None for _ in range(len(api_reference_id))]

                    # Run ID
                    api_api1_run_id = [manual_create_run_id(response=0,
                                                            date=get_today_date(),
                                                            digits_len_int=4)
                                       for _ in range(len(api_reference_id))]

                    # Other columns
                    api_sample_id = [
                        sample_id for _ in range(len(api_reference_id))]
                    api_provider_id = [
                        self.provider_id for _ in range(len(api_reference_id))]
                    api_country = [df_temp.select("country").first(
                    )["country"] for _ in range(len(api_reference_id))]

                    # Raw API output
                    flat_api_result = [
                        item for sublist in temp_result for item in sublist]

                    list_api1_run_id.append(api_api1_run_id)
                    list_sample_id.append(api_sample_id)
                    list_provider_id.append(api_provider_id)
                    list_reference_id.append(api_reference_id)
                    list_country.append(api_country)
                    list_wkt.append(api_wkt)
                    list_lat.append(api_lat)
                    list_lon.append(api_lon)
                    list_name.append(api_name)
                    list_category_name.append(api_category_name)
                    list_category_id_tt.append(api_category_id_tt)
                    list_category_name_tt.append(api_category_name_tt)
                    list_full_address.append(api_full_address)
                    list_street_name.append(api_street_name)
                    list_city.append(api_city)
                    list_postal_code.append(api_postal_code)
                    list_house_number.append(api_house_number)
                    list_business_status.append(api_business_status)
                    list_rating_count.append(api_rating_count)
                    list_avg_rating_score.append(api_avg_rating_score)
                    list_search_rank.append(api_search_rank)
                    list_poi_brand_boolean.append(api_poi_brand_boolean)
                    list_api1_result.append(flat_api_result)

                    del api_api1_run_id
                    del api_sample_id
                    del api_provider_id
                    del api_reference_id
                    del api_country
                    del api_wkt
                    del api_lat
                    del api_lon
                    del api_name
                    del api_category_name
                    del api_category_id_tt
                    del api_category_name_tt
                    del api_full_address
                    del api_street_name
                    del api_city
                    del api_postal_code
                    del api_house_number
                    del api_business_status
                    del api_rating_count
                    del api_avg_rating_score
                    del api_search_rank
                    del api_poi_brand_boolean
                    del flat_api_result

                    del df_temp

                except Exception as err:

                    print(
                        f"""An unknown error happened {type(err).__name__}: {err.args[0]}""")

            # Process output for Spark DataFrame
            list_api1_run_id = [[item]
                                for sublist in list_api1_run_id for item in sublist]
            list_sample_id = [[item]
                              for sublist in list_sample_id for item in sublist]
            list_provider_id = [[item]
                                for sublist in list_provider_id for item in sublist]
            list_reference_id = [[item]
                                 for sublist in list_reference_id for item in sublist]
            list_country = [[item]
                            for sublist in list_country for item in sublist]
            list_wkt = [[item] for sublist in list_wkt for item in sublist]
            list_lat = [[item] for sublist in list_lat for item in sublist]
            list_lon = [[item] for sublist in list_lon for item in sublist]
            list_name = [[item] for sublist in list_name for item in sublist]
            list_category_name = [[item]
                                  for sublist in list_category_name for item in sublist]
            list_category_id_tt = [
                [item] for sublist in list_category_id_tt for item in sublist]
            list_category_name_tt = [
                [item] for sublist in list_category_name_tt for item in sublist]
            list_full_address = [[item]
                                 for sublist in list_full_address for item in sublist]
            list_street_name = [[item]
                                for sublist in list_street_name for item in sublist]
            list_city = [[item] for sublist in list_city for item in sublist]
            list_postal_code = [[item]
                                for sublist in list_postal_code for item in sublist]
            list_house_number = [[item]
                                 for sublist in list_house_number for item in sublist]
            list_business_status = [
                [item] for sublist in list_business_status for item in sublist]
            list_rating_count = [[item]
                                 for sublist in list_rating_count for item in sublist]
            list_avg_rating_score = [
                [item] for sublist in list_avg_rating_score for item in sublist]
            list_search_rank = [[item]
                                for sublist in list_search_rank for item in sublist]
            list_poi_brand_boolean = [
                [item] for sublist in list_poi_brand_boolean for item in sublist]
            list_api1_result = [[item]
                                for sublist in list_api1_result for item in sublist]

        return (list_api1_run_id,
                list_sample_id,
                list_provider_id,
                list_reference_id,
                list_country,
                list_wkt,
                list_lat,
                list_lon,
                list_name,
                list_category_name,
                list_category_id_tt,
                list_category_name_tt,
                list_full_address,
                list_street_name,
                list_city,
                list_postal_code,
                list_house_number,
                list_business_status,
                list_rating_count,
                list_avg_rating_score,
                list_search_rank,
                list_poi_brand_boolean,
                list_api1_result)

    def process_batch_api_results(self,
                                  df_pois: pyspark.sql.dataframe.DataFrame,
                                  limit: int = 20) -> pyspark.sql.dataframe.DataFrame:
        """
        Process multiple outscrapper API calls and retrieve a DataFrame
        # TODO: This function is intended to retrieve results for Aitor's api_1. Modify appropriately (col_for_search_by)

        :param df_pois: DataFrame with information about POIs to search: name, category, longitude, latitude,...
        :type df_pois: pyspark.sql.dataframe.DataFrame
        :param limit: POI search limit, defaults to 20
        :type limit: int, optional
        :return: DataFrame with API POIs table (v2) columns
        :rtype: pyspark.sql.dataframe.DataFrame
        """

        # Columns needed:
        # api1_run_id,
        # sample_id,
        # provider_id,
        # reference_id,
        # country,
        # wkt,
        # lat,
        # lon,
        # name,
        # category_name,
        # category_id_tt,
        # category_name_tt,
        # full_address,
        # street_name,
        # city,
        # postal_code,
        # house_number,
        # business_status,
        # rating_count,
        # avg_rating_score,
        # search_rank,
        # poi_brand_boolean,
        # api1_result

        # Retrieve necessary lists via ancillary function
        (list_api1_run_id,
         list_sample_id,
         list_provider_id,
         list_reference_id,
         list_country,
         list_wkt,
         list_lat,
         list_lon,
         list_name,
         list_category_name,
         list_category_id_tt,
         list_category_name_tt,
         list_full_address,
         list_street_name,
         list_city,
         list_postal_code,
         list_house_number,
         list_business_status,
         list_rating_count,
         list_avg_rating_score,
         list_search_rank,
         list_poi_brand_boolean,
         list_api1_result) = self.perform_batch_outscrapper_api_on_pois_df(df_pois=df_pois,
                                                                           limit=limit)

        # Schema
        schema = StructType([
            StructField("api1_run_id", StringType(), True),
            StructField("sample_id", StringType(), True),
            StructField("provider_id", StringType(), True),
            StructField("reference_id", StringType(), True),
            StructField("country", StringType(), True),
            StructField("wkt", StringType(), True),
            StructField("lat", StringType(), True),
            StructField("lon", StringType(), True),
            StructField("name", StringType(), True),
            StructField("category_name", StringType(), True),
            StructField("category_id_tt", StringType(), True),
            StructField("category_name_tt", StringType(), True),
            StructField("full_address", StringType(), True),
            StructField("street_name", StringType(), True),
            StructField("city", StringType(), True),
            StructField("postal_code", StringType(), True),
            StructField("house_number", StringType(), True),
            StructField("business_status", StringType(), True),
            StructField("rating_count", StringType(), True),
            StructField("avg_rating_score", StringType(), True),
            StructField("search_rank", StringType(), True),
            StructField("poi_brand_boolean", StringType(), True),
            StructField("api1_result", MapType(
                StringType(), StringType(), True))
        ])

        # Data
        data = [(a[0], b[0], c[0], d[0], e[0], f[0], g[0], h[0], i[0], j[0], k[0], l[0], m[0], n[0], o[0], p[0], q[0], r[0], s[0], t[0], u[0], v[0], w[0])
                for a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w
                in zip(list_api1_run_id,
                       list_sample_id,
                       list_provider_id,
                       list_reference_id,
                       list_country,
                       list_wkt,
                       list_lat,
                       list_lon,
                       list_name,
                       list_category_name,
                       list_category_id_tt,
                       list_category_name_tt,
                       list_full_address,
                       list_street_name,
                       list_city,
                       list_postal_code,
                       list_house_number,
                       list_business_status,
                       list_rating_count,
                       list_avg_rating_score,
                       list_search_rank,
                       list_poi_brand_boolean,
                       list_api1_result)]

        df = spark.createDataFrame(data=data, schema=schema)

        del data

        return df


if __name__ == "__main__":

    print("- Calling Outscrapper API...")

    api = OutscrapperApi()

    result = api.get_search_poi_request(param_dict={"query": "restaurants, Madrid, Esp",
                                                    "limit": 15,
                                                    "country": "ESP"})

    print(result)

    result = api.get_search_poi_request(param_dict={"query": "restaurants",
                                                    "latitude": 40.3934355,
                                                    "longitude": -3.7158024,
                                                    "zoom": 16.03,
                                                    "country": "ESP"})

    print(result)
