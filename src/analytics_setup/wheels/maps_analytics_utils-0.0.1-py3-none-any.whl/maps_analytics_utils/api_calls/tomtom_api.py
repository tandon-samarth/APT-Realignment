from urllib.parse import quote
import logging

from .api_call import ApiCall
from pyspark.sql import DataFrame as SparkDataFrame


class TomtomApi(ApiCall):
    """
    Class that represent the TomTom API with the methods to call it
    """


    @property
    def api_key(self) -> str:
        """Key to get the access to the API"""
        return "QQxD2le5hPQanQAI1XYAAfaxWfyfpPaK"


    @property
    def provider_id(self) -> str:
        """Id to identify the provider"""
        return "tt"


    def get_geocode_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for geocoding using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for geocoding
        :rtype: str
        """
        address = param_dict.get("address")
        limit = param_dict.get("limit", 50)
        country = param_dict.get("country", None)
        address_quoted = quote(address, safe='')  # url encode also with slashes /=%2F
        if country and country == "kr":
            return "https://kr-api.tomtom.com/search/2/geocode/"+address_quoted+".json?limit="+str(limit)+"&key="+self.api_key

        return "https://api.tomtom.com/search/2/geocode/"+address_quoted+".json?limit="+str(limit)+"&key="+self.api_key


    def get_reverse_geocode_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for reverse geocoding using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for reverse geocoding
        :rtype: str
        """
        lat = str(param_dict.get("lat"))
        lon = str(param_dict.get("lon"))
        limit = param_dict.get("limit", 50)
        country = param_dict.get("country", None)
        lat_lon = str(lat)+"%2C"+str(lon)
        if country and country == "kr":
            return "https://kr-api.tomtom.com/search/2/reverseGeocode/"+lat_lon+".json?limit="+str(limit)+"&key="+self.api_key

        return "https://api.tomtom.com/search/2/reverseGeocode/"+lat_lon+".json?limit="+str(limit)+"&key="+self.api_key


    def get_search_poi_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for search POI using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for poi search
        :rtype: str
        """

        lat = str(param_dict.get("lat"))
        lon = str(param_dict.get("lon"))
        radius = str(param_dict.get("radius"))
        limit = param_dict.get("limit", 50)
        poi_name = quote(param_dict.get("name"), safe='')

        return "https://api.tomtom.com/search/2/poiSearch/" + poi_name + ".json?limit=" + str(limit) + "&openingHours=nextSevenDays&relatedPois=all&lat=" + lat + "&lon=" + lon + "&radius=" + radius + "&key="+self.api_key

    def extract_and_transform_api_result(self, iteration: int):

        # Read API results (from the Spark Streaming process)
        all_steps_RDD = self.read_api_results(iteration)

        # Transforming results from the API call:
        # Adding column that set TomTom's API result status (1 = result given, 0 = Null result)
        logging.info("Adding column that set TomTom's API result status (1 = result given, 0 = Null result)")
        all_steps_RDD_aux = all_steps_RDD.withColumn("api_status", when(col("apiResults").isNull(), 0).otherwise(1))

        # Exploding the results to get one row per TomTom API's result and keeping specific columns from reference POIs
        logging.info("Exploding the results to get one row per TomTom API's result and keeping specific columns from reference POIs...")
        step3_RDD = all_steps_RDD.select(
            "reference_id", 
            "sample_id", 
            "sample_run_id", 
            "importance_rank", 
            "classification", 
            "search_rank", 
            "search_request_string", 
            "business_status", 
            "name", 
            "lat", 
            "lon", 
            "search_radius_m", 
            "search_group", 
            posexplode_outer(col("apiResults"))
        )

        # Creating search_rank from the API response
        logging.info("Creating search_rank from the API response...")
        step3_RDD_ = (step3_RDD.withColumnRenamed("col", "api_results")
             .withColumnRenamed("pos", "api_search_rank"))

        # Trimming classification column and extracting category as well as subcategory for the reference POI
        logging.info("Trimming classification column and extracting category as well as subcategory for the reference POI...")
        # Trimming
        step3_RDD_1 = step3_RDD_.withColumn("first_trim", regexp_replace(col("classification"), '\\{"', ""))
        step3_RDD_2 = step3_RDD_1.withColumn("second_trim", regexp_replace(col("first_trim"), '"\\}', ""))
        step3_RDD_3 = step3_RDD_2.withColumn("third_trim", regexp_replace(col("second_trim"), '\\(', ""))
        step3_RDD_4 = step3_RDD_3.withColumn("fourth_trim", regexp_replace(col("third_trim"), '\\)', ""))
        step3_RDD_5 = step3_RDD_4.withColumn("fifth_trim", regexp_replace(col("fourth_trim"), '\\"', ""))

        # Spliting
        logging.info("Spliting column...")
        step3_RDD_6 = step3_RDD_5.withColumn("sixth_trim", split(col("fifth_trim"), ','))

        # Drop unnecesary columns
        logging.info("Drop unnecesary columns...")
        step3_RDD_7 = step3_RDD_6.drop(*["first_trim", "second_trim", "third_trim", "fourth_trim", "fifth_trim", "classification"])
        step3_RDD_8 = step3_RDD_7.withColumnRenamed("sixth_trim", "cat_subcat")

        # Extracting category and subcategory
        logging.info("Extracting category and subcategory...")
        step3_RDD_9 = step3_RDD_8.withColumn("category", col("cat_subcat")[0])
        step3_RDD_10 = step3_RDD_9.withColumn("subcategory", element_at(col("cat_subcat"), -1))

        # Extract columns from the TT API call result.
        # Getting first level of the TT API call JSON response.
        logging.info("Extract columns from the TT API call result.")
        logging.info("Getting first level of the TT API call JSON response...")
        step4_RDD = (step3_RDD_10
           .withColumn("tt_api_poi", from_json(col("api_results").getItem("poi"), MapType(StringType(), StringType())))
           .withColumn("tt_api_address", from_json(col("api_results").getItem("address"), MapType(StringType(), StringType())))
           .withColumn("tt_api_position", from_json(col("api_results").getItem("position"), MapType(StringType(), StringType())))
           .withColumn("tt_api_score", col("api_results").getItem("score"))
           .withColumn("tt_api_id", col("api_results").getItem("id"))
          )
        step5_RDD = (step4_RDD
           .withColumn("tt_api_categorySet", from_json(col("tt_api_poi").getItem("categorySet"), ArrayType(MapType(StringType(), StringType()))))
           .withColumn("tt_api_classifications", from_json(col("tt_api_poi").getItem("classifications"), ArrayType(MapType(StringType(), StringType()))))
           .withColumn("tt_api_brands", from_json(col("tt_api_poi").getItem("brands"), ArrayType(MapType(StringType(), StringType()))))
           .withColumn("tt_api_lat", col("tt_api_position").getItem("lat"))
           .withColumn("tt_api_lon", col("tt_api_position").getItem("lon"))
           .withColumn("tt_api_countrySecondarySubdivision", col("tt_api_address").getItem("countrySecondarySubdivision"))
           .withColumn("tt_api_streetNumber", col("tt_api_address").getItem("streetNumber"))
           .withColumn("tt_api_postalCode", col("tt_api_address").getItem("postalCode"))
           .withColumn("tt_api_municipality", col("tt_api_address").getItem("municipality"))
           .withColumn("tt_api_countrySubdivision", col("tt_api_address").getItem("countrySubdivision"))
           .withColumn("tt_api_localName", col("tt_api_address").getItem("localName"))
           .withColumn("tt_api_streetName", col("tt_api_address").getItem("streetName"))
           .withColumn("tt_api_countryCodeISO3", col("tt_api_address").getItem("countryCodeISO3"))
           .withColumn("tt_api_countryCode", col("tt_api_address").getItem("countryCode"))
           .withColumn("tt_api_municipalitySubdivision", col("tt_api_address").getItem("municipalitySubdivision"))
           .withColumn("tt_api_freeformAddress", col("tt_api_address").getItem("freeformAddress"))
           )
        step6_RDD = (step5_RDD
           .withColumn("tt_api_poiName", col("tt_api_poi").getItem("name"))
           .withColumn("tt_api_poiURL", col("tt_api_poi").getItem("url"))
           .withColumn("tt_api_poiBrand", col("tt_api_brands").getItem(0).getItem("name"))
           .withColumn("tt_api_poiPhone", col("tt_api_poi").getItem("phone"))
           .withColumn("tt_api_categoryId", col("tt_api_categorySet").getItem(0).getItem("id"))
           .withColumn("tt_api_code", col("tt_api_classifications").getItem(0).getItem("code"))
          )

        logging.info("Getting just the columns that are needed...")
        # Columns to be dropped.
        columns_to_drop = [
            "tt_api_poi",
            "tt_api_address",
            "tt_api_position",
            "tt_api_categorySet",
            "tt_api_classifications",
            "tt_api_brands"
            ]

        step7_RDD = step6_RDD.drop(*columns_to_drop)

        logging.warning("Renaming columns...")
        # Renaming and adding some extra columns that are needed
        step8_RDD = (step7_RDD
           .withColumnRenamed("lat", "ref_lat")
           .withColumnRenamed("lon", "ref_lon")
           .withColumnRenamed("tt_api_id", "api_poi_id")
           .withColumnRenamed("tt_api_lat", "api_lat")
           .withColumnRenamed("tt_api_lon", "api_lon")
           .withColumnRenamed("tt_category_id", "ref_in_tt_category_id")
           .withColumnRenamed("tt_api_countrySecondarySubdivision", "api_countrySecondarySubdivision")
           .withColumnRenamed("tt_api_streetNumber", "api_streetNumber")
           .withColumnRenamed("tt_api_postalCode", "api_postalCode")
           .withColumnRenamed("tt_api_municipality", "api_municipality")
           .withColumnRenamed("tt_api_countrySubdivision", "api_countrySubdivision")
           .withColumnRenamed("tt_api_localName", "api_localName")
           .withColumnRenamed("tt_api_streetName", "api_streetName")
           .withColumnRenamed("tt_api_countryCodeISO3", "api_countryCodeISO3")
           .withColumnRenamed("tt_api_countryCode", "api_countryCode")
           .withColumnRenamed("tt_api_municipalitySubdivision", "api_municipalitySubdivision")
           .withColumnRenamed("tt_api_freeformAddress", "api_freeformAddress")
           .withColumnRenamed("tt_api_poiName", "api_poiName")
           .withColumnRenamed("tt_api_poiURL", "api_poiURL")
           .withColumnRenamed("tt_api_poiBrand", "api_poiBrand")
           .withColumnRenamed("tt_api_poiPhone", "api_poiPhone")
           .withColumnRenamed("tt_api_categoryId", "api_categoryId")
           .withColumnRenamed("tt_api_code", "api_code")
           .withColumnRenamed("tt_api_score", "api_score")
           .withColumn("api_provider_id", lit("tt"))    # this set ups the provider that has been called (API call)
           .withColumn("api2_run_id", lit(None))
          )
        
        return step8_RDD

if __name__ == "__main__":
    print("- Calling TomTom API...")
    api = TomtomApi()
    result = api.call_geocode_api("13219 SOUTH KIMBERLY-CLARK PLACE JENKS OK 74037 USA", 5)
    print(result)

    print("- Reverse method: Calling TomTom API...")
    api = TomtomApi()
    result = api.call_reverse_geocode_api("35.96846985552107",  "-95.92487593711283", 5)
    print(result)

    print("- Calling TomTom API for korea...")
    api = TomtomApi()
    result = api.call_geocode_api("1층, 마이티빌딩, 199-13 Euljiro 2(i)-ga, Jung-gu, Seoul, Corea del Sur", 5, "korea")
    print(result)

    print("- Reverse method: Calling TomTom API...")
    api = TomtomApi()
    result = api.call_reverse_geocode_api("37.56382",  "126.99471", 5, "korea")
    print(result)