from urllib.parse import quote

import typing

from .api_call import ApiCall


class BingApi(ApiCall):
    """
    Class that represent the Bing API with the methods to call it
    """


    @property
    def api_key(self) -> str:
        """Key to get the access to the API"""
        return "AnAl6cWxZSxruvuVmG28XQGRsZSyEbFStDbrPoWY0JRijVUTEzEzv6Qqqf_pahib"


    @property
    def provider_id(self) -> str:
        """Id to identify the provider"""
        return "bg"


    def get_geocode_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for geocoding using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for geocoding
        :rtype: str
        """
        address = param_dict.get("address")
        address_quoted = quote(address, safe='')  # url encode also with slashes /=%2F
        return "https://dev.virtualearth.net/REST/v1/Locations?q="+address_quoted+"&output=json&key="+self.api_key


    def get_reverse_geocode_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for reverse geocoding using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for reverse geocoding
        :rtype: str
        """
        lat = str(param_dict.get("lat"))
        lon = str(param_dict.get("lon"))
        lat_lon = str(lat)+"%2C"+str(lon)
        return "http://dev.virtualearth.net/REST/v1/Locations/"+lat_lon+"?output=json&key="+self.api_key


    def get_search_poi_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for search POI using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for poi search
        :rtype: str
        """
        pass


if __name__ == "__main__":
    print("- Calling Bing API...")
    api = BingApi()
    result = api.call_geocode_api("13219 SOUTH KIMBERLY-CLARK PLACE JENKS OK 74037 USA", 5)
    print(result)

    print("- Reverse method: Calling Bing API...")
    api = BingApi()
    result = api.call_reverse_geocode_api("35.96846985552107",  "-95.92487593711283", 5)
    print(result)