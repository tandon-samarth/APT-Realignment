from urllib.parse import quote

import typing

from .api_call import ApiCall


class OSMApi(ApiCall):
    """
    Class that represent the OSM API with the methods to call it
    """


    @property
    def api_key(self) -> str:
        """Key to get the access to the API"""
        return ""


    @property
    def provider_id(self) -> str:
        """Id to identify the provider"""
        return "osm"


    def get_geocode_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for geocoding using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for geocoding
        :rtype: str
        """
        address = param_dict.get("address")
        address_quoted = quote(address, safe='')  # url encode also with slashes /=%2F
        return "https://nominatim.openstreetmap.org/search?q="+address_quoted+"&format=jsonv2&addressdetails=1"


    def get_reverse_geocode_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for reverse geocoding using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for reverse geocoding
        :rtype: str
        """
        lat = str(param_dict.get("lat"))
        lon = str(param_dict.get("lon"))
        return "https://nominatim.openstreetmap.org/reverse.php?lat="+str(lat)+"&lon="+str(lon)+"&addressdetails=1&extratags=1&namedetails=1&zoom=18&format=jsonv2"


    def get_search_poi_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for search POI using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for poi search
        :rtype: str
        """
        pass


if __name__ == "__main__":
    print("- Calling OSM API...")
    api = OSMApi()
    result = api.call_geocode_api("135 pilkington avenue, birmingham", 5)
    print(result)

    print("- Calling Reverse geocoding OSM API...")
    api = OSMApi()
    result = api.call_reverse_geocode_api("35.96846985552107",  "-95.92487593711283", 5)
    print(result)