from abc import ABC, abstractmethod
import json
from urllib.parse import quote
import urllib.request
import logging
from retry import retry
import typing
from maps_analytics_utils.utils import spark_utils
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import DataFrame as SparkDataFrame
import time

# TODO: Put it into the __init__.py file so it can be globally set
# logging configuration: include time of logging.info
logging.basicConfig(format='%(asctime)s %(levelname)-8s %(message)s', 
                    level=logging.ERROR,
                    datefmt='%Y-%m-%d %H:%M:%S')

class ApiCall(ABC):
    """
    Declares the operations that all Api calls must implement
    """

    def __init__(self, qps_dict: dict = None, pois_limit: int = 20, saveloc: str = None, checkpoint: str = None, max_iter: int = None) -> None:
        """Parametrized constructor of the class.

        :param qps_dict: Dictionary with the following parameters to be set:
            qps: Number (int) of queries per second to the API. 
            n_retries: Number (int) of retries in case the call fails.
            factor: A factor (float) which determine how much percentage of the QPS is destine to do API calls (the rest will be used for the retries)
        :type qps_dict: typing.Optional(dict, None)
        :param pois_limit: Limit for the number of POIs returned in the API response.
        :type pois_limit: typing.Optional(int, None)
        :param saveloc: Location where to store each pipeline results from Spark Streaming process.
        :type saveloc: str
        :param checkpoint: Location to store files that helps build fault-tolerant and resilient Spark applications.
        :type checkpoint: str
        :param max_iter: Integer that set the maximum amount of iteration in the loop to avoid Null values coming from the API respones.
        :type max_iter: int
        """
        
        # QPS for the spark streaming
        self.qps_dict = qps_dict
        # Spark session
        self.spark_session = SparkSession.builder.getOrCreate()
        # POIs limit for each call
        self.pois_limit = pois_limit
        self.saveloc = "/mnt/raw/pssr-metric/api2_pois_aux_auto_"
        self.checkpoint = "/mnt/raw/pssr-metric/checkpoint_auto_"
        self.max_iter = 1000


    @property
    @abstractmethod
    def api_key(self) -> str:
        """Key to get the access to the API"""
        pass


    @property
    @abstractmethod
    def provider_id(self) -> str:
        """Id to identify the provider"""
        pass


    @abstractmethod
    def get_geocode_request(self, address: str, limit: int = 100, country: str = None) -> str:
        """Constructs and returns the request for geocoding using a given address

        :param address: Address
        :type address: str
        :param limit: Limit of results, defaults to 100
        :type limit: int, optional
        :param country: Country, defaults to None
        :type country: str, optional
        :return: Request for geocoding
        :rtype: str
        """
        pass


    @abstractmethod
    def get_reverse_geocode_request(self, lat: typing.Union[str, float], lon: typing.Union[str, float], limit: int = 100, country: str = None) -> str:
        """Constructs and returns the request for reverse geocoding using some given coordinates

        :param lat: Latitude
        :type lat: typing.Union[str, float]
        :param lon: Longitude
        :type lon: typing.Union[str, float]
        :param limit: Limit of results, defaults to 100
        :type limit: int, optional
        :param country: Country, defaults to None
        :type country: str, optional
        :return: Request for reverse geocoding
        :rtype: str
        """
        pass


    @abstractmethod
    def get_search_poi_request(self, param_dict: dict) -> str:
        """Constructs and returns the request for search POI using given dictionary with all the desired params

        :param param_dict: Dictionary with all the params to be included in the request
        :type param_dict: dict
        :return: Request query for poi search
        :rtype: str
        """

        pass


    @retry((urllib.request.HTTPError), tries=5, delay=1, backoff=2)
    def call_api(self, dict_params: dict, call_type: str) -> typing.Dict:
        """Method that make a call to the API given a endpoint type and returns a dictionary with the results

        :param dict_params: Dictionary with all the params in the call
        :type dict_params: dict
        :param call_type: String with the name of the endpoint type
        :type call_type: str
        :raises Exception: Error when selecting call: please, specify a correct call name (e.g. searchPoi, reverseGeocode, etc)
        :return: Dictionary with the results from call
        :rtype: typing.Dict
        """

        # Call to diferent endpoints given a call type
        if call_type == "poiSearch":
            logging.info("Calling searchPoi API end point...")
            
            try:
                httpurl = self.get_search_poi_request(dict_params)

            except TypeError as err:
                logging.error(f"TypeError: {err}")

        # TODO: Search by category (Nearby Search en google)
        # TODO: Search by brand

        elif call_type == "reverseGeocode": 
            #logging.info("Reverse Geocoding: lat={lat}, lon={lon}".format(lat=dict_params.get("lat"), lon=dict_params.get("lon")))

            try:
                httpurl = self.get_reverse_geocode_request(dict_params)
                
            except TypeError as err:
                logging.error(f"TypeError: {err}")

        elif call_type == "geocode":
            #logging.info("Geocoding: address ={address}".format(address=dict_params.get("address")))
            try:
                httpurl = self.get_geocode_request(dict_params)
                
            except TypeError as err:
                logging.error(f"TypeError: {err}")

        else:
            raise Exception("Error when selecting call: please, specify a correct call name (e.g. poiSearch, reverseGeocode, etc)")

        data = None

        # Open the request
        with urllib.request.urlopen(httpurl) as url:
            # Parses JSON from the URL
            try:
                data = json.loads(url.read().decode())
            except json.decoder.JSONDecodeError:
                logging.error("Error while trying to convert the result to JSON")

        return data


    def set_qps(self):

        self.spark_session.sparkContext.setSystemProperty(
            "spark.streaming.receiver.maxRate", str(self.qps_dict.get("qps", 100) * (self.qps_dict.get("factor", 0,7) / self.qps_dict.get("n_retries"))))
        self.spark_session.sparkContext.setSystemProperty(
            "spark.streaming.backpressure.initialRate", str(self.qps_dict.get("qps", 100) * (self.qps_dict("factor", 0,7) / self.qps_dict.get("n_retries"))))
        self.spark_session.sparkContext.setSystemProperty("spark.streaming.backpressure.enabled", "true")

    def call_api_if_null(self, input_params: dict, call_type: str, last: dict) -> dict:
        """
        Call to TomTom's API with option to retry
        :param row: Array with relevant fields from the row
        :param limit: int limit in the number of results from TT API
        :param apiKey: str Api Key from TomTom
        :return: Array with the results
        """
        
        logging.info("LAST: ")
        logging.info(last)
        
        if last:
            # tt_api_results = callTTApiSearch(row, limit, apiKey)
            # Call to its API
            tt_api_results = self.call_api(input_params, call_type)
            
        else:
            tt_api_results = None
        
        return tt_api_results

    def udf_call_api(self, row: dict, last: dict) -> udf:
        udf_call = udf(
            lambda row, last: self.call_api_if_null(row, last, self.pois_limit, self.api_key), ArrayType(MapType(StringType(), StringType())))

        return udf_call

    def do_withColumn_api(self, original_step: SparkDataFrame) -> SparkDataFrame:
        """
        Do the call to TomTom's API and generate the spent number of api calls.
        :param original_step: dataframe First spark dataframe to work with (dataframe with the reference pois from Google)
        :return step_n_S: dataframe with the results of the TomTom API calls and the reference data from Google
        """
        
        # Call to the TomTom's API
        step_n_S = (original_step
            .withColumn('apiCalls2', when(col('apiResults').isNull(), col('apiCalls') + 1).otherwise(col('apiCalls')))
            .withColumn('apiResults2', when(col('apiResults').isNull(), self.udf_call_api(
                array(col("name"), col("lat"), col("lon"), col("search_radius_m").cast("string")), col('apiResults').isNull())).otherwise(col('apiResults')))
                )
        
        # Droping old columns
        step_n_S = step_n_S.drop(*["apiResults", "apiCalls"])
        
        # Renaming columns
        step_n_S = step_n_S.withColumnRenamed("apiResults2", "apiResults")
        step_n_S = step_n_S.withColumnRenamed("apiCalls2", "apiCalls")
        
        return step_n_S

    def write_step(self, step, saveloc: str, checkpoint: str):
        """
        Void function
        """
        
        logging.info("Writing results to: {location}".format(location=saveloc))
        
        # Write stream
        streamQuery = (step
            .writeStream
            .format("delta")
            .option("checkpointLocation", checkpoint)
            .option("path", saveloc)
            .outputMode("append")
            .trigger(once=True)  # To stop when it finishes the process
            .start()
        )
        
        logging.info("Waiting to write results...")
        logging.info("Num. of active streams: " + str(len(spark.streams.active)))
        
        # Waits for the streamQuery to finish processing
        streamQuery.awaitTermination()
        
        logging.info("Results has been written. Ready to be read")
        logging.info("Num. of active streams: " + str(len(spark.streams.active)))

    def do_streaming_api_calls_(self, input_data: SparkDataFrame) -> int:
        """Function that execute the process of calling the API desired using Spark Streaming, and writes the results in the datalake in a
        temporary file (saveloc_)

        :param input_data: Input data to be used as a reference to call the desired API.
        :type input_data: SparkDataFrame
        :return: Iteration number so it can be known how many iterations were needed to get zero nulls in the API response.
        :rtype: int
        """

        # Read reference POIs table
        # "/mnt/raw/pssr-metric/selected_reference_pois
        sdf_reference_pois = spark_utils.read_spark_dataframe(input_data, "delta")
  
        # Start chrono
        start = time.time()

        # Initialize two extra columns:
        #     apiResults: for the TomTom API
        #     apiCalss: for the number of retries for that particular reference POI
        sdf_reference_pois = (sdf_reference_pois
            .withColumn('apiResults', lit(None).cast( ArrayType(MapType(StringType(), StringType())) ))
            .withColumn('apiCalls',lit(0)))

        # Count number of reference POIs to be used to call the provider API
        n_reference = sdf_reference_pois.select([count(when(col("apiResults").isNull(), True))])
        logging.info("Number of reference POIs: {n_reference}".format(n_reference=n_reference))
        
        iteration = 1    # Iterations that index the steps done
        # all_results = False    # Indicator that tells if TomTom API call has all results (and not any Null)
        remaining = 1
        
        # Do calls to TomTom API until there's no null results
        while remaining > 0 and iteration <= self.max_iter:
            
            logging.info("ENTERING WHILE LOOP")
            logging.info("Iteration " + str(iteration))
            
            # Set iteration for the step
            checkpoint_ = self.checkpoint + str(iteration)
            saveloc_ = self.saveloc + str(iteration)
            logging.info("saveloc_: " + saveloc_)
            logging.info("checkpoint_: " + checkpoint_)

            # Call TomTom API for each reference POI
            sdf_api2_pois_iteration = self.do_withColumn_api(original_step=sdf_reference_pois, udf_call=udf_call)

            # Write results into the data lake
            self.write_step(sdf_api2_pois_iteration, saveloc_, checkpoint_)
            # Time spent in the writing
            end = time.time()
            time_elapsed = end - start
            logging.info("Total time elapsed: {0} seconds".format(time_elapsed))
            logging.info("Total time elapsed: {0} minutes".format(time_elapsed/60))
            
            logging.info("Starting to READ data...")
            
            # Read new step for next iteration
            sdf_api2_pois_iteration = spark_utils.readStream_spark_dataframe(self.saveloc, "delta")

            logging.info("Data read. Checking api results...")

            # Control while loop
            checker_sdf = spark_utils.read_spark_dataframe(saveloc_, "delta")
                
            # Adding column that set TomTom's API result status (1 = result given, 0 = Null result)
            checker_aux = checker_sdf.withColumn("api_status", when(col("apiResults").isNull(), 0).otherwise(1))#.withColumn("api_status2", when(col("apiResults2").isNull(), 0).otherwise(1))
            checker_aux.groupBy(["api_status", "apiCalls"]).count().show()
            
            # Remaining nulls in the TomTom's API results
            remaining = checker_sdf.filter(col("apiResults").isNull()).count()
            
            logging.info("EXITING WHILE LOOP (it "+str(iteration) + ", remaining " + str(remaining) + ")")
            
            # Increase iteration
            iteration = iteration + 1

        # TODO: Delete all temporary files created in each iteration.
        
        # Time spent in the whole process
        # Stop chrono to measure elapsed time
        end = time.time()
        # Time elapsed
        time_elapsed = end - start
        logging.info("Total time elapsed: {0} seconds".format(time_elapsed))
        logging.info("Total time elapsed: {0} minutes".format(time_elapsed/60))
        
        return iteration
  
    def read_api_results(self, iteration: int) -> SparkDataFrame:
        """Method that reads the results from the API call. It reads last iteration from the loop done in Spark Streaming to call the API

        :param iteration: Last iteration of the loop that calls the API until there are no Nulls in the responses.
        :type iteration: int
        :return: Spark Dataframe with all the results from the API.
        :rtype: SparkDataFrame
        """

        logging.info("Reading results from the API call. It reads last iteration from the loop done in Spark Streaming to call the API.")
        # Substracting one to the last iteration to get the actual last iteration (the counter starts at 1, that's why)
        saveloc_allsteps = self.saveloc_auto + str(iteration - 1)    # str(iteration - 1)
        logging.info(saveloc_allsteps)

        # Read last iteration (it has all the results)
        all_steps_RDD = spark_utils.read_spark_dataframe(saveloc_allsteps, "delta")

        return all_steps_RDD

    def sorting_api2_pois_columns(self, input_sdf: SparkDataFrame) -> SparkDataFrame:
        """Method that sort columns for the table api2_pois so it matches the structure of this table in the Data Lake.

        :param input_sdf: Input Spark Dataframe where all the final data for api2_pois table is.
        :type input_sdf: SparkDataFrame
        :return: Spark Dataframe with all the date for api2_pois table already sorted.
        :rtype: SparkDataFrame
        """

        output_sdf = input_sdf.select([
            "api2_run_id",
            "sample_id",
            "sample_run_id",
            "reference_id",
            "importance_rank",
            "search_rank",
            "search_request_string",
            "business_status",
            "name",
            "cat_subcat",
            "category",
            "subcategory",
            "ref_lat",
            "ref_lon",
            "search_radius_m",
            "location_distance_m",
            "search_group",
            "api_provider_id",
            "api_score",
            "api_search_rank",
            "api_poi_id",
            "api_lat",
            "api_lon",
            "api_countrySecondarySubdivision",
            "api_streetNumber",
            "api_postalCode",
            "api_municipality",
            "api_countrySubdivision",
            "api_localName",
            "api_streetName",
            "api_countryCodeISO3",
            "api_countryCode",
            "api_municipalitySubdivision",
            "api_freeformAddress",
            "api_poiName",
            "api_poiURL",
            "api_poiBrand",
            "api_poiPhone",
            "api_categoryId",
            "api_code",
            "api_results"
            ])
        
        return output_sdf
        