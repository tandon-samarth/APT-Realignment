import pandas as pd 
import numpy as np 
import geopandas as gpd
import psycopg2
import shapely 
import typing 


def convert_coordinates_to_query(x:gpd.GeoSeries) -> str:
    """Takes a coordinates geoseries and converts it into a string to build a query in Postgres
    
    :param x: coordinates
    :type x: geopandas.GeoSeries
    :return: string to build a spatial query (table) 
    :rtype: str
    """
    
    # Create index for each address and convert coordinates to WKT
    values = list(zip(x.index.tolist(), x.to_wkt()))
    values_str = ','.join([str(value) for value in values])
    
    return  "(VALUES " + values_str + ")"


def get_country_schema_osm(iso_code:str, 
                           conn:psycopg2.extensions.connection) -> str:
    """Finds schema that contains the buildings for further querying
    
    :param iso_code: ISO3 code of a country ('USA', not 'US')
    :type iso_code: str
    :param conn: connection to OSM database
    :type conn: 
    :return: string for the country iso code
    :rtype: str
    """
    
    # All schemas in database
    query_schemas = """
    SELECT table_schema, table_name
    FROM information_schema.tables
    WHERE table_schema != 'pg_catalog'
    AND table_schema != 'information_schema'
    AND table_type='BASE TABLE'
    ORDER BY table_schema, table_name
    """
    

    # Filter the one we are looking for
    schemas_table = pd.read_sql(query_schemas, conn)
    country_schema = schemas_table.loc[schemas_table.table_schema.str.contains(iso_code, case=False)].table_schema.unique()[0]


    return country_schema


def query_building_in_point(x:gpd.GeoSeries, 
                            schema:str, 
                            conn:psycopg2.extensions.connection) -> gpd.GeoDataFrame:

    """Creates a query to find if point is within some building
    :param x: coordinates to search
    :type x: geopandas.geoseries.GeoSeries
    :param schema: schema of OSM Clean database to query
    :type schema: str
    :param conn: connection object of OSM database
    :type conn: psycopg2.extensions.connection
    :return: string to build a spatial query (table) 
    :rtype: str
    """
        
        
    # Create query for point in building
    query_coordinates = """select index_searched_query,  st_geomfromtext (coordinates, 4326)  coordinates 
    from """ + convert_coordinates_to_query(x) + " as t (index_searched_query, coordinates)"
    
    sample_query = """
    with sample as ({query_coordinates}) 
        select 
        point.index_searched_query
    ,	point.coordinates
    ,	poly.osm_id 
    , poly.building
    ,	st_astext(poly.way) building_shape
    ,	poly.tags
    from sample as point
    left join {schema}.planet_osm_polygon poly
        --on 1=1
        on ST_Within(coordinates, poly.way)
    where poly.building is not null
    """.format(query_coordinates=query_coordinates, schema=schema)
    
    
    # Connect to DB and get result
    point_in_building = gpd.GeoDataFrame.from_postgis(sample_query, conn, geom_col='coordinates')
    point_in_building['building_shape'] = gpd.GeoSeries.from_wkt(point_in_building['building_shape'])
    
    
    return point_in_building


def transform_polygon_results(polygon_addresses:dict) -> pd.DataFrame:
    """Auxiliary function for 'polygon_by_provider' function to help parse the buildings by country

    :param polygon_addresses: dictionary where the key is the ISO-3 code of a country. 
    The dictionary contains the buildings that where found for each provider and address
    :type polygon_addresses: dict
    :return: pandas.DataFrame containing all the OSM buildings ids for a the addresses
    :rtype: pd.DataFrame
    """
    
    buildings_validation = []

    # Iterate over countries
    for key in polygon_addresses.keys():
        country_polygons = polygon_addresses[key]

        # Merge responses by provider
        country_polygons = [polygon.set_index('index_searched_query') for polygon in country_polygons]
        country_polygons_df = country_polygons[0]
        for i in range(1, len(country_polygons)):
            country_polygons_df = pd.merge(country_polygons_df, country_polygons[i], how='outer', left_index=True, right_index=True)

        # Add country and append to list
        country_polygons_df['country'] = key
        buildings_validation.append(country_polygons_df.reset_index())
    
    
    # Concatenate all countries
    buildings_validation_df = pd.concat(buildings_validation, ignore_index=True)


    return buildings_validation_df


def polygon_by_provider(df:pd.DataFrame, 
                        country_codes:typing.List[str],
                        conn:psycopg2.extensions.connection,
                        providers:list=['tt', 'go', 'he']) -> pd.DataFrame:
    """Finds the polygons that contains some provider coordinates
    
    :param df: DataFrame that contains addresses and providers lat lon in a same row.
    :type df: pd.DataFrame
    :param country_codes: list containing ISO-3 country codes (i.e, ESP instead of ES)
    :type country_codes: list
    :param conn: connection object to the OSM clean database
    : type conn: psycopg2.extensions.connection
    :param providers: list containing the name in the original DataFrame of the providers to compare. Defaults to ['tt', 'go', 'he']
    :type providers: list
    :return: DataFrame with the polygon responses for all addresses that were able to be spatially matched
    :rtype: pd.DataFrame
    """
    
    
    # Copy DataFrame and create coordinates columns
    df_copy = df.copy()
    for provider in providers:
        df_copy['coordinates_' + provider] = df_copy.apply(lambda x: shapely.geometry.Point(x['provider_lon_'+provider], x['provider_lat_'+provider]), axis=1)
    
    # Convert to GeoDataFrame and for each provider find the polygon in 3G that contains it
    geo_df = gpd.GeoDataFrame(df_copy)
 
 
    polygon_addresses = {}
    for country in country_codes:
        # Filter country and loop over providers
        country_provider_response_match = geo_df.loc[geo_df.country_code_component_he==country]
        schema = get_country_schema_osm(country, conn)
        country_polygons = []
        for provider in providers:
        # Make query in 3G DB to see the polygon that contains a set of coordinates
            col_coordinate = f'coordinates_{provider}'
            country_provider_pib_df = query_building_in_point(country_provider_response_match[col_coordinate], schema, conn)

            # Rename columns to mantain provider trazability and append to list
            country_provider_pib_df.columns = [col if col=='index_searched_query' else col + f'_{provider}' for col in country_provider_pib_df.columns]
            country_polygons.append(country_provider_pib_df)
        polygon_addresses[country] = country_polygons

    conn.close()
    
    
    return transform_polygon_results(polygon_addresses)