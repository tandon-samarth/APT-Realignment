import pandas as pd
import country_converter
import geopandas as gpd
import shapely
from addressing.utils import dbconnection
from addressing.rca.mnr import convert_coordinates_to_query


def find_osm_schema(country:str, latest:bool or None=True) -> pd.DataFrame:
    """Gets the schema in the Openmap's 3G database to make a spatial query

    :param country: country code in ISO2 or ISO3
    :type country: str
    :param latest: boolean or None indicating whether to return the latest version of Openmap product, defaults to True
    :type latest: bool or None, optional
    :return: DataFrame with the relevant country schemas
    :rtype: pd.DataFrame
    """
    
    
    # Standarize country input to ISO3
    country_iso3 = country_converter.convert(country, to='ISO3')
    
    
    # Query all schemas in Openmap database
    _, conn = dbconnection.connect('../sql/database.ini', 'osm-clean')
    schemas_df = pd.read_sql('SELECT nspname FROM pg_catalog.pg_namespace', 
                             conn)
    conn.close()
    
    # Filter relevant country
    country_schemas = (schemas_df
                    .loc[schemas_df.nspname.str.contains(country_iso3, 
                                                            case=False)]
                    .reset_index(drop=True)
                    )

    
    country_schemas['date'] = country_schemas.nspname.str.extract('([0-9]+)')
    country_schemas['schema'] = country_schemas.nspname.str.replace('_[0-9]+.*', '')
    country_schemas['is_latest'] = country_schemas.date==country_schemas.groupby('schema').date.max()[0]

    # Return schemas
    if latest:
        return country_schemas.loc[country_schemas.is_latest==latest].reset_index(drop=True)
    else:
        return country_schemas
    

def osm_lookup(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, radius:int or float=50) -> pd.DataFrame:
    """Performs spatial queries of a list of coordinates in MNR to get the APTs near the addresses
    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the addresses to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param radius: radius in meters to look around the coordinates to retrieve the nearby APTs,  defaults to 50
    :type radius: int or float, optional
    :return: APTs in MNR near the coordinates
    :rtype: pd.DataFrame
    """


    # Create query for addresses to reverse lookup
    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                         from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    
    
    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', 'osm-clean')
        
        
        query_buffers = """
        with sample as ({query_coordinates})
                        
        ,	buffers as (
                select  
                    sample.index_searched_query
                    , sample.coordinates
                    , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
                from sample
                )

        select 
            buffers.index_searched_query
        ,   buffers.coordinates
        ,   '{date}' as release_date
        ,   '{version}' as product_version
        ,   st_astext(buffers.buffer) buffer
        ,	node.osm_id
        ,	st_astext(node.way) geom
        ,	node.tags
        ,	node."addr:housenumber" housenumber
        ,	node."addr:interpolation" hnr_interpolation
        ,	node.admin_level
        ,	node.cntry_code country_code
        ,   road.road as road_name
        from buffers

        join {schema}.planet_osm_point node
            on ST_Intersects(buffers.buffer, node.way)
        
        join lateral (
            SELECT name
            FROM {schema}.planet_osm_line road
            ORDER BY road.way <-> node.way
            LIMIT 1
            ) AS road
        ON true

        union all

        select 
            buffers.index_searched_query
        ,   buffers.coordinates
        ,   '{date}' as release_date
        ,   '{version}' as product_version
        ,   st_astext(buffers.buffer) buffer
        ,	poly.osm_id
        ,	st_astext(st_centroid(poly.way)) geom
        ,	poly.tags
        ,	poly."addr:housenumber" housenumber
        ,	poly."addr:interpolation" hnr_interpolation
        ,	poly.admin_level
        ,	node.cntry_code country_code
        ,   road.road as road_name
        from buffers

        join {schema}.planet_osm_polygon poly
            on ST_Intersects(buffers.buffer, poly.way)
        
        join lateral (
            SELECT name
            FROM {schema}.planet_osm_line road
            ORDER BY road.way <-> st_centroid(poly.way)
            LIMIT 1
            ) AS road
            ON true

        where not (poly."addr:housenumber" is null and poly."addr:interpolation" is null)
        """.format(query_coordinates=query_coordinates,
                   radius=radius, 
                   date=row.date,                   
                   schema=row.nspname,
                   version=row.nspname)
     
         # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_buffers, conn, geom_col='coordinates')
        spatial_query_result['buffer'] = gpd.GeoSeries.from_wkt(spatial_query_result['buffer'])
        spatial_query_result['geom'] = gpd.GeoSeries.from_wkt(spatial_query_result['geom']) 
        
        
        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
    
    
    return gpd.GeoDataFrame(lookup_df)
    
    
def parse_osm_tags(df:pd.DataFrame) -> pd.DataFrame:
    """Parses the OSM tags to extract address info

    :param df: DataFrame from OSM result
    :type df: pd.DataFrame
    :return: DataFrame with added columns for address components
    :rtype: pd.DataFrame
    """
    
    # Create copy of
    df_copy = df.copy()
    
    
    # Split tags into list
    df_copy['tags_list'] = df_copy.tags.str.split('",')
    df_copy['tags_list'] = df_copy.tags_list.apply(lambda x:  [tag.split('=>') for tag in x])
    
    
    # Parse components
    df_copy['city'] = df_copy.tags_list.apply(lambda x: [tag[1].replace('"', '').strip() 
                                                                            for tag in x if 'city' in tag[0]][0])

    df_copy['street'] = df_copy.tags_list.apply(lambda x: [tag[1].replace('"', '').strip() 
                                                                            for tag in x if 'street' in tag[0]][0])

    df_copy['postcode'] = df_copy.tags_list.apply(lambda x: [tag[1].replace('"', '').strip() 
                                                                                for tag in x if 'postcode' in tag[0]])

    df_copy['postcode'] = df_copy.postcode.apply(lambda x: x[0] if x else None)
    
    
    return df_copy.drop(columns='tags_list')
 
  
if __name__=='__main__':
    # Create test dataframe
    test_addresses = [('11-97 DE ENTREE AMSTERDAM 1101 HE NLD', 52.31177019833552, 4.939634271503648),
                    ('Aalsterweg 303, 5644 RL Eindhoven, NL', 51.41176179168882, 5.482757611072691),
                    ('Ammunitiehaven 343 2511 XM s Gravenhage NL', 52.07742315143409, 4.3212179573462075),
                    ('Baarsweg 148, 3192 VB, Hoogvliet Rotterdam, Ne...', 51.856975720153564, 4.350903401715045),
                    ('Baas Gansendonckstraat 3, 1061CZ Amsterdam, NL', 52.37733757641722, 4.840407597295104)
                    ]


    test_df = pd.DataFrame(test_addresses, columns=['searched_query', 'lat', 'lon'])
    test_df['coordinates'] = test_df.apply(lambda x: shapely.geometry.Point(x.lon, x.lat), axis=1)
    test_gdf = gpd.GeoDataFrame(test_df, geometry='coordinates')


    # Country schema
    nld_openmap_schema = find_osm_schema('nld')
    nld_openmap_result = osm_lookup(test_gdf.coordinates, nld_openmap_schema)
    nld_openmap_result = parse_osm_tags(nld_openmap_result)
