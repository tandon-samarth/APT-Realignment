import pandas as pd
import country_converter
import geopandas as gpd
import shapely
from addressing.utils import dbconnection


def convert_coordinates_to_query(x:gpd.GeoSeries) -> str:
    """Takes a coordinates geoseries and converts it into a string to build a query in Postgres
    
    :param x: coordinates
    :type x: geopandas.GeoSeries
    :return: string to build a spatial query (table) 
    :rtype: str
    """
    
    # Create index for each address and convert coordinates to WKT
    values = list(zip(x.index.tolist(), x.to_wkt()))
    values_str = ','.join([str(value) for value in values])
    
    return  "(VALUES " + values_str + ")"


def find_country_schemas(country:str, latest:bool or None=True) -> pd.DataFrame:
    """Find the database and schemas to query in MNR
    
    :param country: country code in ISO2 or ISO3
    :type country: str
    :param latest: boolean or None indicating whether to return the latest version of MNR, defaults to True
    :type latest: bool or None, optional
    :return: DataFrame with the relevant country schemas
    :rtype: pd.DataFrame
    """
    
    
    # Standarize country input to ISO3
    country_iso3 = country_converter.convert(country, to='ISO3')

    # Query MNR databases to get where the database and schema we need to query are 
    sections = ['eur-cas-mnr', 'lam-mea-nam-oce-sea-mnr']
    schemas_df = pd.DataFrame()
    
    # Loop over MNR databases and retrieve schemas
    for section in sections:
        _, conn = dbconnection.connect('../sql/database.ini', section)
        schema = pd.read_sql('SELECT nspname FROM pg_catalog.pg_namespace', 
                                conn)
        
        schema['db'] = section
        conn.close()
        
        # Add to schema dataframe
        schemas_df = pd.concat([schemas_df, schema], ignore_index=True)
        
    # Filter relevant country
    country_schemas = (schemas_df
                    .loc[schemas_df.nspname.str.contains(country_iso3, 
                                                            case=False)]
                    .reset_index(drop=True)
                    )

    country_schemas['date'] = country_schemas.nspname.str[0:13]
    country_schemas['schema'] = country_schemas.nspname.str[13:]
    country_schemas['is_latest'] = country_schemas.date==country_schemas.groupby('schema').date.max()[0]

    # Return schemas
    if latest:
        return country_schemas.loc[country_schemas.is_latest==latest].reset_index(drop=True)
    else:
        return country_schemas


def lookup_by_coordinates(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, radius:int or float=50) -> pd.DataFrame:
    """Performs spatial queries of a list of coordinates in MNR to get the APTs near the addresses
    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the addresses to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param radius: radius in meters to look around the coordinates to retrieve the nearby APTs,  defaults to 50
    :type radius: int or float, optional
    :return: APTs in MNR near the coordinates
    :rtype: gpd.DataFrame
    """


    # Create query for addresses to reverse lookup
    query_coordinates = """select index_searched_query
                        ,  st_geomfromtext (coordinates, 4326)  coordinates 
                         from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    
    
    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', row.db)
        
        
        # Create query for spatial query in MNR database
        query_buffers = """
        with sample as ({query_coordinates})
        
        , buffers as (
        select  
            sample.index_searched_query
            , sample.coordinates
            , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
        from sample
        )     
        
            
        , apt as (                   
        select 
            '{mnr_version}' as version_checked
        ,	case when n."name" is null then concat(p2.hsn, ', ', p2.street_name, ', ', p2.place_name, ', ', p2.postal_code, ', ', p2.country)
                else concat(p2.hsn, ', ', p2.street_name, ', ', n."name", ', ', p2.place_name, ', ', p2.postal_code, ', ', p2.country)
                end as address
        ,	p2.hsn
        ,	p2.street_name
        ,	p2.place_name
        ,	n.name
        ,	p2.postal_code
        ,	p2.country
        ,	p2.geom
        from
            
        (
        select p1.*, n."name" as place_name
            from
            (
        select apt.feat_id, hsn.hsn, n."name" as street_name, ad.place_name_id, pp.postal_code, pp.country, apt.geom, dependent_locality_id
            from "{schema}".mnr_apt as apt
            join buffers on ST_Intersects(buffers.buffer, apt.geom)
            join "{schema}".mnr_apt2addressset as a2a on apt.feat_id = a2a.apt_id
            join "{schema}".mnr_addressset as ads on a2a.addressset_id = ads.addressset_id
            join "{schema}".mnr_address as ad on ads.addressset_id = ad.addressset_id
            join "{schema}".mnr_hsn as hsn on ad.house_number_id = hsn.hsn_id
            left join "{schema}".mnr_postal_point as pp on ad.postal_code_id = pp.feat_id
            left join "{schema}".mnr_name as n on ad.street_name_id = n.name_id
            --where apt.feat_id in ('8de23f2d-cbcb-4628-baa1-a6b8dc4489df')
            ) as p1
        left join "{schema}".mnr_name as n 
            on p1.place_name_id = n.name_id
            ) as p2
        
        left join "{schema}".mnr_name as n on p2.dependent_locality_id = n.name_id
        )

        select 
            buffers.index_searched_query
        ,   buffers.coordinates
        ,   st_astext(buffers.buffer) buffer
        ,   apt.version_checked
        ,   apt.address
        ,   apt.hsn
        ,   apt.street_name
        ,   apt.place_name
        ,   apt.name
        ,   apt.postal_code
        ,   apt.country
        ,   st_astext(apt.geom) geom
        from buffers 
        join apt on 
            ST_Intersects(buffers.buffer, apt.geom)
        """.format(mnr_version = row.date,
                   query_coordinates = query_coordinates,
                   schema = row.nspname,
                   radius = radius)
        
        
        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_buffers, conn, geom_col='coordinates')
        spatial_query_result['buffer'] = gpd.GeoSeries.from_wkt(spatial_query_result['buffer'])
        spatial_query_result['geom'] = gpd.GeoSeries.from_wkt(spatial_query_result['geom'])


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
    

    return gpd.GeoDataFrame(lookup_df)


def lookup_address_ranges(coordinates:gpd.GeoSeries, schemas:pd.DataFrame, radius:int or float=50) -> pd.DataFrame:
    """Searches for house number ranges in MNR given coordinates

    :param coordinates: geopandas.GeoSeries made out of coordinates (shapely.Point elements) for the addresses to lookup
    :type coordinates: gpd.GeoSeries
    :param schemas: pandas.DataFrame listing the schemas and database to lookup
    :type schemas: pd.DataFrame
    :param radius: radius in meters to look around the coordinates to retrieve the nearby APTs, defaults to 50
    :type radius: int or float, optional
    :return: APTs in MNR near the coordinates
    :rtype: gpd.DataFrame
    """
    
    # Create query for addresses to reverse lookup
    query_coordinates =  """select index_searched_query
    ,  st_geomfromtext (coordinates, 4326)  coordinates 
    from """ + convert_coordinates_to_query(coordinates) + " as t (index_searched_query, coordinates)"
    

    # Create DataFrame to get all 
    lookup_df = pd.DataFrame()
    
    
    # Iterate over schemas and databases to make the spatial query
    for _, row in schemas.iterrows():
        # Connect to database
        _, conn = dbconnection.connect('../sql/database.ini', row.db)
        
        
        # Create query for spatial query in MNR database
        query_hnr = query_hsn_ranges = """
        with sample as ({query_coordinates})

        , buffers as (
        select  
            sample.index_searched_query
            , sample.coordinates
            , ST_Transform(ST_Buffer(ST_Transform(ST_SetSRID(sample.coordinates, 4326), 3857), {radius}), 4326) buffer
        from sample
        ) 

        , hnr as (select
            mnr_netw_route_link.feat_id as netw_id,
            mnr_netw_route_link.name::text as pri_name,
            pp.postal_code,
            mnr_locality.locality,
            mnr_locality.country,
            mnr_netw_geo_link.geom,
            case min(hsn_variance) filter (where mnr_netw2hsn_range.line_side in (1, 2))
                when 2 then 'Even'
                when 3 then 'Odd'
                when 4 then 'Numeric Mixed'
                when 5 then 'Irregular'
                when 6 then 'Alphabetic'
            end as left_variance,
            min(hsn) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 1) as left_first,
            bool_and(interpolated) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 1) as left_first_interpolated,
            array_agg(hsn::text order by seq_num) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 3) as left_intermediates,
            --string_agg(hsn::text, ';' order by seq_num) filter (where line_side in (1, 2) and hsn_type = 3) as left_intermediates,
            min(hsn) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 2) as left_last,
            bool_and(interpolated) filter (where mnr_netw2hsn_range.line_side in (1, 2) and hsn_type = 2) as left_last_interpolated,

            case min(hsn_variance) filter (where mnr_netw2hsn_range.line_side in (1, 3))
                when 2 then 'Even'
                when 3 then 'Odd'
                when 4 then 'Numeric Mixed'
                when 5 then 'Irregular'
                when 6 then 'Alphabetic'
            end as right_variance,
            min(hsn) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 1) as right_first,
            bool_and(interpolated) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 1) as right_first_interpolated,
            array_agg(hsn::text order by seq_num) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 3) as right_intermediates,
            --string_agg(hsn::text, ';' order by seq_num) filter (where line_side in (1, 3) and hsn_type = 3) as right_intermediates,
            min(hsn) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 2) as right_last,
            bool_and(interpolated) filter (where mnr_netw2hsn_range.line_side in (1, 3) and hsn_type = 2) as right_last_interpolated

            from
            "{schema}".mnr_netw_route_link as mnr_netw_route_link

            inner join "{schema}".mnr_netw2hsn_range as mnr_netw2hsn_range on mnr_netw2hsn_range.netw_id = mnr_netw_route_link.feat_id

            join "{schema}".mnr_netw_geo_link mnr_netw_geo_link on mnr_netw_geo_link.feat_id = mnr_netw_route_link.netw_geo_id

            join buffers on ST_Intersects(buffers.buffer, mnr_netw_geo_link.geom)

            inner join "{schema}".mnr_hsn_range as mnr_hsn_range using (hsn_range_id)

            inner join "{schema}".mnr_hsn_range2hsn as mnr_hsn_range2hsn using (hsn_range_id)

            inner join "{schema}".mnr_hsn as mnr_hsn using (hsn_id)

            left join "{schema}".mnr_netw2postal_point as mnr_netw2postal_point 
                on mnr_netw2postal_point.netw_id = mnr_netw2hsn_range.netw_id
                and mnr_netw2postal_point.line_side = mnr_netw2hsn_range.line_side

            inner join "{schema}".mnr_postal_point pp 
                on pp.feat_id = mnr_netw2postal_point.postal_point_id

            left join "{schema}".mnr_netw2locality mnr_netw2locality 
                on mnr_netw2locality.netw_id = mnr_netw2hsn_range.netw_id
                and mnr_netw2locality.ranking = 1
                
            left join "{schema}".mnr_locality mnr_locality
                on mnr_locality.feat_id = mnr_netw2locality.locality_id
                

            group by mnr_netw_route_link.feat_id,
            mnr_netw_route_link,
            mnr_netw_geo_link.geom,
            pp.postal_code,
            mnr_locality.locality,
            mnr_locality.country
            )
            
        select 
                buffers.index_searched_query
            ,   buffers.coordinates
            ,   st_astext(buffers.buffer) buffer
            ,  '{mnr_version}' as version_checked
            ,   hnr.left_first
            ,   hnr.left_intermediates
            ,   hnr.left_last
            ,   hnr.right_first
            ,   hnr.right_intermediates
            ,   hnr.right_last
            ,   hnr.pri_name as street_name
            ,   hnr.locality as place_name
            ,   hnr.postal_code
            ,   hnr.country
            ,   st_astext(hnr.geom) geom
            from buffers 
            join hnr on 
                ST_Intersects(buffers.buffer, hnr.geom)""".format(mnr_version = row.date,
                                                                  query_coordinates = query_coordinates,
                                                                  schema = row.nspname,
                                                                  radius = radius)
        
        
        # Query database
        spatial_query_result = gpd.GeoDataFrame.from_postgis(query_hnr, conn, geom_col='coordinates')
        spatial_query_result['buffer'] = gpd.GeoSeries.from_wkt(spatial_query_result['buffer'])
        spatial_query_result['geom'] = gpd.GeoSeries.from_wkt(spatial_query_result['geom'])


        # Concat responses
        lookup_df = pd.concat([lookup_df, spatial_query_result], ignore_index=True)
        conn.close()
    
    return gpd.GeoDataFrame(lookup_df)

    
if __name__=='__main__':
    # Create test dataframe
    test_addresses = [('11-97 DE ENTREE AMSTERDAM 1101 HE NLD', 52.31177019833552, 4.939634271503648),
    ('Aalsterweg 303, 5644 RL Eindhoven, NL', 51.41176179168882, 5.482757611072691),
    ('Ammunitiehaven 343 2511 XM s Gravenhage NL', 52.07742315143409, 4.3212179573462075),
     ('Baarsweg 148, 3192 VB, Hoogvliet Rotterdam, Ne...', 51.856975720153564, 4.350903401715045),
     ('Baas Gansendonckstraat 3, 1061CZ Amsterdam, NL', 52.37733757641722, 4.840407597295104)
     ]


    test_df = pd.DataFrame(test_addresses, columns=['searched_query', 'lat', 'lon'])
    test_df['coordinates'] = test_df.apply(lambda x: shapely.geometry.Point(x.lon, x.lat), axis=1)
    test_gdf = gpd.GeoDataFrame(test_df, geometry='coordinates')


    # Test functions
    nld_schemas = find_country_schemas('nld', latest=True)
    lookup_df = lookup_by_coordinates(test_gdf.coordinates, nld_schemas, 50)
    address_ranges = lookup_address_ranges(test_gdf.coordinates, nld_schemas, 50)

    print('Lookup of APTs: \n')
    print(lookup_df.iloc[0:5, ])
    
    print('\nLookup of AddressRanges: \n')
    print(address_ranges.iloc[0:5, ])
