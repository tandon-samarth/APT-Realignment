import regex, re

from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.types import StringType, IntegerType
from pyspark.sql.functions import col, lit, concat, udf, trim, greatest, when
from fuzzywuzzy import fuzz
import country_converter
import typing


def make_samples_providers(df_input: SparkDataFrame, providers: typing.List[str] = ['tt', 'he']) -> SparkDataFrame:
    """Creates a DataFrame with the unique combinations of sample addresses and providers 
    
        :param df: DataFrame containing column 'searched_query' which represents the sample points
        :type df: pyspark.sql.DataFrame
        :param providers: list containing the abbreviated forms of the competitors ('tt':'TomTom', 'he':'Here', 'gg': 'Google'). Defaults to ['tt', 'he']
        :type providers: typing.List[str], optional
        :return: DataFrame with two columns: 'searched_query' containing the sample points and 'provider_id' containing the different competitors
        :rtype: pyspark.sql.DataFrame
    """
    df_union = None
    df = df_input.dropDuplicates(['searched_query', 'country', 'lat', 'lon']).select('searched_query', 'country', 'lat', 'lon')
    for provider in providers:
        df_provider = df.withColumn('provider_id', lit(provider))
        if df_union:
            df_union = df_union.unionByName(df_provider)
        else:
            df_union = df_provider
    return df_union


def replace_tokens(x: str, tokens_str: str) -> str:
    """Replace tokens from a given string

    :param x: String input
    :type x: str
    :param tokens_str: String with the tokens to replace
    :type tokens_str: str
    :return: String with the tokens replaced
    :rtype: str
    """
    if x and tokens_str:
        tokens = tokens_str.split(' ')
        for token in tokens:
            x = x.lower().replace(token.lower(), '')
        x = x.strip().replace('  ', ' ')
        return regex.sub('[^0-9\p{L}\s]', ' ', x).replace('  ', ' ').lower()
    else:
        return None


def get_wratio(postcode1: str, postcode2: str, preprocess: bool = False) -> int:
    """Returns a measure of the postcodes similarity between 0 and 100

    :param postcode1: Postcode
    :type postcode1: str
    :param postcode2: Postcode
    :type postcode2: str
    :param preprocess: Boolean to preprocess the strings
    :type preprocess: bool
    :return: Value with the similarity between 0 and 100
    :rtype: int
    """
    if postcode1 and postcode2:
      try:
        if preprocess:
            postcode1 = postcode1.lower().strip()
            postcode2 = postcode2.lower().strip()
        return fuzz.WRatio(str(postcode1), str(postcode2))
      except:
        return 0
    return 0
  

def get_token_set_ratio(house_number1: str, house_number2: str) -> int:
    """Returns a measure of the postcodes similarity between 0 and 100, and it takes out 
    the common tokens before calculating the fuzz.ratio() between the new strings

    :param house_number1: House number
    :type house_number1: str
    :param house_number2: House number
    :type house_number2: str
    :return: Value with the similarity between 0 and 100
    :rtype: int
    """
    if house_number1 and house_number2:
      try: 
        return fuzz.token_set_ratio(str(house_number1), str(house_number2))
      except:
        return 0
    return 0


def calculate_mean(val1: int, val2: int, val3: int = None, val4: int = None) -> float:
    """ Method to calculate the mean of the given parameters.

    :param val1: First value to calculate the mean
    :type val1: int
    :param val2: Second value to calculate the mean
    :type val2: int
    :param val3: Third value to calculate the mean, defaults to None
    :type val3: int, optional
    :param val4: Forth value to calculate the mean, defaults to None
    :type val4: int, optional
    :return: Mean of the values
    :rtype: int
    """
    values = []
    if val1 is not None:
      values.append(val1)
    if val2 is not None:
      values.append(val2)
    if val3 is not None:
      values.append(val3)
    if val4 is not None:
      values.append(val4)
    if len(values) > 0:
      return sum(values) / len(values)
    else:
      return 0


def get_country_alpha_2(iso2:str, iso3:str, country_provider:str, country_sample:str) -> str:
    """Method to get the country ISO2 given a country name

    :param iso2: ISO2 
    :type iso2: str
    :param iso3: ISO3 
    :type iso3: str
    :param country_provider: string representing the provider the country identifies
    :type country_provider: str
    :param country_sample: Country name
    :type country_sample: str

    :return: ISO2 value of the country
    :rtype: str
    """
    try: 
      if iso2:
          country_code = iso2
      elif iso3:
          country_code = country_converter.convert(iso3, to='ISO2')
      elif country_provider:
          country_code = country_converter.convert(country_provider, to='ISO2', not_found=country_sample)
      else: 
          country_code = country_sample
    except:
        country_code = 'nan'
    return country_code

  
def is_it_in_column(string: str, content: str, second_content: str = None) -> bool:
    """Method that indicates if a given string is inside a column

    :param string: string to check
    :type string: str
    :param content: content of the column
    :type content: str
    :param second_content: second content to check, defaults to None
    :type second_content: str, optional
    :return: Boolean that indicates if a given string is inside a column
    :rtype: bool
    """
    try: 
      if string and string != 'nan' and string.lower() in content.lower():
        if second_content:
          if string.lower() not in second_content.lower():
            return False
        return True
    except:
      return False
    return False


def locality_normalitation(locality: str, country: str) -> str:
  """Method to normalize and correct the locality based on a given country

  :param locality: Locality
  :type locality: str
  :param country: Country
  :type country: str
  :return: Locality corrected
  :rtype: str
  """
  if locality:
    if country == "ar":
      if "caba" == locality:
        return 'ciudad autonoma buenos aires'
  return locality


def extract_single_house_number(house_number: str, position: int) -> str:
    """Extract one part of the house number

    :param house_number: Complete house number
    :type house_number: str
    :param position: Position to extract
    :type position: int
    :return: Part of the house number
    :rtype: str
    """
    try:
      groups = re.search('(\d+)[^\d]+(\d+)', house_number).groups()
      return groups[position]
    except:
      return None


def compute_stn_similarity(left_hsn_sim: int, right_hsn_sim: int, left_hsn_component: int, right_hsn_component: int, hsn_wratio: int, hsn_component_wratio: int, country: str) -> int:
  """Computes the street number similarity of an address given a country

  :param left_hsn_sim: Similarity between the left part of the left libpostal house number and the provider one
  :type left_hsn_sim: int
  :param right_hsn_sim: Similarity between the rigth part of the left libpostal house number and the provider one
  :type right_hsn_sim: int
  :param left_hsn_component: Similarity between the left part of the left libpostal house number and the component one
  :type left_hsn_component: int
  :param right_hsn_component: Similarity between the right part of the left libpostal house number and the component one
  :type right_hsn_component: int
  :param hsn_wratio: Similarity between the house number and the component one
  :type hsn_wratio: int
  :param hsn_component_wratio: Similarity between the left libpostal house number and the component one
  :type hsn_component_wratio: int
  :param country: Country ISO2
  :type country: str
  :return: Similarity based on the country
  :rtype: int
  """
  if country == "in":
    return max(left_hsn_sim, left_hsn_component)
  return max(hsn_wratio, hsn_component_wratio)


def calculate_similarity_metrics(input_df: SparkDataFrame) -> SparkDataFrame:
    """Method to calculate the similarity metrics of postcode, road, house number and city

    :param input_df: Input DataFrame with the components
    :type input_df: SparkDataFrame
    :return: Output DataFrame with the similarity metrics
    :rtype: SparkDataFrame
    """
    udf_wratio = udf(get_wratio, IntegerType())
    udf_token_set_ratio = udf(get_token_set_ratio, IntegerType())
    udf_replace_tokens = udf(replace_tokens, StringType())

    # Postcode similarity
    output_df = input_df.withColumn('pc_wratio', udf_wratio("libpostal_postcode", "provider_postcode"))
    output_df = output_df.withColumn('pc_component_wratio', udf_wratio("libpostal_postcode", "provider_pc_component"))
    output_df = output_df.withColumn('pc_similarity', greatest("pc_wratio", "pc_component_wratio"))
    output_df = output_df.withColumn('pc_similarity', when(col("libpostal_postcode")=='', None).otherwise(when(((col("provider_pc_component")=='') | (col("provider_pc_component").isNull())), 50).otherwise(col("pc_similarity"))))

    # Road similarity 
    output_df = output_df.withColumn('road_wratio', udf_wratio("libpostal_road", "provider_road"))
    output_df = output_df.withColumn('road_component_wratio', udf_wratio("libpostal_road", "provider_road_component"))
    output_df = output_df.withColumn('road_similarity', greatest("road_wratio", "road_component_wratio"))

    # House number similarity
    output_df = output_df.withColumn('house_number_wratio', udf_token_set_ratio("libpostal_house_number", "provider_house_number"))
    output_df = output_df.withColumn('house_number_component_wratio', udf_token_set_ratio("libpostal_house_number", "house_number_component"))
    output_df = output_df.withColumn('house_number_similarity', greatest("house_number_wratio", "house_number_component_wratio"))

    # Localities similarity
    output_df = output_df.withColumn('searched_query_tokens', trim(concat(col("libpostal_road"), lit(" "), col("libpostal_house_number"), lit(" "), col("libpostal_postcode"))))
    output_df = output_df.withColumn('provider_tokens', trim(concat(col("provider_road_component"), lit(" "), col("house_number_component"), lit(" "), col("provider_pc_component"))))

    output_df = output_df.withColumn('aux_searched_query', udf_replace_tokens("searched_query", "searched_query_tokens"))
    output_df = output_df.withColumn('aux_provider_formatted_address', udf_replace_tokens("provider_formatted_address", "provider_tokens"))

    output_df = output_df.withColumn('locality_wratio', udf_wratio("aux_searched_query", "aux_provider_formatted_address"))
    output_df = output_df.withColumn('locality_city_state_ratio', udf_wratio(trim(concat(col("libpostal_city"), lit(" "), col("libpostal_state"))), trim(concat(col("provider_city"), lit(" "), col("provider_state")))))
    output_df = output_df.withColumn('locality_similarity', (col("locality_wratio") + col("locality_city_state_ratio"))/2)

    return output_df