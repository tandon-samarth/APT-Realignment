import pandas as pd 
import geopandas as gpd
import psycopg2
from math import sin, cos, sqrt, atan2, radians
import shapely 
import typing 
import country_converter


def convert_coordinates_to_query(x:gpd.GeoSeries) -> str:
    """Takes a coordinates geoseries and converts it into a string to build a query in Postgres
    
    :param x: coordinates
    :type x: geopandas.GeoSeries
    :return: string to build a spatial query (table) 
    :rtype: str
    """
    
    # Create index for each address and convert coordinates to WKT
    values = list(zip(x.index.tolist(), x.to_wkt()))
    values_str = ','.join([str(value) for value in values])
    
    return  "(VALUES " + values_str + ")"


def get_country_schema_osm(iso_code:str, 
                           conn:psycopg2.extensions.connection) -> str:
    """Finds schema that contains the buildings for further querying
    
    :param iso_code: ISO3 code of a country ('USA', not 'US')
    :type iso_code: str
    :param conn: connection to OSM database
    :type conn: 
    :return: string for the country iso code
    :rtype: str
    """
    query_schemas = """
    SELECT table_schema, table_name
                        FROM information_schema.tables
                        WHERE table_schema != 'pg_catalog'
                        AND table_schema != 'information_schema'
                        AND table_type='BASE TABLE'
                        ORDER BY table_schema, table_name
    """
    schemas_table = pd.read_sql(query_schemas, conn)
    country_schema = schemas_table.loc[schemas_table.table_schema.str.contains(iso_code, case=False)].table_schema.unique()[0]

    return country_schema


  
def query_building_in_point(x:gpd.GeoSeries, 
                            schema:str, 
                            conn:psycopg2.extensions.connection) -> gpd.GeoDataFrame:

    """Creates a query to find if point is within some building

    :param x: coordinates to search
    :type x: geopandas.geoseries.GeoSeries
    :param schema: schema of OSM Clean database to query
    :type schema: str
    :param conn: connection object of OSM database
    :type conn: psycopg2.extensions.connection
    :return: string to build a spatial query (table) 
    :rtype: str
    """
        
        
    # Create query for point in building
    query_coordinates = """select index_searched_query,  st_geomfromtext (coordinates, 4326)  coordinates 
    from """ + convert_coordinates_to_query(x) + " as t (index_searched_query, coordinates)"
    
    sample_query = """
    with sample as ({query_coordinates}) 
        select 
        point.index_searched_query
    ,	point.coordinates
    ,	poly.osm_id 
    , poly.building
    ,	st_astext(poly.way) building_shape
    ,	poly.tags
    from sample as point
    left join {schema}.planet_osm_polygon poly
        --on 1=1
        on ST_Within(coordinates, poly.way)
    where poly.building is not null
    """.format(query_coordinates=query_coordinates, schema=schema)
    
    
    # Connect to DB and get result
    point_in_building = gpd.GeoDataFrame.from_postgis(sample_query, conn, geom_col='coordinates')
    point_in_building['building_shape'] = gpd.GeoSeries.from_wkt(point_in_building['building_shape'])
    
    
    return point_in_building


def truncate(n:float, decimals:int=0) -> int:
    """Simple function which truncates an incoming float value (n) and returns its integer value
    based on its multiplier value, later divided by the same multiplier value.

    :param n: Input numerical value, float type.
    :type n: flaot
    :param decimals: Input integer which defines the number of decimal point to return, defaults to 0
    :type decimals: int, optional
    :return:Output integer value after the truncate process of the input value (n).
    :rtype: int
    """    

    multiplier = 10 ** decimals
    return int(n * multiplier) / multiplier


def haversine_distance(lt1:float,
                       ln1:float,
                       lt2:float,
                       ln2:float) -> float:
    """Function which calculates the distance in meters between two XY coodinates. The function requires
    the latitude and longitude for each point. At the end of the function, we truncate the output distance
    value with a maximun of 4 decimal points.

    :param lt1: Latitude value of first coordinate point.
    :type lt1: float
    :param ln1: Longitude value of first coordinate point.
    :type ln1: float
    :param lt2: Latitude value of second coordinate point.
    :type lt2: float
    :param ln2: Longitude value of second coordinate point.
    :type ln2: float
    :return: Distance between point in meters.
    :rtype: float
    """
    
    R = 6373.0  # approximate radius of earth in km
    lat1 = radians(lt1)  
    lon1 = radians(ln1)
    lat2 = radians(lt2)  
    lon2 = radians(ln2)
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = truncate(R * c, 4) * 1000
    return distance


def polygon_distance(poly:gpd.GeoSeries, points:gpd.GeoSeries) -> typing.List:
    """Compute distance to nearest point in polygon in meters

    :param poly: geopandas.GeoSeries of polygon features
    :type poly: gpd.GeoSeries
    :param points: geopandas.Geoseries of Points
    :type points: gpd.GeoSeries
    :return: Distance between point in and polygons in meters
    :rtype: typing.List
    """
    
    
    # For each polygon and point pair, compute the nearest point in polygon
    nearest_points = [shapely.ops.nearest_points(poly,
                                                 point)[0]
                      if point.wkt != 'POINT (nan nan)'
                      else shapely.geometry.Point(90, 90) 
                      for poly, point in zip(poly, points)]
    
    
    # Compute Haversine distance to nearest point
    distance = [haversine_distance(nearest_point.y,
                                   nearest_point.x,
                                   point.y,
                                   point.x)
                if point.wkt != 'POINT (nan nan)'
                else 1e7 
                for nearest_point, point in zip(nearest_points, points)]
    
    
    return distance


def convert_to_coordinates(lat:float, lon:float) -> shapely.geometry.point.Point:
    """UDF that converts a pair of latitude and longitude to a shapely geometry Point object 

    :param lat: latitude
    :type lat: float
    :param lon: longitude
    :type lon: float
    :return: the Well Known Text (WKT) of the shapely geometry object
    :rtype: shapely.geometry.point.Point
    """

    try:
      return shapely.geometry.Point(float(lon), float(lat)).wkt  
    except Exception:
      return shapely.geometry.Point(999, 999).wkt


def point_in_polygon(point:str, polygon:str) -> int:
    """UDF that measures whether a point is within the area of a polygon

    :param point: string that represents the WKT of a point
    :type point: str
    :param polygon: string that represents the WKT of a polygon
    :type polygon: str
    :return: 1 if the point is within the polygon and 0 otherwise.
    :rtype: int
    """

    # Convert point and polygon to shapely format
    point_obj = shapely.wkt.loads(point)
    polygon_obj = shapely.wkt.loads(polygon)


    # Return 1 if polygon contains the point, and 0 otherwise
    if point_obj.within(polygon_obj):
        return 1
    else:
        return 0
    

def buildings_country(df:pd.DataFrame) -> pd.DataFrame:
    """Function to be applied in a PySpark.DataFrame with the applyInPandas method. 
    Function computes for a given country the buildings that represent the sample addresses

    :param df: DataFrame containing at least the following columns: 'searched_query', 'country', 'coordinates'
    :type df: pd.DataFrame
    :return: DataFrame containing the addresses that had a building in OSMBuildings
    :rtype: pd.DataFrame
    """

    df_copy = df.copy()
  
  
    # Establish connection
    conn = psycopg2.connect(dbname='ggg', user='ggg_ro', password='ggg_ro', host='tt3g-prod.openmap.maps.az.tt3.com')


    # Get schema of OSM Database. 
    country_iso3 = country_converter.convert(df_copy.country.unique()[0], to='ISO3')
    schema = get_country_schema_osm(iso_code=country_iso3, conn=conn)


    # Convert relevant column no geometry
    df_copy = df_copy.drop_duplicates(['searched_query']).reset_index(drop=True)
    df_copy['coordinates'] = gpd.GeoSeries.from_wkt(df_copy.coordinates)
    geo_df = gpd.GeoDataFrame(df_copy, geometry='coordinates')

    
    # Make query to database
    point_in_building_df = query_building_in_point(x=geo_df.coordinates, 
                                                   schema=schema, 
                                                   conn=conn)
    point_in_building_df['country'] = df.country.unique()[0]

    conn.close() 
    
    
    # Unary union of building if there are more than one response from OSM Buildings. It may affect conformance to reality.
    point_in_building_df['osm_id'] = point_in_building_df.osm_id.astype(str)
    point_in_building_df = point_in_building_df.groupby(['index_searched_query', 'country']).agg({'building_shape': lambda x: shapely.ops.unary_union(x),
                                                                                                  'osm_id': lambda x: '+'.join(x)}).reset_index()

    
    # Merge to original DataFrame to get searched query and responses
    point_in_building_df = point_in_building_df.merge(geo_df[['searched_query']].reset_index(drop=True),
                                                      how='left',
                                                      left_on='index_searched_query', right_index=True)

   
    
    return pd.DataFrame(point_in_building_df).astype(str)


def distance_to_polygon(polygon:str, point:str) -> float:
    """UDF that measures the distance from a point to a polygon

    :param polygon: string representing the WKT of the polygon
    :type polygon: str
    :param point: string representing the WKT of the point
    :type point: str
    :return: distance to the nearest point of the polygon. If the point is in the polygon, the distance will be 0
    :rtype: float
    """

    # Convert point and polygon to shapely format
    point_obj = gpd.GeoSeries(shapely.wkt.loads(point))
    polygon_obj = gpd.GeoSeries(shapely.wkt.loads(polygon))
    

    return polygon_distance(polygon_obj, point_obj)[0]
  