import pandas as pd
import numpy as np 
import typing

confidence_levels=[0.9]


def bootstrap_resample(df:pd.DataFrame, 
                       agg_fun:callable, 
                       times:int=1000,
                       seed:int=0)->pd.DataFrame:
    """Auxiliary function that computes a bootstrap routine on a DataFrame

    :param df:  pandas DataFrame containing variables to be resampled and aggregated
    :type df: pd.DataFrame
    :param agg_fun: function to apply on pandas DataFrame
    :type agg_fun: callable
    :param times: number of resamples, defaults to 1000
    :type times: int, optional
    :param seed: initial seed to ensure reproducibility, defaults to 0
    :type seed: int, optional
    :return: pandas.DataFrame with the result  of the aggregation for each iteration and the relevant functions
    :rtype: pd.DataFrame
    """


    reboot = pd.DataFrame()

    for t in range(times):
        df_boot = df.sample(frac = 1, replace=True, random_state = t+seed)
        reboot = pd.concat([reboot, agg_fun(df_boot,t)])
    print(reboot)
    
    
    return pd.DataFrame(reboot)

  
def percentile_bootstrap(df:pd.DataFrame,
                         agg_fun:callable,
                         confs:typing.List[float]=[0.9, 0.8],
                         thresholds:typing.List[float]=[],
                         times:int=1000,
                         seed:int=0,
                         keys:typing.List[str]=[], 
                         keynames:typing.List[str]=[], 
                         sortBy:typing.List[str]=[]) -> pd.DataFrame:
    """Generic Percentile Bootstrap

    :param df: DataFrame with the observed random vectors. Each row represents an observation an each column is a random variable.
    :type df: pandas.DataFrame
    :param agg_fun: Aggregation function. This function should receive as input a pandas.DataFrame (resamples) and returns pandas.DataFrame with as many columns as statistics computed.
    :type agg_fun: function
    :param confs: Confidence level of the returned interval, defaults to 0.9
    :type confs: list[float], optional
    :param thresholds: Confidence level of the returned interval, defaults to empty list. List must be empty or same zize as number of columns returned by aggfun
    :type thresholds: list[float], optional
    :param times: Bootstrap resamples, defaults to 1000
    :type times: int, optional
    :param seed: Random seed, defaults to 0
    :type seed: int, optional
    :param keys: tuple with the values of the grouping columns that define current group
    :type keys: tuple
    :param keynames: list of strings with the names of the grouping columns
    :type keynames: list[str]
    :return: pandas DataFrame with the results of the bootstrapping process for this group
    :rtype: pandas.DataFrame
    """


    # Sort values to ensure repeatibility for a given sample and better comparison between competitors
    if(len(sortBy)>0):
      sorted_df = df.sort_values(sortBy, ascending= np.zeros(len(sortBy)))
    else:
      sorted_df = df
    reboot = bootstrap_resample(sorted_df, agg_fun, times, seed)
    
    listDicts = [] 
    for i in range(len(reboot.columns)):
      intervals = {}
      for k in range(len(keys)):
        intervals.update({keynames[k]: keys[k]})
      intervals.update({'variable': reboot.columns[i], 'resamples': times, 'size': len(df)})
      myArray = np.array(reboot[[reboot.columns[i]]])
      for conf in confs:
        interval = np.quantile(myArray,
                               [(1-conf)/2, (1-conf)/2+conf])
        intervals.update({'upper'+str(int(conf*100)): interval[1], 'lower'+str(int(conf*100)): interval[0]})
      if (len(thresholds)>0) and (len(thresholds[i])>0):
        for t in thresholds[i]:
          if t>0:
            prob = np.sum(myArray>t) / len(myArray)
            intervals.update({'prob_above_'+str(int(t*100)): prob})
          else:
            prob = np.sum(myArray<-t) / len(myArray)
            intervals.update({'prob_below_'+str(int(-t*100)): prob})
      intervals.update({'resamples_array': [i[0] for i in myArray]})
      listDicts = listDicts + [intervals]
    #dfDict.update(intervals)
    print(listDicts)
    
    resultPDF = pd.DataFrame(listDicts)
    return resultPDF
  
  
def aggregate_match(df:pd.DataFrame,
                    resampleIdx:int=1) -> pd.DataFrame:
    """Auxiliary function that generates the bootstrap results for the ASF and provider distance metrics

    :param df: pandas DataFrame containing at least 'match' and 'provider_distance' columns
    :type df: pd.DataFrame
    :param resampleIdx: indices of bootstrap samples, defaults to 1
    :type resampleIdx: int, optional
    :return: pandas.DataFrame with the aggregation of the addressing variables
    :rtype: pd.DataFrame
    """

    
    auxdf = df
    auxdf['resample']=resampleIdx
    
    result_bs = (auxdf
                 .groupby('resample')
                 .agg(match=('match', 'mean'))
                 )

    result_distance = (auxdf.loc[auxdf.match==1]
                .groupby('resample')
                .agg(provider_distance=('provider_distance', 'mean'),
                    provider_distance_p90=('provider_distance', lambda x: np.quantile(x, 0.9)))
                )

    result_bs = result_bs.merge(result_distance, left_index= True, right_index = True)
    
    return result_bs


def aggregate_rooftop(df:pd.DataFrame,
                      resampleIdx:int=1) -> pd.DataFrame:
    """Auxiliary function that generates the bootstrap results for the ASF and provider distance metrics

    :param df: pandas DataFrame containing at least 'match' and 'provider_distance' columns
    :type df: pd.DataFrame
    :param resampleIdx: indices of bootstrap samples, defaults to 1
    :type resampleIdx: int, optional
    :return: pandas.DataFrame with the aggregation of the addressing variables
    :rtype: pd.DataFrame
    """

    
    auxdf = df
    auxdf['resample']=resampleIdx
    
    result_bs = (auxdf
                 .groupby('resample')
                 .agg(match=('rooftop', 'mean'))
                 )

    result_distance = (auxdf.loc[auxdf.rooftop==1]
                .groupby('resample')
                .agg(provider_distance=('provider_distance_building', 'mean'),
                     provider_distance_p90=('provider_distance_building', lambda x: np.quantile(x, 0.9)))
                )

    result_bs = result_bs.merge(result_distance, left_index= True, right_index = True)
    
    return result_bs


def applyInPandasAggMatching(keys:typing.Tuple[str],
                             pdf:pd.DataFrame) -> pd.DataFrame:
  """Applying a bootstrapping function to each group in a grouped spark DataFrame

    :param keys: tuple with the values of the grouping columns that define current group
    :type keys: tuple
    :param pdf: data whithin the group in pandas format
    :type pdf: pandas.DataFrame
    :return: result of the bootstrapping process in pandas format
    :rtype: pandas.DataFrame
    """
  
  return percentile_bootstrap(pdf, 
                              aggregate_match, 
                              confs=confidence_levels, 
                              times=1000, 
                              seed=0, 
                              keys=keys, 
                              keynames=["matching_run_id", "provider_id", "country"],
                              sortBy=["searched_query"])


def applyInPandasRooftop(keys:typing.Tuple[str],
                             pdf:pd.DataFrame) -> pd.DataFrame:
  """Applying a bootstrapping function to each group in a grouped spark DataFrame

    :param keys: tuple with the values of the grouping columns that define current group
    :type keys: tuple
    :param pdf: data whithin the group in pandas format
    :type pdf: pandas.DataFrame
    :return: result of the bootstrapping process in pandas format
    :rtype: pandas.DataFrame
    """
  
  return percentile_bootstrap(pdf, 
                              aggregate_rooftop, 
                              confs=confidence_levels, 
                              times=1000, 
                              seed=0, 
                              keys=keys, 
                              keynames=["matching_run_id", "provider_id", "country"],
                              sortBy=["searched_query"])
