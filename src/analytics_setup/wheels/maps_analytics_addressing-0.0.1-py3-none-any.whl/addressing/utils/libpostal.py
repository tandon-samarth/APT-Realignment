from math import sin, cos, sqrt, atan2, radians
from urllib.parse import quote, unquote
from datetime import datetime
import requests
import json
import ast

from pyspark.sql.types import StringType, MapType
from pyspark.sql.functions import col, lit, regexp_replace, concat, udf, trim, when
from pyspark.sql import DataFrame as SparkDataFrame
import pyspark.sql.utils
from retry import retry
import typing
import pycountry


def construct_query(address: str) -> str:
    """Construct the query given an address ready for calling libpostal service

    :param address: Address
    :type address: str
    :return: string with the query for libpostal service
    :rtype: str
    """
    query = ""
    try:
        query = json.dumps({"query": address.replace("'", '"').replace('"', '\"').replace('’', '\’').replace('+',' ').replace('\ufffd', '')}, ensure_ascii=False)
    except pyspark.sql.utils.AnalysisException as err:
        print(f"Error with the given column {address}: {err}")
    return query


def deduplicate_dictionary(value: typing.Dict) -> typing.Dict:
    """Method to deduplicate the keys from a given dictionary

    :param value: Python dictionary
    :type value: typing.Dict
    :return: Dictionary deduplicated
    :rtype: typing.Dict
    """
    try:
        result_parsed = ast.parse(value)
        exp_dict = result_parsed.body[0].value
        keys = list(map(ast.literal_eval, exp_dict.keys))
        values = list(map(ast.literal_eval, exp_dict.values))
        dict_result = {}
        for k, v in zip(keys, values):
            dict_result.setdefault(k, []).append(v)
        dict_result = {k:' '.join(v) if len(v) > 1 else v[0] for (k,v) in dict_result.items()}
        dict_result = {key : value.replace("'","") for key, value in dict_result.items()}
        return dict_result
    except Exception as err:
        print(f"Error while deduplicating: {value}")
        return {}


@retry((requests.exceptions.ConnectionError), tries=5, delay=1, backoff=2)
def call_libpostal_service(query: str) -> typing.Dict:
    """Calls libpostal service sending a given query.
    
    :param query: string of the form "{'query': <searched_query>}"
    :type query: str
    :return: string that can be converted into a dictionary, with each component of the address parsed
    :rtype: str
    """
    response = None
    try:
        response = requests.post('http://10.133.4.11:8080/parser', query, timeout=20)
    except requests.exceptions.ConnectionError as err:
        print(f"Error while trying apply libpostal to {query}: {err}")
    return response


def get_libpostal_response_from_query(query: str) -> str:
    """Sends the given query to the internal TT LibPostal service and returns the response.
    
    :param query: string of the form "{'query': <searched_query>}"
    :type query: str
    :return: string that can be converted into a dictionary, with each component of the address parsed
    :rtype: str
    """
    response = call_libpostal_service(query.encode('utf-8'))
    out_dict_in_string = ""
    if response:
        result = response.text
        try:
            encoding = response.apparent_encoding
            result = result.encode(encoding).decode('utf-8')
        except:
            result = result.encode('ascii', 'ignore').decode('utf-8')
        # Deduplicate keys
        out_dict_in_string = deduplicate_dictionary(result)

    return out_dict_in_string


def get_libpostal_responses(df: SparkDataFrame, address_column: str = "corrected_address", column_string: str = "libpostal") -> SparkDataFrame:
    """
    function which encapsulates all the processes to create a Query libpostal format, then
    call the libpostal url request, retrieve the response and convert to new columns.

    :param df: Input pyspark dataframe with the data to apply libpostal
    :type df: pyspark.sql.DataFrame
    :param address_column: Name of the column to construct the libpostal queries
    :type address_column: str
    :param column_string: Name of string that will be inserted before the libpostal column names
    :type column_string: str
    :return: Dataframe with the libpostal data
    :rtype: pyspark.sql.DataFrame
    """
    # Create udf functions for applying libpostal
    udf_extract_query = udf(construct_query, StringType())
    udf_query_response = udf(get_libpostal_response_from_query, MapType(StringType(),StringType()))

    # Apply functions to the columns
    try:
        pre_out_df = df.withColumn(column_string + "_query", udf_extract_query(address_column)).withColumn(column_string + "_response", udf_query_response(column_string + "_query"))
        keys = ["house", "category", "near", "house_number", "road", "unit", "level", "staircase", "entrance", "po_box", "postcode", "suburb",
               "city_district", "city", "island", "state_district", "state", "country_region", "country", "world_region"]
        exprs = [col(column_string + "_response").getItem(k).alias(column_string + "_" + k) for k in keys]
        out_df = pre_out_df.select("*", *exprs)
        return out_df
    except pyspark.sql.utils.AnalysisException as err:
        print(f"Error with the given column {address_column}: {err}")
        return None


def get_libpostal_components_dfs(in_df: SparkDataFrame) -> typing.Tuple[SparkDataFrame, SparkDataFrame, SparkDataFrame]:
    """
    Function which takes as input pyspark dataframe with the libpostal response columns, and
    creates new dataframes based on the values inside each of these columns representing the 
    libpostal components.

    :param df: Input pyspark dataframe with the data
    :type df: pyspark.sql.DataFrame
    :return: Dataframes based on the values inside each of these columns with the 
    libpostal components
    :rtype: typing.Tuple[SparkDataFrame, SparkDataFrame, SparkDataFrame]
    """
    # Creates column "libpostal_locality" with concatenation of city, city district, state and country values
    if 'libpostal_city' not in in_df.columns:
        in_df = in_df.withColumn('libpostal_city', lit(''))
    if 'libpostal_state_district' not in in_df.columns:
        in_df = in_df.withColumn('libpostal_state_district', lit(''))
    if 'libpostal_state' not in in_df.columns:
        in_df = in_df.withColumn('libpostal_state', lit(''))
    if 'libpostal_country' not in in_df.columns:
        in_df = in_df.withColumn('libpostal_country', lit(''))
        
    in_df = in_df.na.fill('')
    in_df = in_df.withColumn("libpostal_locality", trim(concat(col("libpostal_city"), lit(" "), col("libpostal_state_district"), lit(" "), col("libpostal_state"), lit(" "), col("libpostal_country"))))
    in_df = in_df.withColumn("libpostal_locality", regexp_replace("libpostal_locality", r"  ", " "))
    out_df_locality = in_df

    # Creates out_df_locality DataFrame where "corrected_address" is equals to "libpostal_locality"
    out_df_locality = in_df.filter(col("libpostal_locality") != "")
    out_df_locality = out_df_locality.withColumn("corrected_address", col("libpostal_locality"))


    # Creates out_df_pc DataFrame where "corrected_address" is equals to "libpostal_locality" with "libpostal_postcode"
    out_df_locality_pc = out_df_locality.filter(col("libpostal_postcode") != "").withColumn("corrected_address", concat(col("libpostal_locality"),lit(" "),col("libpostal_postcode")))


    # Creates out_df_pc DataFrame where "corrected_address" is equals to "libpostal_road" and "libpostal_locality" with "libpostal_postcode"
    out_df_locality_pc_stn = out_df_locality.filter((col("libpostal_postcode") != "") & (col("libpostal_road") != ""))
    out_df_locality_pc_stn = out_df_locality_pc_stn.withColumn("corrected_address", concat(col("libpostal_road"),lit(" "),col("libpostal_locality"),lit(" "),col("libpostal_postcode")))
        
    
    return out_df_locality, out_df_locality_pc, out_df_locality_pc_stn


def get_country_alpha_2(iso2: str, country: str) -> str:
    """Creates the ISO2 format of a given country

    :param iso2: country in ISO2
    :type iso2: str
    :param country: Name of the country
    :type country: str
    :return: Country in ISO2
    :rtype: str
    """
    try: 
      if (not iso2) or (iso2 and (len(iso2) != 2)):
        country_code = pycountry.countries.search_fuzzy(str(country))[0].alpha_2
      else:
        return iso2.lower().strip()
    except:
      country_code = 'nan'
    return country_code.lower().strip()


def components_to_columns(input_df: SparkDataFrame) -> SparkDataFrame:
    """Convert the map (MapType) column with the components into multiple columns (one column for each map key)

    :param input_df: Input DataFrame with the libpostal component
    :type input_df: SparkDataFrame
    :return: Output DataFrame with the libpostal component
    :rtype: SparkDataFrame
    """
    input_df = input_df.withColumn('house_number_component', input_df.provider_address_components['street_number'])
    input_df = input_df.withColumn('country_code_component', input_df.provider_address_components['country_code_ISO2'])
    input_df = input_df.withColumn('country_component', input_df.provider_address_components['country'])
    input_df = input_df.withColumn('provider_road_component', input_df.provider_address_components['street_name'])
    input_df = input_df.withColumn('provider_pc_component', input_df.provider_address_components['postcode'])
    udf_get_country_alpha_2 = udf(get_country_alpha_2, StringType())
    input_df = input_df.withColumn("country_code_component", udf_get_country_alpha_2('country_code_component', 'country_component'))
    input_df = input_df.withColumn('country_matches', when((col("country_code_component") == col("country")), True).otherwise(False))
    return input_df