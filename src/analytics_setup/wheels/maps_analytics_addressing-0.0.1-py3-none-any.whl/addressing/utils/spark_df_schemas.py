from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType, MapType
from pyspark.sql import SparkSession
from pyspark.sql import DataFrame as SparkDataFrame
import typing

    
def create_df_from_list(in_list: typing.List, schema_type: str) -> SparkDataFrame:
    """Creates a Pyspark DataFrame with the results of each API call

    :param in_list: List with the results of each API call
    :type in_list: typing.List[str]
    :param schema_type: Type of the schema: arp_reference, arp_results
    :type schema_type: str
    :return: Pyspark DataFrame with the API call results
    :rtype: SparkDataFrame
    """
    if schema_type == "arp_reference":
        fields = [StructField("address", StringType(),True),
                StructField("corrected_address", StringType(),True),
                StructField("lat", StringType(),True),
                StructField("lon", StringType(),True),
                StructField("country", StringType(),True),
                StructField("rooftop_id", MapType(StringType(),StringType()),True),
                StructField("validation", StringType(),True),
                StructField("gtd_validated", StringType(),True),
                StructField("granular_components", MapType(StringType(),StringType()),True),
                StructField("sample_source", StringType(),True),
                StructField("sample_status", StringType(),True),
                StructField("sample_id", StringType(),True),
                StructField("api1_run_id", StringType(),True),
                StructField("logs_components", MapType(StringType(),StringType()),True),
                StructField("business_components", MapType(StringType(),StringType()),True),
                StructField("reversegeo_components", MapType(StringType(),StringType()),True)
                ]

    elif schema_type == "arp_results":
        fields = [StructField("country", StringType(),True),
                StructField("upload_date", StringType(),True),
                StructField("return_rank", StringType(),True),
                StructField("provider_id", StringType(),True),
                StructField("provider_address_components", MapType(StringType(),StringType()),True),
                StructField("provider_distance", StringType(),True),
                StructField("provider_api_id", StringType(),True),
                StructField("provider_lat", StringType(),True),
                StructField("provider_lon", StringType(),True),
                StructField("provider_type", StringType(),True),
                StructField("provider_formatted_address", StringType(),True),
                StructField("searched_query", StringType(),True),
                StructField("searched_query_type", StringType(),True),
                StructField("lat", StringType(),True),
                StructField("lon", StringType(),True),
                StructField("osm_components", MapType(StringType(),StringType()),True),
                StructField("sample_id", StringType(),True),
                StructField("api2_run_id", StringType(),True)
                ]
    
    elif schema_type == "arp_reporting":
        fields = [StructField("country", StringType(),True),
                StructField("return_rank", StringType(),True),
                StructField("provider_id", StringType(),True),
                StructField("provider_address_components", MapType(StringType(),StringType()),True),
                StructField("provider_distance", StringType(),True),
                StructField("provider_lat", StringType(),True),
                StructField("provider_lon", StringType(),True),
                StructField("provider_type", StringType(),True),
                StructField("provider_formatted_address", StringType(),True),
                StructField("searched_query", StringType(),True),
                StructField("searched_query_type", StringType(),True),
                StructField("lat", StringType(),True),
                StructField("lon", StringType(),True),
                StructField("match", IntegerType(),True),
                StructField("rooftop", IntegerType(),True),
                StructField("provider_distance_building", FloatType(),True),
                StructField("matching_run_id", StringType(),True),
                StructField("sample_id", StringType(),True)
                ]

    else:
        return None

    schema = StructType(fields)
    spark = SparkSession.builder.getOrCreate()
    try:
        output_df = spark.createDataFrame(in_list, schema)
        return output_df
    except TypeError as err:
        print(f"Error converting list to spark dataframe: {err}")
        return None