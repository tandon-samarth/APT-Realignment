from datetime import datetime
from pyspark.sql.functions import col, split, sha2, concat_ws
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.types import IntegerType


def get_today_date() -> str:
    """Function which uses datetime.now() function to collect today´s datetime value

    :return: Today´s date
    :rtype: str
    """
    date_value = datetime.now().strftime('%Y%m%d')
    return date_value


def create_sample_id_hash(input_df: SparkDataFrame) -> SparkDataFrame:
    """Function which creates unique sample_id value, based on concatenated spark dataframe columns and
    using the pysaprk sha2 class to generate a hash value.

    :param input_df: Input pyspark dataframe.
    :type input_df: SparkDataFrame
    :return: Output pyspark dataframe with the "sample_id" column with unique sha2 hash value per row.
    :rtype: SparkDataFrame
    """
    out_df = input_df.withColumn("sample_id", sha2(concat_ws("||",*(col(c).cast("string") for c in input_df.columns)), 256))
    return out_df


def create_api_run_id(response: int) -> str:
    """Function which create unique identifier run IDw based on date and response integer input

    :param response: Integer input, with response value from the find_api1_run_id() function
    :type response: int
    :return: String output with the structure (DATETIME-XXXX) of internal identifier value (i.e. 20210523-0001)
    :rtype: str
    """
    api_run_id_value = get_today_date() + "-" + format(response + 1, "04")
    print(f"API run Id created: {api_run_id_value}")
    return api_run_id_value


def find_api_run_id(input_df: SparkDataFrame, api_run: int = 1) -> int:
    """
    Function which extracts the api_run_id value if found. If api_run_id is found within the same
    day of the execution, then it will split from the datetime, and extract only the numerical part.
    The structure format of the identifier looks like DATETIME-XXXX (i.e. 20210523-0001).
    
    :param df: Input pyspark dataframe with the data
    :type df: pyspark.sql.DataFrame
    :param api_run: The version of the API call, defaults to 1
    :type api_run: int, optional
    :return: Integer output with the integer found in the identifier, otherwise return 0.
    :rtype: int
    """
    try:
        api_run_field = "api" + str(api_run) + "_run_id" 
        input_df_null_filter =  input_df.where(col(api_run_field).isNotNull())
        if len(input_df_null_filter.head(1)) > 0:
            split_col = split(input_df[api_run_field], '-')
            splitted_df = input_df_null_filter.withColumn('date', split_col.getItem(0)).withColumn('id', split_col.getItem(1))
            checked_splitted_df = splitted_df.where(col("date").isin({get_today_date()}))
            if len(checked_splitted_df.head(1)) > 0:
                checked_splitted_df = checked_splitted_df.withColumn("id", checked_splitted_df["id"].cast(IntegerType()))
                response = checked_splitted_df.agg({"id": "max"}).collect()[0][0]
                return response
    except Exception as err:
        # column api_run_id doesn´t exist
        print(f"Error while extractiong the API ID: {err}")
    return 0


def find_matching_run_id(input_df: SparkDataFrame) -> int:
    """
    Function which extracts the matching_run_id value if found. If matching_run_id is found within the same
    day of the execution, then it will split from the datetime, and extract only the numerical part.
    The structure format of the identifier looks like DATETIME-XXXX (i.e. 20210523-0001).
    
    :param df: Input pyspark dataframe with the data
    :type df: pyspark.sql.DataFrame
    :return: Integer output with the integer found in the identifier, otherwise return 0.
    :rtype: int
    """
    try:
        matching_field = "matching_run_id" 
        input_df_null_filter =  input_df.where(col(matching_field).isNotNull())
        if len(input_df_null_filter.head(1)) > 0:
            split_col = split(input_df[matching_field], '-')
            splitted_df = input_df_null_filter.withColumn('date', split_col.getItem(0)).withColumn('id', split_col.getItem(1))
            checked_splitted_df = splitted_df.where(col("date").isin({get_today_date()}))
            if len(checked_splitted_df.head(1)) > 0:
                checked_splitted_df = checked_splitted_df.withColumn("id", checked_splitted_df["id"].cast(IntegerType()))
                response = checked_splitted_df.agg({"id": "max"}).collect()[0][0]
                return response
    except Exception as err:
        # column api_run_id doesn´t exist
        print(f"Error while extractiong the API ID: {err}")
    return 0