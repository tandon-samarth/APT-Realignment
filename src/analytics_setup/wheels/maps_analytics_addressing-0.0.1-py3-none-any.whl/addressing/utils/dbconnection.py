import psycopg2
import pandas as pd
from configparser import ConfigParser
import typing
import pkgutil


def config(filename:str='database.ini', section:str='postgresql') -> dict:
    """Reads DDBB configuration file and load it
    :param filename: Configuration file
    :type filename: str
    :param section: Get different sections of the configuration file
    :type section: str 
    :return: Configuration parameters from the DDBB
    :rtype: dict
    """
    # create a parser
    parser = ConfigParser()

    # within package/mymodule1.py, for example
    configfile = pkgutil.get_data(__name__, filename).decode()

    # read config file
    parser.read_string(configfile)

    # Get section, default to postgresql
    db = {}
    if parser.has_section(section):
        params = parser.items(section)
        for param in params:
            db[param[0]] = param[1]
    else:
        raise Exception('Section {0} not found in the {1} file'.format(section, filename))


    return db


def connect(filepath:str,
            section:str) -> typing.Tuple[psycopg2.extensions.cursor, psycopg2.extensions.connection]:
    """Connects to a postgres DatabASE
    :param filepath: path to file that contains database login info
    :type filepath: str
    :param section: section in path with credentials
    :type section: str
    :return: tuple containing cursor and connection to database
    :rtype: typing.Tuple
    """

    try:
        # read connection parameters
        params = config(filepath, section)


        # connect to the PostgreSQL server
        conn = psycopg2.connect(**params)


        # create a cursor
        cur = conn.cursor()

        return (cur, conn)

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)