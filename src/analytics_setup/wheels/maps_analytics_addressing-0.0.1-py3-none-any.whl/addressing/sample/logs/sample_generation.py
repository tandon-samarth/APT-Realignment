import pandas as pd
import numpy as np
from maps_analytics_utils.connections import adx, connections_utils
from country_list import countries_for_language, available_languages
import typing
import pycountry
from rapidfuzz import fuzz, process
import io
import pkgutil


def generate_countries_spellings(country_codes: typing.List[str] or str = None,
                                 languages: typing.List[str] = None) -> pd.DataFrame:
    """Generates a DataFrame with spellings in different languages for a country

    :param country_codes: string or list of strings of ISO-2 codes of a country ('ES', not 'ESP'), defaults to None
    :type country_codes: str or list, optional
    :param languages: list of languages to get the spellings from, defaults to None
    :type languages: list, optional
    :return: DataFrame with two columns: country code and spellings
    :rtype: pd.DataFrame
    """
    
    # Get all country keys
    if country_codes is None:
        country_codes=list(dict(countries_for_language('en')).keys())
    
    
    # If country code is not a list, convert to list with one element
    if type(country_codes) != list:
        country_codes = [country_codes]
    
    
    # Define languages to query
    if languages is None:
        languages = [lang for lang in available_languages() if len(lang)==2]
    
    
    # Find country spellings 
    country_spellings = [(country, [dict(countries_for_language(lang))[country.upper()] for lang in languages]) for country in country_codes]
    
    
    # Drop duplicates
    country_spellings = [(country, list(set(spellings))) for country, spellings in country_spellings]
    
    
    # Add ISO codes to list of spellings
    country_spellings = [(country, spellings + [country.upper(), pycountry.countries.get(alpha_2=country.upper()).alpha_3]) 
                        for country, spellings in country_spellings]


    # Add official name if exists
    country_spellings = [(country, spellings + [pycountry.countries.get(alpha_2=country.upper()).official_name])
                         if 'official_name' in str(pycountry.countries.get(alpha_2=country))
                         else (country, spellings)
                         for country, spellings in country_spellings]
    
    
    return pd.DataFrame(country_spellings, columns=['country_code', 'spellings'])


def query_addresses(country_names: typing.List[str],
                    populated_fields: typing.List[str],
                    country: str,
                    geocode: bool=True,
                    sample: int=100000
                    ) -> str:
    """Creates a query for getting addresses search logs for a country

    :param country_names: list containing different spellings representing a same country. For example, for Spain: ['SPAIN', 'ESPAÑA', 'SPANJE', 'ESPANYA'] and more
    :type country_names: list
    :param populated_fields: list containing different populated fields, as can be found in "search_logs_insights" table in ADX
    :type populated_fields: list
    :param sample: sample size
    :type sample: int
    :param country: name of the country in order to have one unique country name as result of the query
    :type country: str
    :return: string representing the query necessary to sample a country
    :rtype: str
    """

    # Turn country_names and populated fields into strings
    country_names = str(tuple(country_names))
    populated_fields = str(tuple(populated_fields))
    
    
    if geocode==True:
        building_string = '''search_logs_insights
                             | where toupper(countryName) in~ {country_names}
                             | where method_name == 'search 2 geocode'
                             | where populated_fields in~ {populated_fields}
                             | sample {sample}
                             | extend countryName='{country}'
                             | where not(searched_query contains "�")
                             | summarize searches=count() by searched_query, populated_fields, ordered_populated_fields, countryName, developer_email
                             ;\n'''.format(country_names=country_names, populated_fields=populated_fields, country=country, sample=sample)
    
    else:
         building_string = '''search_logs_insights
                             | where toupper(countryName) in~ {country_names}
                             | where populated_fields in~ {populated_fields}
                             | sample {sample}    
                             | where not(searched_query contains "�")                        
                             | extend countryName='{country}'
                             | summarize searches=count() by searched_query, populated_fields, ordered_populated_fields, countryName, developer_email
                             ;\n'''.format(country_names=country_names, populated_fields=populated_fields, country=country, sample=sample)
    
    
    return building_string


def query_addresses_new(country_names: typing.List[str],
                       populated_fields: typing.List[str],
                       country: str,
                       geocode: bool=True,
                       sample: int=100000) -> str:
    """Creates a query for getting addresses search logs for a country but using search_log_insights_new

    :param country_names: list containing different spellings representing a same country. For example, for Spain: ['SPAIN', 'ESPAÑA', 'SPANJE', 'ESPANYA'] and more
    :type country_names: list
    :param populated_fields: list containing different populated fields, as can be found in "search_logs_insights" table in ADX
    :type populated_fields: list
    :param sample: sample size
    :type sample: int
    :param country: name of the country in order to have one unique country name as result of the query
    :type country: str
    :return: string representing the query necessary to sample a country
    :rtype: str
    """
    # Turn country_names and populated fields into strings
    country_names = str(tuple(country_names))
    populated_fields = str(tuple(populated_fields))
    
    
    if geocode==True:
        building_string = '''search_log_insights_new
                             | where toupper(countryName) in~ {country_names}
                             | where method_name == 'search 2 geocode'
                             | where populated_fields in~ {populated_fields}
                             | sample {sample}
                             | extend countryName='{country}'
                             | where not(searched_query contains "�")
                             | summarize searches=count() by searched_query, populated_fields, ordered_populated_fields, countryName
                             ;\n'''.format(country_names=country_names, populated_fields=populated_fields, country=country, sample=sample)
    else:
        building_string = '''search_log_insights_new
                             | where toupper(countryName) in~ {country_names}
                             | where populated_fields in~ {populated_fields}
                             | sample {sample}
                             | extend countryName='{country}'
                             | where not(searched_query contains "�")
                             | summarize searches=count() by searched_query, populated_fields, ordered_populated_fields, countryName
                             ;\n'''.format(country_names=country_names, populated_fields=populated_fields, country=country, sample=sample)
    
    return building_string


def parse_populated_fields(df: pd.DataFrame) -> pd.DataFrame:
    """Translate the keys from populated fields into readable content

    :param df: DataFrame of search logs containing column 'populated_fields' for which the components we wish to translate
    :type df: pd.DataFrame
    :return: DataFrame with column 'components' which has the 'populated_fields' components in a readable form.
    :rtype: pd.DataFrame
    """
    
    # Create connection to ADX and get populated fields master data
    tenant_id, client_id, secret_value, secret_id = connections_utils.get_adx_secrets()
    adx_instance = adx.AzureDataExplorer()
    populated_fields_master_df, _ = adx_instance.execute_adx_query(query='populated_fields_master_data',
                                                                   cluster="https://ttapianalyticsadxpweu.westeurope.kusto.windows.net",
                                                                   database="ttapianalytics-onlineSearch",
                                                                   client_id=client_id,
                                                                   secret_id=secret_id,
                                                                   tenant_id=tenant_id) 
    
    adx_instance = None
    
    # Parse
    df_copy = df.copy()
    
    # Create dictionary from 'populated_fields_master_df' to help translate populated fields
    fields_dictionary = pd.Series(populated_fields_master_df.populated_field_description.values,
                                  index=populated_fields_master_df.populated_field_id.astype(str)).to_dict()


    # Split by pipes and substitute each number with their corresponding component
    df_copy['components'] = df_copy.populated_fields.str.split('|')

    df_copy['components'] = (df_copy
                             .components
                             .apply(lambda x: [fields_dictionary[comp] for comp in x if comp!=''])
                                     )

    df_copy['number_components'] = df_copy.components.apply(lambda x: len(x))
    
    
    # Transform back to a single string divided by pipes
    df_copy['components'] = df_copy.components.apply(lambda x: '|'.join(x))
    
    return df_copy


def return_schema(df:pd.DataFrame) -> pd.DataFrame:
    """Adjusts log sample to final schema

    :param df: DataFrame containing addresses
    :type df: pd.DataFrame
    :return: DataFrame with current accepted schema
    :rtype: pd.DataFrame
    """
    
    cols = ['address','corrected_address','lat','lon','country','rooftop_id',
            'validation','gtd_validated','granular_components','sample_source','sample_status',
            'sample_id', 'config_id','logs_components', 'business_components', 'reversegeo_components']
    
    
    df['logs_components'] = (df[['logs_developer_email', 'logs_populated_fields',
                                 'logs_ordered_populated_fields', 'logs_searches', 'logs_weight']]
                             .to_dict(orient='records')
                             )
    df['business_components'] = (df[['foursquare_poi_name','foursquare_translated_poi_name','foursquare_gdf_category',
                                     'foursquare_gdf_sub_cat','foursquare_lat','foursquare_lon']]
                                 .to_dict(orient='records')
                                 )
    df['reversegeo_components'] = (df[['reversegeo_provider_id','reversegeo_lat','reversegeo_lon']]
                                                     .to_dict(orient='records')
                                                     )
    

    return df.loc[:, cols]


def get_country_logs(country:str, geocode:bool=True, new:bool=False, sample:int=100000) -> pd.DataFrame:
    """Gets search logs for a given country

    :param country: string of ISO-2 code of a country ('ES', not 'ESP').
    :type country: str
    :param geocode: whether to only query the 'search 2 geocode' enpoint, defaults to True, defaults to True
    :type geocode: bool, optional
    :param new: wether to query 'search_log_insights_new' instead of 'search_logs_insights', defaults to False
    :type new: bool, optional
    :param sample: Initial sample size, defaults to 100000
    :type sample: int, optional
    :return: DataFrame with logs for the country
    :rtype: pd.DataFrame
    """
    
    
    # Get country search patterns
    addresses = pkgutil.get_data(__name__, 'complete_addresses_patterns.txt')

    search_patterns_df = pd.read_csv(io.BytesIO(addresses), sep='\t')

    search_patterns_df = search_patterns_df.loc[search_patterns_df.components.str.contains('country')].reset_index(drop=True)


    # Country spellings and produce query
    country_names = generate_countries_spellings(country)
    
    if new==False:
        query_country = query_addresses(country_names=country_names.spellings[0],
                                        populated_fields=search_patterns_df.populated_fields.tolist(),
                                        country=country,
                                        geocode=geocode,
                                        sample=sample)
    else:
        query_country = query_addresses_new(country_names=country_names.spellings[0],
                                            populated_fields=search_patterns_df.populated_fields.tolist(),
                                            country=country,
                                            geocode=geocode,
                                            sample=sample)


    # Create connection to ADX and make query
    tenant_id, client_id, secret_value, secret_id = connections_utils.get_adx_secrets()
    adx_instance = adx.AzureDataExplorer()


    addresses_df, _ = adx_instance.execute_adx_query(query=query_country,
                                                    cluster="https://ttapianalyticsadxpweu.westeurope.kusto.windows.net",
                                                    database="ttapianalytics-onlineSearch",
                                                    client_id=client_id,
                                                    secret_id=secret_id,
                                                    tenant_id=tenant_id) 
    addresses_df = parse_populated_fields(addresses_df)
    addresses_df.countryName = addresses_df.countryName.str.upper()
    
    
    if 'developer_email' not in addresses_df.columns:
        addresses_df['developer_email'] = ''
    
    
    # Close connections
    adx_instance = None


    # Reduce customer
    addresses_clients_df = (addresses_df
                            .groupby(['searched_query', 'populated_fields', 'ordered_populated_fields', 'components', 'countryName'])
                            .agg({'developer_email': [lambda x: list(x), np.size],
                                'searches': 'sum'})
                            .reset_index()
                            )
    addresses_clients_df.columns = [col[0] if col[1]=='' else '_'.join(col) for col in addresses_clients_df.columns]
    addresses_clients_df.columns = [col.replace('_<lambda_0>', '') for col in addresses_clients_df.columns]


    # Compute weight
    addresses_clients_df['weight'] = addresses_clients_df.searches_sum/addresses_clients_df.searches_sum.sum()


    # Return current schema
    cols_schema = ['corrected_address','lat','lon','rooftop_id','config_id', 'validation','gtd_validated','granular_components','sample_status','sample_id',
                   'foursquare_poi_name','foursquare_translated_poi_name','foursquare_gdf_category','foursquare_gdf_sub_cat',
                   'foursquare_lat','foursquare_lon','reversegeo_provider_id','reversegeo_lat','reversegeo_lon']
    for col in cols_schema:
        addresses_clients_df[col] = np.NaN
    
    addresses_clients_df['sample_source'] = 'logs'
    addresses_clients_df = addresses_clients_df.rename(columns={'searched_query':'address',
                                                                'countryName':'country',
                                                                'developer_email':'logs_developer_email',
                                                                'populated_fields':'logs_populated_fields',
                                                                'ordered_populated_fields':'logs_ordered_populated_fields',
                                                                'searches_sum':'logs_searches',
                                                                'weight':'logs_weight'})
    addresses_clients_df = addresses_clients_df.loc[~addresses_clients_df.address.str.contains('�')].reset_index(drop=True)


    # Create dictionary columns
    addresses_clients_df = return_schema(addresses_clients_df)


    return addresses_clients_df


def deduplicate_dataframe(df:pd.DataFrame, 
                          simm_function:typing.Callable=fuzz.WRatio, 
                          cutoff:float=99) -> typing.Tuple[pd.DataFrame, pd.DataFrame]:
    """Deduplicates a list of addresses in a DataFrame

    :param df: DataFrame with column 'address' where there could be duplicate values
    :type df: pd.DataFrame
    :param simm_function: function for computing similarity, defaults to fuzz.WRatio
    :type simm_function: function, optional
    :param cutoff: minimum threshold for similarity (from 0 to 100), defaults to 99
    :type cutoff: float, optional
    :return: a tuple where first element is DataFrame deduplicated and second is a 
    pandas.DataFrame of the duplicates
    :rtype: typing.Tuple[pd.DataFrame, pd.DataFrame]
    """
    
    # Create list to store results and also list for candidates
    deduplicates = []
    addresses_search = df.address.reset_index().values.tolist()


    # Loop over addresses
    for idx in range(len(addresses_search)):


        # The candidates get smaller as we iterate over the original list of addresses
        address = addresses_search[idx]
        address_lookup = addresses_search[(idx+1):]
        address_str = [adr[1] for adr in address_lookup]
        
        
        deduplicates.append((address, process.extract(query=address[1], 
                                                    choices=address_str, 
                                                    scorer=simm_function, 
                                                    score_cutoff=cutoff)))
    
    # We find the addresses that are duplicated and filter them 
    duplicated = [adr for adr in deduplicates if adr[1] != []]
    address_out = [(pair[0][1], dup[0]) for pair in duplicated for dup in pair[1]]
    address_out_df = pd.DataFrame(address_out, columns=['address', 'duplicate'])
    
    df_copy = df.loc[~df.address.isin(address_out_df.duplicate)].reset_index(drop=True)

    
    return df_copy, address_out_df

if __name__ == '__main__':
    get_country_logs('us')