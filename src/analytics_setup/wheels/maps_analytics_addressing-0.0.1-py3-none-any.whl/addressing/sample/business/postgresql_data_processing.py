from datetime import datetime

import pandas
import numpy
import typing
import country_converter


def apply_schema_to_df(dataframe: pandas.DataFrame, country: str, address_field: pandas.DataFrame, version: int = 1) -> pandas.DataFrame:
    """Applies data transformations to the extraction, so its output corresponds to the defined schema:
    :param dataframe: pandas DataFrame
    :type: dataframe: pandas DataFrame
    :param country: country iso3 code
    :type country: string
    :param address_field: pandas series/ dataframe column containing the address information
    :type iso2code: pandas series
    :param version: version of the sample generation (default = 1)
    :type version: int, optional
    :return: Dataframe with the tranformations applied
    :rtype: pandas.DataFrame
    """

    # DataFrame's columns:
    columns = ['address', 'corrected_address',
               'lat', 'lon', 'country',
               'rooftop_osm_id', 'validation',
               'gtd_validated','granular_components',
               'sample_source', 'sample_status', 
               'sample_id', 'config_id', 
               'logs_components','business_components', 'reversegeo_components']
    
    # Search logs components (null for the business sample):
    logs_components = {'logs_developer_email': numpy.nan,
                       'logs_populated_fields': numpy.nan,
                       'logs_ordered_populated_fields': numpy.nan,
                       'logs_searches': numpy.nan,
                       'logs_weight': numpy.nan}
    
    # Reverse geo components (null for the business sample):
    reversegeo_components = {'reversegeo_provider_id': numpy.nan,
                             'reversegeo_lat': numpy.nan,
                             'reversegeo_lon': numpy.nan}
    
    # Columns tansformations:
    df = pandas.DataFrame(columns = columns)

    try:
        df['address'] = address_field.tolist()
        df['lat'] = dataframe['lat'].tolist()
        df['lon'] = dataframe['lon'].tolist()
        df['country'] = country_converter.convert(country, to='ISO2', not_found=None).lower()
        df['business_components'] = dataframe['business_components'].tolist()
        df.loc[:,'sample_source'] = 'business'
        df.loc[:,'sample_status'] = 1
        df.loc[:,'sample_id'] = str(datetime.date(datetime.now())).replace('-','') + '000' + str(version)
        df.loc[:,'logs_components'] = str(logs_components)
        df.loc[:,'reversegeo_components'] = str(reversegeo_components)
        df.loc[:,'config_id'] = numpy.nan
    except Exception as err:
        print(f"Error while applying schema to data from country {country}: {err}")

    return df


def define_pssr_sample(df: pandas.DataFrame) -> typing.Dict:
    """Queries the PSSR database to extract locality and category information

    :param df: Dataframe with the PSSR data
    :type df: pandas.DataFrame
    :return: Dictionary with the PSSR where the key corresponds to a country
    :rtype: typing.Dict
    """
    out_df = df.drop_duplicates(['address']).reset_index(drop=True)
    out_df['lat'] = [out_df.location.loc[i].replace('POINT ','').replace('(','').replace(')','').split()[1] for i in range(len(out_df))]
    out_df['lon'] = [out_df.location.loc[i].replace('POINT ','').replace('(','').replace(')','').split()[0] for i in range(len(out_df))]
    out_df['category'] = [list(set(out_df.classification.loc[i].replace('}','').replace('{','').replace('(','').replace(')','').replace('"','').split(',')))[0] for i in range(len(out_df))]

    subcat=[]
    
    for i in range(len(out_df)):
        try:
          subcat.append(list(set(out_df.classification.loc[i].replace('}','')
                                 .replace('{','')
                                 .replace('(','')
                                 .replace(')','')
                                 .replace('"','')
                                 .split(',')))[1])
        except:
            subcat.append(list(set(out_df.classification.loc[i].replace('}','')
                                   .replace('{','')
                                   .replace('(','')
                                   .replace(')','')
                                   .replace('"','')
                                   .split(',')))[0])
    
    out_df['subcategory'] = subcat
    
    for i, cat in zip(range(len(out_df)), out_df.category):
        if cat == 'missing':
            out_df.category.loc[i] = out_df.subcategory.loc[i]
    
    out_df['business_components'] = [{'pssr_poi_category': out_df.category.loc[i],
                                  'pssr_poi_subcategory': out_df.subcategory.loc[i], 
                                  'pssr_poi_lat': out_df.lat.loc[i],
                                  'pssr_poi_lon': out_df.lon.loc[i]} for i in range(len(out_df))]
    
    return {i: apply_schema_to_df(out_df[out_df.country == str(i)].reset_index(drop=True), str(i), 
                             out_df[out_df.country == str(i)].address) for i in out_df.country.unique().tolist()}