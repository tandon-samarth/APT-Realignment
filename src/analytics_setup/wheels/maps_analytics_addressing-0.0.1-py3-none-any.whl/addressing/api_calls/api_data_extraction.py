from abc import ABC, abstractmethod
import re

import typing
import pandas


class ApiResponseExtractor(ABC):
    """
    Declares the operations that API reponse extractor must implement
    """


    @abstractmethod
    def get_items_from_response(self, response: typing.Dict, reverse: bool = False) -> typing.List[typing.Dict]:
        """Extracts the items from an API call response

        :param response: Response of the API request
        :type response: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: List of items
        :rtype: typing.List[typing.Dict]
        """
        pass


    @abstractmethod
    def get_data_from_item(self, item: typing.Dict, reverse: bool = False) -> typing.Tuple[typing.Dict, str, str, str, float, float, str]:
        """Gets data from an item. It returns the address components, API ID, type, address, latitude, longitude and country

        :param item: Item with the provider data
        :type item: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Address components, API ID, type, address, latitude, longitude and country
        :rtype: typing.Tuple[str, str, str, str, float, float, str]
        """
        pass


    @abstractmethod
    def get_df_from_components(self, components: typing.Dict, reverse: bool = False) -> pandas.DataFrame:
        """Gets data from a given address components object and returns a pandas DataFrame

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Pandas DataFrame with the address component data
        :rtype: pandas.DataFrame
        """
        df = pandas.Series(components).to_frame().T
        return df


    @abstractmethod
    def get_components_formatted(self, components: typing.Dict, reverse: bool = False) -> typing.Dict:
        """Gets dictionary with the components data formatted from a given address components object

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: typing.Dict with the data formatted
        :rtype: typing.Dict
        """
        return components
    
    
    def get_df_from_item(self, item: typing.Dict, reverse: bool = False) -> pandas.DataFrame:
        """Gets data from a given item object and returns a pandas DataFrame with its fields

        :param components: Item
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Pandas DataFrame with the address component data
        :rtype: pandas.DataFrame
        """
        # Gets the basic fields from the item
        components, api_id, type, address, lat, lon, country = self.get_data_from_item(item, reverse)
        
        # Gets DataFrame with the components data
        components_df = self.get_df_from_components(components, reverse)
        
        # Inserts the basic provider fields into the components DataFrame
        components_df = components_df.assign(components=str(components))
        components_df = components_df.assign(country=country)
        components_df = components_df.assign(lon=lon)
        components_df = components_df.assign(lat=lat)
        components_df = components_df.assign(type=type)
        components_df = components_df.assign(address=address)
        components_df = components_df.assign(apiId=api_id)
        
        return components_df


class TomtomResponseExtractor(ApiResponseExtractor):
    """
    Class that represent the Tomtom Response Extractor with the methods to call it
    """


    def get_items_from_response(self, response: typing.Dict, reverse: bool = False) -> typing.List[typing.Dict]:
        """Extracts the items from an API call response

        :param response: Response of the API request
        :type response: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: List of items
        :rtype: typing.List[typing.Dict]
        """
        if reverse:
            return response.get("addresses",[])
        return response.get("results",[])


    def get_data_from_item(self, item: typing.Dict, reverse: bool = False) -> typing.Tuple[typing.Dict, str, str, str, float, float, str]:
        """Gets data from an item. It returns the address components, API ID, type, address, latitude, longitude and country

        :param item: Item with the provider data
        :type item: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Address components, API ID, type, address, latitude, longitude and country
        :rtype: typing.Tuple[typing.Dict, str, str, str, float, float, str]
        """
        provider_address_components = item.get("address",{})
        provider_api_id = item.get("id","")
        provider_type = item.get("type","")
        provider_address = item.get("address",{}).get("freeformAddress","")
        provider_country = item.get("address",{}).get("country", "")
        if reverse:
            try:
                provider_lat = item.get("position","").split(",")[0]
                provider_lon = item.get("position","").split(",")[1]
            except (IndexError, ValueError):
                print("Error while extraction the coordinates")
                provider_lat = ""
                provider_lon = ""
        else:
            provider_lat = item.get("position",{}).get("lat","")
            provider_lon = item.get("position",{}).get("lon","")
        return self.get_components_formatted(provider_address_components), provider_api_id, provider_type, provider_address, provider_lat, provider_lon, provider_country


    def get_df_from_components(self, components: typing.Dict, reverse: bool = False) -> pandas.DataFrame:
        """Gets data from a given address components object and returns a pandas DataFrame

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Pandas DataFrame with the address component data
        :rtype: pandas.DataFrame
        """
        df = pandas.Series(components).to_frame().T
        
        # Renames the columns according to our standard
        df.rename(columns={'municipality':'locality'}, inplace=True)
        
        return df


    def get_components_formatted(self, components: typing.Dict, reverse: bool = False) -> typing.Dict:
        """Gets dictionary with the components data formatted from a given address components object

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: typing.Dict with the data formatted
        :rtype: typing.Dict
        """
        country = components.get('country', '')
        components_dict = {'street_number': str(components.get('streetNumber', '')), 
                   'street_name': components.get('streetName', ''),
                   'locality': components.get('municipality', ''),
                   'postcode': components.get('postalCode', ''),
                   'country_code_ISO2': components.get('countryCode', ''),
                   'country_code_ISO3': components.get('countryCodeISO3', ''),
                   'country': country,
                  }
        return components_dict


class GoogleResponseExtractor(ApiResponseExtractor):
    """
    Class that represent the Google Response Extractor with the methods to call it
    """

    def get_items_from_response(self, response: typing.Dict, reverse: bool = False) -> typing.List[typing.Dict]:
        """Extracts the items from an API call response

        :param response: Response of the API request
        :type response: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: List of items
        :rtype: typing.List[typing.Dict]
        """
        return response.get('results',[])


    def get_data_from_item(self, item: typing.Dict, reverse: bool = False) -> typing.Tuple[typing.List, str, str, str, float, float]:
        """Gets data from an item. It returns the address components, API ID, type, address, latitude, longitude and country

        :param item: Item with the provider data
        :type item: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Address components, API ID, type, address, latitude and longitude
        :rtype: typing.Tuple[typing.List, str, str, str, float, float, str]
        """
        provider_address_components = item.get('address_components',[])
        provider_api_id = item.get('place_id',"")
        provider_type = str(item.get('types',""))
        provider_address = item.get('formatted_address',"")
        provider_lat = item.get('geometry',{}).get('location',{}).get('lat',"")
        provider_lon = item.get('geometry',{}).get('location',{}).get('lng',"")
        country = ""
        for component in item.get('address_components',[]):
            if "country" in component.get("types",[]):
                country = component.get("long_name","")
        return self.get_components_formatted(provider_address_components), provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country
    
    
    def get_df_from_components(self, components: typing.List, reverse: bool = False) -> pandas.DataFrame:
        """Gets data from a given address components object and returns a pandas DataFrame

        :param components: Components of an address
        :type components: typing.List
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Pandas DataFrame with the address component data
        :rtype: pandas.DataFrame
        """
        # Extracts the component from the given list
        data = {}
        for component in components:
            try:
                if "country" in component.get("types",[]):
                    data['countryCode'] = component.get("short_name","")
                elif "street_number" in component.get("types",[]):
                    data['streetNumber'] = component.get("short_name","")
                    data['extendedPostalCode'] = component.get("long_name","")
                elif "locality" in component.get("types",[]):
                    data['locality'] = component.get("long_name","")
                elif "postal_code" in component.get("types",[]):
                    data['postalCode'] = component.get("long_name","")
                elif "route" in component.get("types",[]):
                    data['streetName'] = component.get("long_name","")
                else:
                    if component.get("types",[]):
                        data[component.get("types",[])[0]] = component.get("long_name","")
            except Exception as err:
                print(f"Error while trying to extract a component: {err}")
        df = pandas.Series(data).to_frame().T
        
        return df


    def get_components_formatted(self, components: typing.Dict, reverse: bool = False) -> typing.Dict:
        """Gets dictionary with the components data formatted from a given address components object

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: typing.Dict with the data formatted
        :rtype: typing.Dict
        """
        components_dict = {}
        for component in components:
            try:
                if "country" in component.get("types",[]):
                    components_dict['country_code_ISO2'] = component.get("short_name","")
                    components_dict['country'] = component.get("long_name","")
                elif "street_number" in component.get("types",[]):
                    components_dict['street_number'] = str(component.get("short_name",""))
                elif "locality" in component.get("types",[]):
                    components_dict['locality'] = component.get("long_name","")
                elif "postal_code" in component.get("types",[]):
                    components_dict['postcode'] = component.get("long_name","")
                elif "route" in component.get("types",[]):
                    components_dict['street_name'] = component.get("long_name","")
            except Exception as err:
                print(f"Error while trying to extract a component: {err}")
        return components_dict


class HereResponseExtractor(ApiResponseExtractor):
    """
    Class that represent the Here Response Extractor with the methods to call it
    """


    def get_items_from_response(self, response: typing.Dict, reverse: bool = False) -> typing.List[typing.Dict]:
        """Extracts the items from an API call response

        :param response: Response of the API request
        :type response: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: List of items
        :rtype: typing.List[typing.Dict]
        """
        return response.get('items',[])


    def get_data_from_item(self, item: typing.Dict, reverse: bool = False) -> typing.Tuple[str, str, str, str, float, float, str]:
        """Gets data from an item. It returns the address components, API ID, type, address, latitude, longitude and country

        :param item: Item with the provider data
        :type item: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Address components, API ID, type, address, latitude, longitude and country
        :rtype: typing.Tuple[str, str, str, str, float, float, str]
        """
        provider_address_components = item.get('address',"")
        provider_api_id = item.get("id","")
        provider_type = item.get('resultType',"")
        provider_address = item.get('address',{}).get("label", "")
        provider_lat = item.get('position',{}).get("lat", "")
        provider_lon = item.get('position',{}).get("lng", "")
        country = item.get('address',{}).get("countryName", "")
        return self.get_components_formatted(provider_address_components), provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country


    def get_df_from_components(self, components: typing.Dict, reverse: bool = False) -> pandas.DataFrame:
        """Gets data from a given address components object and returns a pandas DataFrame

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Pandas DataFrame with the address component data
        :rtype: pandas.DataFrame
        """
        df = pandas.Series(components).to_frame().T
        
        # Renames the columns according to our standard
        df.rename(columns={'countryRegion':'countryCodeISO3'}, inplace=True)
        df.rename(columns={'houseNumber':'streetNumber'}, inplace=True)
        df.rename(columns={'street':'streetName'}, inplace=True)
        df.rename(columns={'city':'locality'}, inplace=True)
        
        return df
    

    def get_components_formatted(self, components: typing.Dict, reverse: bool = False) -> typing.Dict:
        """Gets dictionary with the components data formatted from a given address components object

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: typing.Dict with the data formatted
        :rtype: typing.Dict
        """
        country = components.get('countryName', '')
        components_dict = {'street_number': str(components.get('houseNumber', '')), 
                   'street_name': components.get('street', ''),
                   'locality': components.get('city', ''),
                   'postcode': components.get('postalCode', ''),
                   'country_code_ISO3': components.get('countryCode', ''),
                   'country': country,
                  }
        return components_dict


class BingResponseExtractor(ApiResponseExtractor):
    """
    Class that represent the Bing Response Extractor with the methods to call it
    """


    def get_items_from_response(self, response: typing.Dict, reverse: bool = False) -> typing.List[typing.Dict]:
        """Extracts the items from an API call response

        :param response: Response of the API request
        :type response: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: List of items
        :rtype: typing.List[typing.Dict]
        """
        items = []
        if response.get("resourceSets",[]):
            try:
                items = response.get("resourceSets",[])[0].get("resources",[])
            except AttributeError:
                print("Error while extracting items")
        return items


    def get_data_from_item(self, item: typing.Dict, reverse: bool = False) -> typing.Tuple[typing.Dict, str, str, str, float, float]:
        """Gets data from an item. It returns the address components, API ID, type, address, latitude, longitude and country

        :param item: Item with the provider data
        :type item: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Address components, API ID, type, address, latitude, longitude and country
        :rtype: typing.Tuple[typing.Dict, str, str, str, float, float, str]
        """
        provider_address_components = item.get('address',{})
        provider_api_id = ""
        provider_type = item.get('point',{}).get("type","")
        provider_address = item.get('address',{}).get('formattedAddress',"")
        try:
            provider_lat = item.get('point',{}).get('coordinates',[])[0]
            provider_lon = item.get('point',{}).get('coordinates',[])[1]
        except (IndexError, ValueError):
            print("Error while extraction the coordinates")
            provider_lat = ""
            provider_lon = ""
        country = item.get('address',{}).get('countryRegion',"")
        return self.get_components_formatted(provider_address_components), provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country


    def get_df_from_components(self, components: typing.Dict, reverse: bool = False) -> pandas.DataFrame:
        """Gets data from a given address components object and returns a pandas DataFrame

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Pandas DataFrame with the address component data
        :rtype: pandas.DataFrame
        """
        df = pandas.Series(components).to_frame().T
        
        # Extracts the name and number of the street from addressLine field
        street_regex = re.compile(r'(?P<number>[0-9]+[^ ]?)*(?P<name>.*)')
        match = street_regex.search(components.get("addressLine", ""))
        if match:
            street_dict = match.groupdict()
            street_number = street_dict.get('number').strip() if street_dict.get('number') else None
            street_name = street_dict.get('name').strip() if street_dict.get('name') else None
            
            # Inserts the new fields into the DataFrame
            df.insert(0, "streetNumber", street_number, allow_duplicates=True)
            df.insert(0, "streetName", street_name, allow_duplicates=True)
        return df


    def get_components_formatted(self, components: typing.Dict, reverse: bool = False) -> typing.Dict:
        """Gets dictionary with the components data formatted from a given address components object

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: typing.Dict with the data formatted
        :rtype: typing.Dict
        """
        country = components.get('countryRegion', '')
        street_regex_left = re.compile(r'(?P<number>[0-9]+[^ ]?)*(?P<name>.*)')
        street_regex_right = re.compile(r'(?P<name>[^0-9]*)(?P<number>[0-9]+.*)?')
        match_left = street_regex_left.search(components.get("addressLine", ""))
        match_right = street_regex_right.search(components.get("addressLine", ""))
        if match_left.groups()[0] is not None:
            street_dict = match_left.groupdict()
            street_number = street_dict.get('number').strip() if street_dict.get('number') else None
            street_name = street_dict.get('name').strip() if street_dict.get('name') else None
        else:
            street_dict = match_right.groupdict()
            street_number = street_dict.get('number').strip() if street_dict.get('number') else None
            street_name = street_dict.get('name').strip() if street_dict.get('name') else None 

        components_dict = {'street_number': street_number, 
                        'street_name': street_name,
                        'locality': components.get('locality', ''),
                        'postcode': components.get('postalCode', ''),
                        'country': country,
                        }
        return components_dict
    

class OpenMapResponseExtractor(ApiResponseExtractor):
    """
    Class that represent the OpenMap Response Extractor with the methods to call it
    """


    def get_items_from_response(self, response: typing.Dict, reverse: bool = False) -> typing.List[typing.Dict]:
        """Extracts the items from an API call response

        :param response: Response of the API request
        :type response: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: List of items
        :rtype: typing.List[typing.Dict]
        """
        if reverse:
            return response.get('addresses',[])
        return response.get('results',[])

    def get_data_from_item(self, item: typing.Dict, reverse: bool = False) -> typing.Tuple[typing.Dict, str, str, str, float, float, str]:
        """Gets data from an item. It returns the address components, API ID, type, address, latitude, longitude and country

        :param item: Item with the provider data
        :type item: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Address components, API ID, type, address, latitude, longitude and country
        :rtype: typing.Tuple[typing.Dict, str, str, str, float, float, str]
        """
        provider_address_components = item.get("address",{})
        provider_api_id = item.get("id","")
        provider_type = item.get("type","")
        provider_address = item.get("address",{}).get("freeformAddress","")
        country = item.get("address",{}).get("country", "")
        if reverse:
            try:
                provider_lat = item.get("position","").split(",")[0]
                provider_lon = item.get("position","").split(",")[1]
            except (IndexError, ValueError):
                print("Error while extraction the coordinates")
                provider_lat = ""
                provider_lon = ""
        else:
            provider_lat = item.get("position",{}).get("lat")
            provider_lon = item.get("position",{}).get("lon")
        return self.get_components_formatted(provider_address_components), provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country


    def get_df_from_components(self, components: typing.Dict, reverse: bool = False) -> pandas.DataFrame:
        """Gets data from a given address components object and returns a pandas DataFrame

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Pandas DataFrame with the address component data
        :rtype: pandas.DataFrame
        """
        df = pandas.Series(components).to_frame().T
        
        # Renames the columns according to our standard
        df.rename(columns={'municipality':'locality'}, inplace=True)
        return df
    

    def get_components_formatted(self, components: typing.Dict, reverse: bool = False) -> typing.Dict:
        """Gets dictionary with the components data formatted from a given address components object

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: typing.Dict with the data formatted
        :rtype: typing.Dict
        """
        components_dict = {'street_number': str(components.get('streetNumber', '')), 
                   'street_name': components.get('streetName', ''),
                   'locality': components.get('municipality', ''),
                   'postcode': components.get('postalCode', ''),
                   'country_code_ISO2': components.get('countryCode', ''),
                   'country_code_ISO3': components.get('countryCodeISO3', ''),
                   'country': components.get('country', ''),
                  }
        return components_dict
        

class OSMResponseExtractor(ApiResponseExtractor):
    """
    Class that represent the OSM Response Extractor with the methods to call it
    """


    def get_items_from_response(self, response: typing.Union[typing.Dict, typing.List], reverse: bool = False) -> typing.List[typing.Dict]:
        """Extracts the items from an API call response

        :param response: Response of the API request
        :type response: typing.Union[typing.Dict, typing.List]
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: List of items
        :rtype: typing.List[typing.Dict]
        """
        if reverse:
            return [response]
        return response


    def get_data_from_item(self, item: typing.Dict, reverse: bool = False) -> typing.Tuple[typing.Dict, str, str, str, float, float]:
        """Gets data from an item. It returns the address components, API ID, type, address, latitude, longitude and country

        :param item: Item with the provider data
        :type item: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Address components, API ID, type, address, latitude, longitude and country
        :rtype: typing.Tuple[typing.Dict, str, str, str, float, float,  str]
        """
        # Extracts data from the response
        provider_address_components = item.get("address",{})
        provider_api_id = item.get("osm_type", "")
        provider_type = item.get("type", "")
        provider_address = item.get("display_name", "")
        provider_lat = item.get("lat", "")
        provider_lon = item.get("lon", "")
        country = item.get("address",{}).get("country", "")
        return self.get_components_formatted(provider_address_components), provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country


    def get_df_from_components(self, components: typing.Dict, reverse: bool = False) -> pandas.DataFrame:
        """Gets data from a given address components object and returns a pandas DataFrame

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: Pandas DataFrame with the address component data
        :rtype: pandas.DataFrame
        """
        df = pandas.Series(components).to_frame().T
        
        # Renames the columns according to our standard
        df.rename(columns={'house_number':'streetNumber'}, inplace=True)
        df.rename(columns={'road':'streetName'}, inplace=True)
        df.rename(columns={'country_code':'countryCode'}, inplace=True)
        df.rename(columns={'postcode':'postalCode'}, inplace=True)
        df.rename(columns={'city':'locality'}, inplace=True)
        
        # Set the countryCode to upper case
        df['countryCode'] = df['countryCode'].str.upper()
        
        return df


    def get_components_formatted(self, components: typing.Dict, reverse: bool = False) -> typing.Dict:
        """Gets dictionary with the components data formatted from a given address components object

        :param components: Components of an address
        :type components: typing.Dict
        :param reverse: Is it reverse geocoding?
        :type reverse: bool
        :return: typing.Dict with the data formatted
        :rtype: typing.Dict
        """
        country = components.get('country', '')
        components_dict = {'street_number': str(components.get('house_number', '')), 
                   'street_name': components.get('road', ''),
                   'locality': components.get('city', ''),
                   'postcode': components.get('postcode', ''),
                   'country_code_ISO2': components.get('country_code', '').upper(),
                   'country': country,
                  }
        return components_dict
    
    
if __name__ == "__main__":
    print("- Extracting data from Bing response (geocoding)")
    response = {'authenticationResultCode': 'ValidCredentials', 'brandLogoUri': 'http://dev.virtualearth.net/Branding/logo_powered_by.png', 'copyright': 'Copyright © 2021 Microsoft and its suppliers. All rights reserved. This API cannot be accessed and the content and any results may not be used, reproduced or transmitted in any manner without express written permission from Microsoft Corporation.', 'resourceSets': [{'estimatedTotal': 1, 'resources': [{'__type': 'Location:http://schemas.microsoft.com/search/local/ws/rest/v1', 'bbox': [35.96587228242932, -95.93012035600087, 35.97359771757068, -95.91739364399912], 'name': '13219 Kimberly Clark Pl, Jenks, OK 74008', 'point': {'type': 'Point', 'coordinates': [35.969735, -95.923757]}, 'address': {'addressLine': '13219 Kimberly Clark Pl', 'adminDistrict': 'OK', 'adminDistrict2': 'Tulsa County', 'countryRegion': 'United States', 'formattedAddress': '13219 Kimberly Clark Pl, Jenks, OK 74008', 'locality': 'Jenks', 'postalCode': '74008'}, 'confidence': 'High', 'entityType': 'Address', 'geocodePoints': [{'type': 'Point', 'coordinates': [35.969735, -95.923757], 'calculationMethod': 'Rooftop', 'usageTypes': ['Display']}, {'type': 'Point', 'coordinates': [35.9700727, -95.9235352], 'calculationMethod': 'Rooftop', 'usageTypes': ['Route']}], 'matchCodes': ['Good']}]}], 'statusCode': 200, 'statusDescription': 'OK', 'traceId': '628b8341b72a409fa84f8e0d75eec150|DU00002744|0.0.0.1|Ref A: BE38C72F100D40798DFDBA060C7069D0 Ref B: DB3EDGE1810 Ref C: 2021-12-15T16:28:57Z'}
    extractor = BingResponseExtractor()
    item = extractor.get_items_from_response(response)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0])
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)
    df = extractor.get_df_from_components(provider_address_components)
    df = extractor.get_df_from_item(item[0])
    print(df)
    
    print("- Extracting data from Bing response (reverse geocoding)")
    response = {'authenticationResultCode': 'ValidCredentials', 'brandLogoUri': 'http://dev.virtualearth.net/Branding/logo_powered_by.png', 'copyright': 'Copyright © 2021 Microsoft and its suppliers. All rights reserved. This API cannot be accessed and the content and any results may not be used, reproduced or transmitted in any manner without express written permission from Microsoft Corporation.', 'resourceSets': [{'estimatedTotal': 1, 'resources': [{'__type': 'Location:http://schemas.microsoft.com/search/local/ws/rest/v1', 'bbox': [35.965348982429326, -95.93037161382874, 35.97307441757068, -95.91764498617125], 'name': '13262 S Yale Pl, Jenks, OK 74008, United States', 'point': {'type': 'Point', 'coordinates': [35.9692117, -95.9240083]}, 'address': {'addressLine': '13262 S Yale Pl', 'adminDistrict': 'OK', 'adminDistrict2': 'Tulsa Co.', 'countryRegion': 'United States', 'formattedAddress': '13262 S Yale Pl, Jenks, OK 74008, United States', 'locality': 'Jenks', 'postalCode': '74008'}, 'confidence': 'High', 'entityType': 'Address', 'geocodePoints': [{'type': 'Point', 'coordinates': [35.9692117, -95.9240083], 'calculationMethod': 'Rooftop', 'usageTypes': ['Display']}], 'matchCodes': ['Good']}]}], 'statusCode': 200, 'statusDescription': 'OK', 'traceId': 'd449ae0c2ed748d7812ebd77f0ae479a|DU0000273D|0.0.0.1|DU01EAP000003EB'}
    item = extractor.get_items_from_response(response, True)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0], True)
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)
    
    print("- Extracting data from Google response (geocoding)")
    response = {'results': [{'address_components': [{'long_name': '13219', 'short_name': '13219', 'types': ['street_number']}, {'long_name': 'Kimberly Clark Place', 'short_name': 'Kimberly Clark Pl', 'types': ['route']}, {'long_name': 'Bixby', 'short_name': 'Bixby', 'types': ['locality', 'political']}, {'long_name': 'Tulsa County', 'short_name': 'Tulsa County', 'types': ['administrative_area_level_2', 'political']}, {'long_name': 'Oklahoma', 'short_name': 'OK', 'types': ['administrative_area_level_1', 'political']}, {'long_name': 'United States', 'short_name': 'US', 'types': ['country', 'political']}, {'long_name': '74008', 'short_name': '74008', 'types': ['postal_code']}], 'formatted_address': '13219 Kimberly Clark Pl, Bixby, OK 74008, USA', 'geometry': {'location': {'lat': 35.9668213, 'lng': -95.9309273}, 'location_type': 'RANGE_INTERPOLATED', 'viewport': {'northeast': {'lat': 35.9681702802915, 'lng': -95.92957831970848}, 'southwest': {'lat': 35.9654723197085, 'lng': -95.9322762802915}}}, 'place_id': 'Ei0xMzIxOSBLaW1iZXJseSBDbGFyayBQbCwgQml4YnksIE9LIDc0MDA4LCBVU0EiGxIZChQKEgnjxNYvXZC2hxEl6JO3jwaoDxCjZw', 'types': ['street_address']}], 'status': 'OK'}
    extractor = GoogleResponseExtractor()
    item = extractor.get_items_from_response(response)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0])
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)
    
    print("- Extracting data from Google response (reverse geocoding)")
    response = {'plus_code': {'compound_code': 'X39G+92Q Jenks, OK, USA', 'global_code': '8676X39G+92Q'}, 'results': [{'address_components': [{'long_name': 'X39G+92', 'short_name': 'X39G+92', 'types': ['plus_code']}, {'long_name': 'Jenks', 'short_name': 'Jenks', 'types': ['locality', 'political']}, {'long_name': 'Tulsa County', 'short_name': 'Tulsa County', 'types': ['administrative_area_level_2', 'political']}, {'long_name': 'Oklahoma', 'short_name': 'OK', 'types': ['administrative_area_level_1', 'political']}, {'long_name': 'United States', 'short_name': 'US', 'types': ['country', 'political']}], 'formatted_address': 'X39G+92 Jenks, OK, USA', 'geometry': {'bounds': {'northeast': {'lat': 35.9685, 'lng': -95.924875}, 'southwest': {'lat': 35.968375, 'lng': -95.925}}, 'location': {'lat': 35.9684699, 'lng': -95.92487589999999}, 'location_type': 'GEOMETRIC_CENTER', 'viewport': {'northeast': {'lat': 35.9697864802915, 'lng': -95.9235885197085}, 'southwest': {'lat': 35.9670885197085, 'lng': -95.92628648029151}}}, 'place_id': 'GhIJh9RZ0vb7QUAR8tavKjH7V8A', 'plus_code': {'compound_code': 'X39G+92 Jenks, OK, USA', 'global_code': '8676X39G+92'}, 'types': ['plus_code']}, {'address_components': [{'long_name': 'Unnamed Road', 'short_name': 'Unnamed Road', 'types': ['route']}, {'long_name': 'Bixby', 'short_name': 'Bixby', 'types': ['locality', 'political']}, {'long_name': 'Tulsa County', 'short_name': 'Tulsa County', 'types': ['administrative_area_level_2', 'political']}, {'long_name': 'Oklahoma', 'short_name': 'OK', 'types': ['administrative_area_level_1', 'political']}, {'long_name': 'United States', 'short_name': 'US', 'types': ['country', 'political']}, {'long_name': '74008', 'short_name': '74008', 'types': ['postal_code']}], 'formatted_address': 'Unnamed Road, Bixby, OK 74008, USA', 'geometry': {'bounds': {'northeast': {'lat': 35.9670219, 'lng': -95.9202956}, 'southwest': {'lat': 35.9670111, 'lng': -95.92629649999999}}, 'location': {'lat': 35.9670193, 'lng': -95.9232961}, 'location_type': 'GEOMETRIC_CENTER', 'viewport': {'northeast': {'lat': 35.9683654802915, 'lng': -95.9202956}, 'southwest': {'lat': 35.9656675197085, 'lng': -95.92629649999999}}}, 'place_id': 'ChIJne4ys0GQtocRDvHmLmOENKI', 'types': ['route']}, {'address_components': [{'long_name': 'Jenks', 'short_name': 'Jenks', 'types': ['locality', 'political']}, {'long_name': 'Tulsa County', 'short_name': 'Tulsa County', 'types': ['administrative_area_level_2', 'political']}, {'long_name': 'Oklahoma', 'short_name': 'OK', 'types': ['administrative_area_level_1', 'political']}, {'long_name': 'United States', 'short_name': 'US', 'types': ['country', 'political']}], 'formatted_address': 'Jenks, OK, USA', 'geometry': {'bounds': {'northeast': {'lat': 36.04310290000001, 'lng': -95.913669}, 'southwest': {'lat': 35.958927, 'lng': -96.0298229}}, 'location': {'lat': 36.0228734, 'lng': -95.9683278}, 'location_type': 'APPROXIMATE', 'viewport': {'northeast': {'lat': 36.04310290000001, 'lng': -95.913669}, 'southwest': {'lat': 35.958927, 'lng': -96.0298229}}}, 'place_id': 'ChIJe9qPRxmRtocRIaxjmHNpZKk', 'types': ['locality', 'political']}, {'address_components': [{'long_name': '74008', 'short_name': '74008', 'types': ['postal_code']}, {'long_name': 'Bixby', 'short_name': 'Bixby', 'types': ['locality', 'political']}, {'long_name': 'Oklahoma', 'short_name': 'OK', 'types': ['administrative_area_level_1', 'political']}, {'long_name': 'United States', 'short_name': 'US', 'types': ['country', 'political']}], 'formatted_address': 'Bixby, OK 74008, USA', 'geometry': {'bounds': {'northeast': {'lat': 36.005693, 'lng': -95.7368489}, 'southwest': {'lat': 35.8520259, 'lng': -95.99387689999999}}, 'location': {'lat': 35.92399169999999, 'lng': -95.8775964}, 'location_type': 'APPROXIMATE', 'viewport': {'northeast': {'lat': 36.005693, 'lng': -95.7368489}, 'southwest': {'lat': 35.8520259, 'lng': -95.99387689999999}}}, 'place_id': 'ChIJL7HFrxeFtocRHIciH3-kEdc', 'types': ['postal_code']}, {'address_components': [{'long_name': 'Tulsa County', 'short_name': 'Tulsa County', 'types': ['administrative_area_level_2', 'political']}, {'long_name': 'Oklahoma', 'short_name': 'OK', 'types': ['administrative_area_level_1', 'political']}, {'long_name': 'United States', 'short_name': 'US', 'types': ['country', 'political']}], 'formatted_address': 'Tulsa County, OK, USA', 'geometry': {'bounds': {'northeast': {'lat': 36.4237321, 'lng': -95.7614629}, 'southwest': {'lat': 35.8559, 'lng': -96.29809}}, 'location': {'lat': 36.1593471, 'lng': -95.94097099999999}, 'location_type': 'APPROXIMATE', 'viewport': {'northeast': {'lat': 36.4237321, 'lng': -95.7614629}, 'southwest': {'lat': 35.8559, 'lng': -96.29809}}}, 'place_id': 'ChIJscN-NimKtocROGrbT2c3uEM', 'types': ['administrative_area_level_2', 'political']}, {'address_components': [{'long_name': 'Oklahoma', 'short_name': 'OK', 'types': ['administrative_area_level_1', 'political']}, {'long_name': 'United States', 'short_name': 'US', 'types': ['country', 'political']}], 'formatted_address': 'Oklahoma, USA', 'geometry': {'bounds': {'northeast': {'lat': 37.0023119, 'lng': -94.430662}, 'southwest': {'lat': 33.615787, 'lng': -103.002455}}, 'location': {'lat': 35.0077519, 'lng': -97.092877}, 'location_type': 'APPROXIMATE', 'viewport': {'northeast': {'lat': 37.0023119, 'lng': -94.430662}, 'southwest': {'lat': 33.615787, 'lng': -103.002455}}}, 'place_id': 'ChIJnU-ssRE5rIcRSOoKQDPPHF0', 'types': ['administrative_area_level_1', 'political']}, {'address_components': [{'long_name': 'United States', 'short_name': 'US', 'types': ['country', 'political']}], 'formatted_address': 'United States', 'geometry': {'bounds': {'northeast': {'lat': 71.5388001, 'lng': -66.885417}, 'southwest': {'lat': 18.7763, 'lng': 170.5957}}, 'location': {'lat': 37.09024, 'lng': -95.712891}, 'location_type': 'APPROXIMATE', 'viewport': {'northeast': {'lat': 71.5388001, 'lng': -66.885417}, 'southwest': {'lat': 18.7763, 'lng': 170.5957}}}, 'place_id': 'ChIJCzYy5IS16lQRQrfeQ5K5Oxw', 'types': ['country', 'political']}], 'status': 'OK'}
    item = extractor.get_items_from_response(response, True)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0], True)
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)
    
    print("- Extracting data from Here response (geocoding)")
    response = {'items': [{'title': '13219 Kimberly Clark Pl, Jenks, OK 74008, United States', 'id': 'here:af:streetsection:HFJSyuQpYf7bh-DWUGVpsC:EAIaBTEzMjE5', 'resultType': 'houseNumber', 'houseNumberType': 'interpolated', 'address': {'label': '13219 Kimberly Clark Pl, Jenks, OK 74008, United States', 'countryCode': 'USA', 'countryName': 'United States', 'stateCode': 'OK', 'state': 'Oklahoma', 'county': 'Tulsa', 'city': 'Jenks', 'street': 'Kimberly Clark Pl', 'postalCode': '74008', 'houseNumber': '13219'}, 'position': {'lat': 35.96853, 'lng': -95.93075}, 'access': [{'lat': 35.96853, 'lng': -95.93092}], 'mapView': {'west': -95.93186, 'south': 35.96763, 'east': -95.92964, 'north': 35.96943}, 'scoring': {'queryScore': 0.84, 'fieldScore': {'country': 1.0, 'state': 1.0, 'city': 1.0, 'streets': [1.0], 'houseNumber': 1.0, 'postalCode': 0.64}}}]}
    extractor = HereResponseExtractor()
    item = extractor.get_items_from_response(response)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0])
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)
    
    response = {'items': [{'title': 'Kimberly-Clark', 'id': 'here:pds:place:840962og-493f89bf5b9b0171fb087d5d04652c3a', 'resultType': 'place', 'address': {'label': 'Kimberly-Clark, Bixby, OK 74008, United States', 'countryCode': 'USA', 'countryName': 'United States', 'stateCode': 'OK', 'state': 'Oklahoma', 'county': 'Tulsa', 'city': 'Bixby', 'postalCode': '74008'}, 'position': {'lat': 35.96968, 'lng': -95.92305}, 'access': [{'lat': 35.96968, 'lng': -95.92305}], 'distance': 213, 'categories': [{'id': '900-9200-0218', 'name': 'Industrial Zone', 'primary': True}]}]}
    item = extractor.get_items_from_response(response, True)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0], True)
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)

    print("- Extracting data from OpenMap response (geocoding)")
    response = {'summary': {'query': '13219 south kimberly clark place jenks ok 74037 usa', 'queryType': 'NON_NEAR', 'queryTime': 1197, 'numResults': 5, 'offset': 0, 'totalResults': 6, 'fuzzyLevel': 2}, 'results': [{'type': 'Address Range', 'id': 'US/ADDR/p1/13385093', 'score': 10.5183696747, 'address': {'streetNumber': '13219', 'streetName': 'Kimberly Clark Pl', 'municipality': 'Jenks', 'countrySecondarySubdivision': 'Tulsa County', 'countrySubdivision': 'Oklahoma', 'countryCode': 'US', 'country': 'United States', 'countryCodeISO3': 'USA', 'freeformAddress': '13219 Kimberly Clark Pl, Jenks, Oklahoma', 'localName': 'Jenks'}, 'position': {'lat': 35.97164, 'lon': -95.93088}, 'viewport': {'topLeftPoint': {'lat': 35.97379, 'lon': -95.93094}, 'btmRightPoint': {'lat': 35.97018, 'lon': -95.93093}}, 'addressRanges': {'rangeLeft': '13101 - 13299', 'from': {'lat': 35.97379, 'lon': -95.93093}, 'to': {'lat': 35.97018, 'lon': -95.93094}}}, {'type': 'Point Address', 'id': 'US/PAD/p0/55127254', 'score': 9.6188621521, 'address': {'streetNumber': 'Jenks', 'streetName': 'W 112th Pl S', 'municipality': 'Jenks', 'countrySecondarySubdivision': 'Tulsa County', 'countrySubdivision': 'Oklahoma', 'postalCode': '74037-2129', 'countryCode': 'US', 'country': 'United States', 'countryCodeISO3': 'USA', 'freeformAddress': 'Jenks W 112th Pl S, Jenks, Oklahoma 74037-2129', 'localName': 'Jenks'}, 'position': {'lat': 36.00032, 'lon': -96.00356}, 'viewport': {'topLeftPoint': {'lat': 36.00122, 'lon': -96.00467}, 'btmRightPoint': {'lat': 35.99942, 'lon': -96.00245}}}, {'type': 'Address Range', 'id': 'US/ADDR/p1/10183281', 'score': 9.4276924133, 'address': {'streetNumber': '13219', 'streetName': 'S Clark Prevo Pl', 'countrySecondarySubdivision': 'Vigo County', 'countrySubdivision': 'Indiana', 'countryCode': 'US', 'country': 'United States', 'countryCodeISO3': 'USA', 'freeformAddress': '13219 S Clark Prevo Pl, Indiana'}, 'position': {'lat': 39.30616, 'lon': -87.59139}, 'viewport': {'topLeftPoint': {'lat': 39.31723, 'lon': -87.60307}, 'btmRightPoint': {'lat': 39.29924, 'lon': -87.57983}}, 'addressRanges': {'rangeLeft': '12601 - 13491', 'from': {'lat': 39.31358, 'lon': -87.59146}, 'to': {'lat': 39.30289, 'lon': -87.59144}}}, {'type': 'Address Range', 'id': 'US/ADDR/p1/13480123', 'score': 9.3273477554, 'address': {'streetNumber': '13219', 'streetName': 'S 21st Pl', 'municipality': 'Jenks', 'countrySecondarySubdivision': 'Tulsa County', 'countrySubdivision': 'Oklahoma', 'countryCode': 'US', 'country': 'United States', 'countryCodeISO3': 'USA', 'freeformAddress': '13219 S 21st Pl, Jenks, Oklahoma', 'localName': 'Jenks'}, 'position': {'lat': 35.97152, 'lon': -95.94095}, 'viewport': {'topLeftPoint': {'lat': 35.97165, 'lon': -95.94102}, 'btmRightPoint': {'lat': 35.97095, 'lon': -95.94094}}, 'addressRanges': {'rangeLeft': '13201 - 13299', 'from': {'lat': 35.97165, 'lon': -95.94102}, 'to': {'lat': 35.97095, 'lon': -95.94094}}}, {'type': 'Address Range', 'id': 'US/ADDR/p2/13456892', 'score': 9.3273477554, 'address': {'streetNumber': '13219', 'streetName': 'S 19th Pl', 'municipality': 'Jenks', 'countrySecondarySubdivision': 'Tulsa County', 'countrySubdivision': 'Oklahoma', 'countryCode': 'US', 'country': 'United States', 'countryCodeISO3': 'USA', 'freeformAddress': '13219 S 19th Pl, Jenks, Oklahoma', 'localName': 'Jenks'}, 'position': {'lat': 35.97116, 'lon': -95.94681}, 'viewport': {'topLeftPoint': {'lat': 35.97127, 'lon': -95.94689}, 'btmRightPoint': {'lat': 35.96999, 'lon': -95.94656}}, 'addressRanges': {'rangeLeft': '13201 - 13399', 'from': {'lat': 35.97127, 'lon': -95.94689}, 'to': {'lat': 35.96999, 'lon': -95.94656}}}]}
    extractor = OpenMapResponseExtractor()
    item = extractor.get_items_from_response(response)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0])
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)

    print("- Extracting data from OSM response (geocoding)")
    response = [{'place_id': 121212563, 'licence': 'Data © OpenStreetMap contributors, ODbL 1.0. https://osm.org/copyright', 'osm_type': 'way', 'osm_id': 90394480, 'boundingbox': ['52.5487473', '52.5488481', '-1.816513', '-1.8163464'], 'lat': '52.5487921', 'lon': '-1.8164308339635031', 'display_name': '135, Pilkington Avenue, Maney, Sutton Coldfield, Wylde Green, Birmingham, West Midlands Combined Authority, West Midlands, England, B72 1LH, United Kingdom', 'place_rank': 30, 'category': 'building', 'type': 'residential', 'importance': 0.411, 'address': {'house_number': '135', 'road': 'Pilkington Avenue', 'hamlet': 'Maney', 'town': 'Sutton Coldfield', 'village': 'Wylde Green', 'city': 'Birmingham', 'county': 'West Midlands Combined Authority', 'state_district': 'West Midlands', 'state': 'England', 'postcode': 'B72 1LH', 'country': 'United Kingdom', 'country_code': 'gb'}}]
    extractor = OSMResponseExtractor()
    item = extractor.get_items_from_response(response)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0])
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)
    
    print("- Extracting data from OSM response (reverse geocoding)")
    response = {'place_id': 101438031, 'licence': 'Data © OpenStreetMap contributors, ODbL 1.0. https://osm.org/copyright', 'osm_type': 'way', 'osm_id': 15033921, 'lat': '35.9665476', 'lon': '-95.9223764', 'place_rank': 26, 'category': 'highway', 'type': 'residential', 'importance': 0.09999999999999998, 'addresstype': 'road', 'name': 'South Yale Avenue', 'display_name': 'South Yale Avenue, Kimberly-Clark, Bixby, Tulsa County, Oklahoma, 74008, United States', 'address': {'road': 'South Yale Avenue', 'industrial': 'Kimberly-Clark', 'town': 'Bixby', 'county': 'Tulsa County', 'state': 'Oklahoma', 'postcode': '74008', 'country': 'United States', 'country_code': 'us'}, 'extratags': {'maxspeed': '50 mph'}, 'namedetails': {'name': 'South Yale Avenue'}, 'boundingbox': ['35.901145', '35.9665476', '-95.922409', '-95.922286']}
    item = extractor.get_items_from_response(response, True)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0], True)
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)
    
    print("- Extracting data from TomTom response (geocoding)")
    response = {'summary': {'query': '13219 south kimberly clark place jenks ok 74037 usa', 'queryType': 'NON_NEAR', 'queryTime': 130, 'numResults': 1, 'offset': 0, 'totalResults': 1, 'fuzzyLevel': 1}, 'results': [{'type': 'Address Range', 'id': 'US/ADDR/p2/52101270', 'score': 15.3311691284, 'address': {'streetNumber': '13219', 'streetName': 'Kimberly Clark Place', 'municipality': 'Jenks', 'countrySecondarySubdivision': 'Tulsa', 'countrySubdivision': 'OK', 'countrySubdivisionName': 'Oklahoma', 'postalCode': '74008', 'countryCode': 'US', 'country': 'United States', 'countryCodeISO3': 'USA', 'freeformAddress': '13219 Kimberly Clark Place, Bixby, OK 74008', 'localName': 'Bixby'}, 'position': {'lat': 35.97307, 'lon': -95.93098}, 'viewport': {'topLeftPoint': {'lat': 35.97379, 'lon': -95.93093}, 'btmRightPoint': {'lat': 35.97259, 'lon': -95.93092}}, 'addressRanges': {'rangeLeft': '13297 - 13101', 'from': {'lat': 35.97259, 'lon': -95.93092}, 'to': {'lat': 35.97379, 'lon': -95.93093}}}]}
    extractor = TomtomResponseExtractor()
    item = extractor.get_items_from_response(response)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0])
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)
    print(provider_address_components)
    df = extractor.get_df_from_components(provider_address_components)
    df = extractor.get_df_from_item(item[0])
    print(df)
    
    print("- Extracting data from TomTom response (reverse geocoding)")
    response = {'summary': {'queryTime': 22, 'numResults': 1}, 'addresses': [{'address': {'buildingNumber': '13252', 'streetNumber': '13252', 'routeNumbers': [], 'street': 'South Yale Place', 'streetName': 'South Yale Place', 'streetNameAndNumber': '13252 South Yale Place', 'countryCode': 'US', 'countrySubdivision': 'OK', 'countrySecondarySubdivision': 'Tulsa', 'municipality': 'Jenks', 'postalCode': '74008', 'country': 'United States', 'countryCodeISO3': 'USA', 'freeformAddress': '13252 South Yale Place, Bixby, OK 74008', 'boundingBox': {'northEast': '35.969274,-95.926154', 'southWest': '35.968154,-95.927080', 'entity': 'position'}, 'extendedPostalCode': '74008-4227', 'countrySubdivisionName': 'Oklahoma', 'localName': 'Bixby'}, 'position': '35.970165,-95.926468'}]}
    item = extractor.get_items_from_response(response, True)
    provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country = extractor.get_data_from_item(item[0], True)
    print(provider_address_components, provider_api_id, provider_type, provider_address, provider_lat, provider_lon, country)